#!/bin/sh
# MC Panel на Linux/macOS: нужен Node.js 22 или новее (https://nodejs.org)
cd "$(dirname "$0")"
export PORT="${PORT:-3000}" DATA_DIR="${DATA_DIR:-$(pwd)/data}"
exec node --no-warnings server.js
