@echo off
chcp 65001 >nul
title MC Panel
cd /d "%~dp0"
if not defined PORT set PORT=3000
if not defined DATA_DIR set "DATA_DIR=%~dp0data"
echo Запуск MC Panel...
echo Если Windows спросит про брандмауэр - нажмите "Разрешить доступ" (частные сети),
echo иначе приложение на телефоне не найдет панель.
echo.
"%~dp0node\node.exe" --no-warnings server.js
echo.
echo Панель остановлена. Нажмите любую клавишу, чтобы закрыть окно.
pause >nul
