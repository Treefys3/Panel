#!/usr/bin/env node
'use strict';
/*
 * Агент панели для сервера Minecraft. Запускается на той же машине, где работает сервер.
 *  - читает logs/latest.log и отправляет события (вход/выход, чат, команды, смерти, достижения, наказания, репорты);
 *  - передаёт строки консоли;
 *  - (опционально) опрашивает статус сервера и принимает RCON-команды от панели, выполняя их локально.
 *
 * Запуск:  node agent.js --config agent.config.json
 */
const fs = require('fs');
const path = require('path');
const mc = require('./mc');
const { spawn } = require('child_process');

const VERSION = '1.2.0';

// ───────────── Конфигурация ─────────────
function parseProps(file) {
  const out = {};
  for (const l of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([^#=\s][^=]*?)\s*=\s*(.*)$/.exec(l);
    if (m) out[m[1]] = m[2];
  }
  return out;
}
function detectProps() {
  for (const d of [process.cwd(), path.join(process.cwd(), '..'), path.join(__dirname, '..')]) {
    const f = path.join(d, 'server.properties');
    if (fs.existsSync(f)) return f;
  }
  return null;
}
function loadConfig() {
  const args = process.argv.slice(2);
  let cfgPath = path.join(__dirname, 'agent.config.json');
  const cli = {};
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--config') cfgPath = args[++i];
    else if (a.startsWith('--')) cli[a.slice(2)] = args[i + 1] !== undefined && !args[i + 1].startsWith('--') ? args[++i] : 'true';
  }
  let file = {};
  try { file = JSON.parse(fs.readFileSync(cfgPath, 'utf8')); }
  catch (e) { if (e.code !== 'ENOENT') { console.error('Не удалось прочитать конфиг:', e.message); process.exit(1); } }
  const env = process.env;
  const cfg = {
    panel: (cli.panel || env.PANEL_URL || file.panel || '').replace(/\/+$/, ''),
    key: cli.key || env.PANEL_KEY || file.key,
    log: cli.log || env.MC_LOG || file.log,
    properties: cli.properties || file.properties || detectProps(),
    autoUpdate: String(cli['auto-update'] ?? file.autoUpdate ?? 'false') === 'true',
    mcHost: cli['mc-host'] || file.mcHost,
    mcPort: Number(cli['mc-port'] || file.mcPort || 25565),
    rcon: file.rcon || null,
    startCommand: cli['start-command'] || file.startCommand || '',
    startDir: file.startDir || '',
    sendConsole: String(cli.console ?? file.sendConsole ?? 'true') !== 'false',
    replay: String(cli.replay ?? file.replay ?? 'false') === 'true',
  };
  if (cli['rcon-port']) cfg.rcon = { host: cli['rcon-host'] || '127.0.0.1', port: Number(cli['rcon-port']), password: cli['rcon-password'] || env.RCON_PASSWORD || '' };
  if (cfg.properties) {
    try {
      const p = parseProps(cfg.properties);
      if (!cfg.rcon && p['enable-rcon'] === 'true' && p['rcon.password']) cfg.rcon = { host: '127.0.0.1', port: Number(p['rcon.port'] || 25575), password: p['rcon.password'] };
      if (!cfg.mcHost) { cfg.mcHost = '127.0.0.1'; cfg.mcPort = Number(p['server-port'] || 25565); }
      if (!cfg.log) cfg.log = path.join(path.dirname(cfg.properties), 'logs', 'latest.log');
    } catch (e) { console.error('Не удалось прочитать server.properties:', e.message); }
  }
  if (!cfg.panel || !cfg.key || !cfg.log) {
    console.error('Нужно указать panel (адрес панели), key (ключ сервера) и log (путь к latest.log) — в конфиге или флагами --panel --key --log');
    process.exit(1);
  }
  return cfg;
}
const cfg = loadConfig();
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);

// ───────────── Разбор строк лога ─────────────
const ANSI = /\x1b\[[0-9;]*[A-Za-z]/g;
const DEATH = new RegExp('^(\\w{1,16}) (' + [
  'was slain by', 'was shot by', 'was fireballed by', 'was pummeled by', 'was killed by', 'was blown up by', 'was squashed by', 'was impaled on',
  'was skewered by', 'was pricked to death', 'was poked to death', 'was doomed to fall', 'was squished too much', 'was stung to death', 'was struck by lightning',
  'was killed', 'was obliterated by', 'was frozen to death', 'was roasted in dragon', 'was burnt to a crisp', 'was shot off', 'was knocked off', 'was blown from',
  'fell from a high place', 'fell off', 'fell out of the water', 'fell while', 'fell into a patch', 'hit the ground too hard', 'drowned', 'suffocated in a wall',
  'starved to death', 'burned to death', 'went up in flames', 'walked into fire', 'walked into a cactus', 'tried to swim in lava', 'discovered the floor was lava',
  'blew up', 'withered away', 'died', 'experienced kinetic energy', 'froze to death', 'left the confines of this world', 'didn\'t want to live in the same world as',
  'went off with a bang', 'was squished', 'was stung', 'was impaled', 'was fireballed', 'was pummeled', 'was shot',
].map(s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')(?: (.*))?$');

const uuids = new Map();       // имя -> uuid (из строки "UUID of player")
const pendingLeave = new Map(); // имя -> причина отключения

function parseHeader(line) {
  if (line[0] !== '[') return null;
  const i = line.indexOf(']: ');
  if (i < 0) return null;
  const head = line.slice(0, i + 1);
  const lvl = /(INFO|WARN|ERROR|FATAL|DEBUG)/.exec(head);
  const t = /^\[(\d\d):(\d\d):(\d\d)/.exec(head);
  if (!t) return null;
  return { level: lvl ? lvl[1] : 'INFO', time: [+t[1], +t[2], +t[3]], msg: line.slice(i + 3) };
}
function toTs(time) {
  const d = new Date();
  d.setHours(time[0], time[1], time[2], 0);
  let ts = d.getTime();
  if (ts > Date.now() + 120000) ts -= 86400000;
  return ts;
}

// Возвращает массив событий для строки (без console)
function parseMessage(msg, level, ts) {
  let m;
  const ev = (type, player, message, data) => ({ type, ts, player: player || undefined, message: message || undefined, data: data || undefined });

  if ((m = /^UUID of player (\S+) is ([0-9a-f-]{32,36})$/i.exec(msg))) { uuids.set(m[1], m[2]); return []; }
  if ((m = /^(\S+)\[\/(.+):(\d+)\] logged in with entity id (\d+) at \((.*)\)$/.exec(msg))) {
    const data = { ip: m[2], uuid: uuids.get(m[1]), entity: +m[4], pos: m[5] };
    const w = /^\[([^\]]+)\]/.exec(m[5]);
    if (w) data.world = w[1];
    return [ev('join', m[1], null, data)];
  }
  if ((m = /^(\S+) lost connection: (.*)$/.exec(msg))) { pendingLeave.set(m[1], m[2]); return []; }
  if ((m = /^(\S+) left the game$/.exec(msg))) {
    const reason = pendingLeave.get(m[1]); pendingLeave.delete(m[1]);
    return [ev('leave', m[1], reason || null, reason ? { reason } : null)];
  }
  if ((m = /^(?:\[Not Secure\] )?<([^>\s]+)> (.*)$/.exec(msg))) return [ev('chat', m[1], m[2])];
  if ((m = /^(\S+) issued server command: (\/.*)$/.exec(msg))) {
    const out = [ev('command', m[1], m[2])];
    const r = /^\/(?:report|rep|репорт)\s+(\S+)\s+(.+)$/i.exec(m[2]);
    if (r) out.push(ev('report', m[1], r[2], { target: r[1] }));
    return out;
  }
  if ((m = /^(\S+) has (made the advancement|completed the challenge|reached the goal) \[(.+)\]$/.exec(msg))) {
    return [ev('advancement', m[1], `${m[2] === 'made the advancement' ? 'Достижение' : m[2] === 'completed the challenge' ? 'Испытание' : 'Цель'}: ${m[3]}`, { name: m[3] })];
  }
  if (/^Done \([\d.,]+s\)! For help/.test(msg)) return [ev('server_start', null, 'Сервер запущен')];
  if (/^Stopping (the )?server/.test(msg)) return [ev('server_stop', null, 'Сервер останавливается')];
  // Наказания, выданные операторами: [Admin: Banned Steve: reason]  или  Banned Steve: reason
  if ((m = /^\[(\S+?): (Banned|Unbanned|Kicked) (\S+?)(?:: (.*?))?\]$/.exec(msg)) || (m = /^()(Banned|Unbanned|Kicked) (\S+?)(?:: (.*))?$/.exec(msg))) {
    const kind = { Banned: 'ban', Unbanned: 'unban', Kicked: 'kick' }[m[2]];
    const actor = m[1] || 'Server';
    if (actor !== 'Rcon' && /^[\w.\-]{1,40}$/.test(m[3])) return [ev('punish', m[3], m[4] && m[4] !== 'Banned by an operator.' ? m[4] : '', { kind, actor })];
    return [];
  }
  if ((m = DEATH.exec(msg)) && !msg.startsWith('<')) {
    const by = /was (?:slain|shot|killed|blown up|fireballed|pummeled|squashed|impaled|skewered|obliterated) by (.+?)(?: using .*)?$/.exec(msg);
    return [ev('death', m[1], msg, by ? { killer: by[1] } : null)];
  }
  if (level === 'ERROR' || level === 'FATAL') return [ev('error', null, msg.slice(0, 500))];
  return [];
}

// ───────────── Очередь отправки ─────────────
const queue = [];
let errThrottle = { t: 0, n: 0 };
function push(e) {
  if (queue.length > 20000) queue.splice(0, 5000);
  queue.push(e);
}
function onLine(raw) {
  const line = raw.replace(ANSI, '').replace(/§[0-9a-fk-or]/gi, '').trimEnd();
  if (!line) return;
  const h = parseHeader(line);
  if (!h) { // продолжение предыдущей записи (stack trace)
    if (cfg.sendConsole) push({ type: 'console', ts: Date.now(), message: line.slice(0, 1500), data: { level: 'INFO' } });
    return;
  }
  const ts = toTs(h.time);
  if (cfg.sendConsole) push({ type: 'console', ts, message: h.msg.slice(0, 1500), data: { level: h.level } });
  for (const e of parseMessage(h.msg, h.level, ts)) {
    if (e.type === 'error') { // не заваливаем панель при лавине ошибок
      const now = Date.now();
      if (now - errThrottle.t > 1000) errThrottle = { t: now, n: 0 };
      if (++errThrottle.n > 5) continue;
    }
    push(e);
  }
}

// ───────────── Чтение файла лога ─────────────
class Tailer {
  constructor(file) { this.file = file; this.pos = null; this.ino = null; this.buf = ''; this.busy = false; }
  start() { setInterval(() => this.poll(), 400); this.poll(); }
  poll() {
    if (this.busy) return;
    this.busy = true;
    fs.stat(this.file, (err, st) => {
      if (err) { this.busy = false; return; }
      if (this.pos === null) this.pos = cfg.replay ? 0 : st.size;
      if (this.ino !== null && st.ino !== this.ino) { this.pos = 0; this.buf = ''; }
      this.ino = st.ino;
      if (st.size < this.pos) { this.pos = 0; this.buf = ''; }
      if (st.size === this.pos) { this.busy = false; return; }
      const len = Math.min(st.size - this.pos, 1024 * 1024);
      fs.open(this.file, 'r', (e2, fd) => {
        if (e2) { this.busy = false; return; }
        const b = Buffer.alloc(len);
        fs.read(fd, b, 0, len, this.pos, (e3, n) => {
          fs.close(fd, () => {});
          this.busy = false;
          if (e3 || !n) return;
          this.pos += n;
          this.buf += b.toString('utf8', 0, n);
          const lines = this.buf.split(/\r?\n/);
          this.buf = lines.pop();
          for (const l of lines) { try { onLine(l); } catch (e) { log('Ошибка разбора:', e.message); } }
        });
      });
    });
  }
}

// ───────────── Связь с панелью ─────────────
async function api(method, url, body, timeout = 15000) {
  const res = await fetch(cfg.panel + url, {
    method,
    headers: { Authorization: 'Bearer ' + cfg.key, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(timeout),
  });
  const text = await res.text();
  let json = {};
  try { json = JSON.parse(text); } catch {}
  if (!res.ok) { const e = new Error(json.error || 'HTTP ' + res.status); e.status = res.status; throw e; }
  return json;
}

// Автообновление: панель сообщает актуальную версию агента; при расхождении агент скачивает файлы и перезапускается (под службой/run.sh)
let updating = false, lastUpdateTry = 0;
async function checkUpdate(latest) {
  if (!cfg.autoUpdate || latest === VERSION || latest === '0' || updating || Date.now() - lastUpdateTry < 3600000) return;
  updating = true; lastUpdateTry = Date.now();
  try {
    const texts = {};
    for (const f of ['agent.js', 'mc.js']) {
      const res = await fetch(`${cfg.panel}/agent-dl/${f}`, { signal: AbortSignal.timeout(20000) });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      texts[f] = await res.text();
      if (!texts[f].includes("'use strict'")) throw new Error('некорректный файл');
    }
    for (const f of Object.keys(texts)) fs.writeFileSync(path.join(__dirname, f + '.new'), texts[f]);
    for (const f of Object.keys(texts)) fs.renameSync(path.join(__dirname, f + '.new'), path.join(__dirname, f));
    log(`Агент обновлён до ${latest}, перезапуск…`);
    setTimeout(() => process.exit(0), 500);
  } catch (e) { log('Не удалось обновить агента:', e.message); updating = false; }
}

let status = null;
async function refreshStatus() {
  if (!cfg.mcHost) return;
  try { status = await mc.ping(cfg.mcHost, cfg.mcPort, 4000); }
  catch { status = { online: false, players_online: 0, players_max: 0 }; }
}

let lastBeat = 0, lastErr = '', sending = false;
async function flush() {
  if (sending) return;
  const beatDue = Date.now() - lastBeat > 10000;
  if (!queue.length && !beatDue) return;
  sending = true;
  const batch = queue.slice(0, 300);
  try {
    const body = { events: batch, agent: { v: VERSION, rcon: !!cfg.rcon } };
    if (beatDue && status) body.agent.status = status;
    const r = await api('POST', '/api/agent/events', body);
    if (r.agent_latest) checkUpdate(r.agent_latest);
    queue.splice(0, batch.length);
    lastBeat = Date.now();
    if (lastErr) { log('Связь с панелью восстановлена'); lastErr = ''; }
  } catch (e) {
    if (e.message !== lastErr) { log('Ошибка отправки в панель:', e.message); lastErr = e.message; }
    if (e.status === 401) log('Проверьте ключ сервера (key) в настройках агента');
  } finally { sending = false; }
}

// Запуск/перезапуск сервера (нужен startCommand в agent.config.json)
const sleepMs = ms => new Promise(r => setTimeout(r, ms));
async function isUp() { if (!cfg.mcHost) return false; try { const s = await mc.ping(cfg.mcHost, cfg.mcPort, 3000); return !!s.online; } catch { return false; } }
function startServer() {
  const dir = cfg.startDir || path.dirname(cfg.properties || path.dirname(path.dirname(cfg.log)));
  const out = fs.openSync(path.join(dir, 'panel-start.log'), 'a');
  const child = spawn(cfg.startCommand, { shell: true, cwd: dir, detached: true, stdio: ['ignore', out, out] });
  child.unref();
}
async function control(action) {
  if (action !== 'start' && action !== 'restart') return { ok: false, error: 'Неизвестная команда' };
  if (!cfg.startCommand) return { ok: false, error: 'В agent.config.json не задан "startCommand" (например "./start.sh" или "java -Xmx4G -jar server.jar nogui")' };
  try {
    if (action === 'start') {
      if (await isUp()) return { ok: true, response: 'Сервер уже запущен' };
      startServer();
      return { ok: true, response: 'Команда запуска выполнена, сервер стартует…' };
    }
    if (await isUp()) {
      if (!cfg.rcon) return { ok: false, error: 'Для перезапуска нужен RCON (остановка сервера)' };
      await mc.rcon(cfg.rcon.host || '127.0.0.1', cfg.rcon.port, cfg.rcon.password, 'stop').catch(() => {});
      let down = false;
      for (let i = 0; i < 45 && !down; i++) { await sleepMs(2000); down = !(await isUp()); }
      if (!down) return { ok: false, error: 'Сервер не остановился за 90 секунд' };
      await sleepMs(3000);
    }
    startServer();
    return { ok: true, response: 'Сервер остановлен и запускается снова…' };
  } catch (e) { return { ok: false, error: e.message }; }
}
async function commandLoop() {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  for (;;) {
    try {
      const r = await api('GET', `/api/agent/commands?wait=25&v=${VERSION}`, null, 40000);
      if (r.agent_latest) checkUpdate(r.agent_latest);
      for (const c of r.commands || []) {
        let result;
        if (c.command.startsWith('@@')) {
          result = await control(c.command.slice(2));
          log('Управление:', c.command, result.ok ? '→ ok' : '→ ' + result.error);
          await api('POST', `/api/agent/commands/${c.id}/result`, result).catch(e => log('Не удалось отправить результат:', e.message));
          continue;
        }
        try {
          const out = await mc.rcon(cfg.rcon.host || '127.0.0.1', cfg.rcon.port, cfg.rcon.password, c.command);
          result = { ok: true, response: out };
        } catch (e) { result = { ok: false, error: e.message }; }
        log('RCON:', c.command, result.ok ? '→ ok' : '→ ' + result.error);
        await api('POST', `/api/agent/commands/${c.id}/result`, result).catch(e => log('Не удалось отправить результат:', e.message));
      }
    } catch (e) { await sleep(3000); }
  }
}

// ───────────── Запуск ─────────────
log(`Агент ${VERSION} запущен. Панель: ${cfg.panel}`);
log(`Лог: ${cfg.log}${cfg.replay ? ' (чтение с начала)' : ''}`);
log(cfg.rcon ? `RCON: ${cfg.rcon.host || '127.0.0.1'}:${cfg.rcon.port} — команды из панели включены` : 'RCON не настроен — команды из панели выполняться не будут');
if (cfg.mcHost) log(`Статус сервера опрашивается: ${cfg.mcHost}:${cfg.mcPort}`);

new Tailer(cfg.log).start();
setInterval(flush, 1000);
setInterval(refreshStatus, 10000);
refreshStatus().then(flush);
if (cfg.rcon || cfg.startCommand) commandLoop();
process.on('uncaughtException', e => log('Ошибка:', e.message));
