'use strict';
// Протоколы Minecraft: Server List Ping (статус сервера) и RCON (консольные команды).
// Без внешних зависимостей. Используется и панелью, и агентом.
const net = require('net');

function varint(n) {
  const out = [];
  n >>>= 0;
  do {
    let b = n & 0x7f;
    n >>>= 7;
    if (n) b |= 0x80;
    out.push(b);
  } while (n);
  return Buffer.from(out);
}
function mcString(s) {
  const b = Buffer.from(s, 'utf8');
  return Buffer.concat([varint(b.length), b]);
}
function packet(id, payload) {
  const body = Buffer.concat([varint(id), payload]);
  return Buffer.concat([varint(body.length), body]);
}
function readVarInt(buf, off) {
  let n = 0, shift = 0, i = off;
  for (;;) {
    if (i >= buf.length) return null;
    const b = buf[i++];
    n |= (b & 0x7f) << shift;
    if (!(b & 0x80)) break;
    shift += 7;
    if (shift > 35) throw new Error('varint слишком длинный');
  }
  return { value: n, size: i - off };
}

function stripCodes(s) {
  return String(s == null ? '' : s).replace(/§[0-9a-fk-orx]/gi, '').replace(/\x1b\[[0-9;]*m/g, '');
}
function motdText(d) {
  if (d == null) return '';
  if (typeof d === 'string') return d;
  if (Array.isArray(d)) return d.map(motdText).join('');
  let s = d.text || '';
  if (!s && d.translate) s = d.translate;
  if (Array.isArray(d.extra)) for (const e of d.extra) s += motdText(e);
  return s;
}

function parseStatus(json) {
  const p = json.players || {};
  return {
    online: true,
    version: (json.version && json.version.name) || '',
    protocol: (json.version && json.version.protocol) || null,
    players_online: Number.isFinite(p.online) ? p.online : 0,
    players_max: Number.isFinite(p.max) ? p.max : 0,
    sample: Array.isArray(p.sample) ? p.sample.map(x => x && x.name).filter(Boolean) : [],
    motd: stripCodes(motdText(json.description)).replace(/\s+\n/g, '\n').trim().slice(0, 300),
    favicon: typeof json.favicon === 'string' && json.favicon.length < 70000 ? json.favicon : null,
    latency: null,
  };
}

// Server List Ping. Возвращает объект со статусом или бросает ошибку.
function ping(host, port = 25565, timeout = 4000) {
  return new Promise((resolve, reject) => {
    let buf = Buffer.alloc(0), done = false, info = null, t0 = 0, fallback = null;
    const sock = net.connect({ host, port });
    const finish = (err, val) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      clearTimeout(fallback);
      sock.destroy();
      err ? reject(err) : resolve(val);
    };
    const timer = setTimeout(() => finish(info ? null : new Error('таймаут'), info), timeout);
    sock.on('error', finish);
    sock.on('close', () => finish(info ? null : new Error('соединение закрыто'), info));
    sock.on('connect', () => {
      const hs = Buffer.concat([varint(-1), mcString(host), Buffer.from([(port >> 8) & 255, port & 255]), varint(1)]);
      t0 = Date.now();
      sock.write(Buffer.concat([packet(0, hs), packet(0, Buffer.alloc(0))]));
    });
    sock.on('data', d => {
      try {
        buf = Buffer.concat([buf, d]);
        for (;;) {
          const len = readVarInt(buf, 0);
          if (!len || buf.length < len.size + len.value) return;
          const body = buf.subarray(len.size, len.size + len.value);
          buf = buf.subarray(len.size + len.value);
          const id = readVarInt(body, 0);
          if (id.value === 0) {
            const sl = readVarInt(body, id.size);
            const json = JSON.parse(body.subarray(id.size + sl.size, id.size + sl.size + sl.value).toString('utf8'));
            info = parseStatus(json);
            info.latency = Date.now() - t0;
            t0 = Date.now();
            const payload = Buffer.alloc(8);
            payload.writeBigInt64BE(BigInt(t0));
            sock.write(packet(1, payload));
            fallback = setTimeout(() => finish(null, info), 800);
          } else if (id.value === 1 && info) {
            info.latency = Math.max(1, Date.now() - t0);
            finish(null, info);
          }
        }
      } catch (e) { finish(e); }
    });
  });
}

// RCON: выполняет одну команду и возвращает текст ответа.
function rcon(host, port, password, command, timeout = 6000) {
  return new Promise((resolve, reject) => {
    let buf = Buffer.alloc(0), authed = false, out = [], done = false, idle = null;
    const sock = net.connect({ host, port });
    const finish = (err, val) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      clearTimeout(idle);
      sock.destroy();
      err ? reject(err) : resolve(val);
    };
    const timer = setTimeout(() => finish(new Error('RCON: таймаут ответа')), timeout);
    const send = (id, type, body) => {
      const b = Buffer.from(body, 'utf8');
      const p = Buffer.alloc(14 + b.length);
      p.writeInt32LE(10 + b.length, 0);
      p.writeInt32LE(id, 4);
      p.writeInt32LE(type, 8);
      b.copy(p, 12);
      sock.write(p);
    };
    sock.on('error', e => finish(new Error('RCON: ' + (e.code === 'ECONNREFUSED' ? 'соединение отклонено (RCON выключен или неверный порт)' : e.message))));
    sock.on('close', () => finish(authed ? null : new Error('RCON: соединение закрыто'), stripCodes(out.join(''))));
    sock.on('connect', () => send(1, 3, password));
    sock.on('data', d => {
      buf = Buffer.concat([buf, d]);
      while (buf.length >= 4) {
        const len = buf.readInt32LE(0);
        if (len < 10 || len > 8192) return finish(new Error('RCON: повреждённый пакет'));
        if (buf.length < len + 4) break;
        const id = buf.readInt32LE(4), type = buf.readInt32LE(8);
        const body = buf.toString('utf8', 12, len + 2);
        buf = buf.subarray(len + 4);
        if (!authed) {
          if (type === 2) {
            if (id === -1) return finish(new Error('RCON: неверный пароль'));
            authed = true;
            send(2, 2, command);
            send(3, 0, ''); // маркер конца ответа
          }
          continue;
        }
        if (id === 2) {
          out.push(body);
          clearTimeout(idle);
          idle = setTimeout(() => finish(null, stripCodes(out.join(''))), 1500);
        } else if (id === 3) {
          finish(null, stripCodes(out.join('')));
        }
      }
    });
  });
}

module.exports = { ping, rcon, stripCodes };
