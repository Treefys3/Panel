#!/usr/bin/env node
'use strict';
// Сброс пароля владельца (если вы его забыли):
//   node tools/owner.js [логин] [новый пароль]
process.removeAllListeners('warning');
const crypto = require('crypto');
const { q } = require('../src/db');
const A = require('../src/auth');

const owner = q.get("SELECT * FROM users WHERE role='owner'");
const login = process.argv[2] || (owner && owner.login) || 'owner';
const pass = process.argv[3] || crypto.randomBytes(12).toString('base64url');
if (!A.validPassword(pass)) { console.error('Пароль: от 8 до 128 символов'); process.exit(1); }
if (owner) {
  q.run('UPDATE users SET login=?, pass_hash=?, disabled=0 WHERE id=?', login, A.hashPassword(pass), owner.id);
  q.run('DELETE FROM sessions WHERE user_id=?', owner.id);
} else {
  q.run('INSERT INTO users(login,pass_hash,role,display_name,servers,created_at) VALUES(?,?,?,?,?,?)', login, A.hashPassword(pass), 'owner', 'Владелец', '*', Date.now());
}
console.log(`Владелец: ${login}\nПароль:   ${pass}`);
