#!/usr/bin/env bash
# Устанавливает панель как systemd-службу (автозапуск, перезапуск при сбое).
# Запуск от root из папки с панелью:  sudo bash tools/install-service.sh
set -e
[ "$(id -u)" = 0 ] || { echo "Запустите от root: sudo bash $0"; exit 1; }
[ -d /run/systemd/system ] || { echo "systemd не найден. Запустите: node server.js (или используйте Docker)."; exit 1; }
DIR="$(cd "$(dirname "$0")/.." && pwd)"
NODE="$(command -v node)" || { echo "Node.js 22.5+ не найден"; exit 1; }
cat > /etc/systemd/system/mc-panel.service <<UNIT
[Unit]
Description=MC Panel
After=network.target

[Service]
WorkingDirectory=$DIR
ExecStart=$NODE $DIR/server.js
Environment=DATA_DIR=$DIR/data
EnvironmentFile=-$DIR/panel.env
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now mc-panel
echo "Готово. Статус: systemctl status mc-panel"
echo "Переменные (PORT, OWNER_PASSWORD, PUBLIC_URL…) можно задать в $DIR/panel.env, затем: systemctl restart mc-panel"
