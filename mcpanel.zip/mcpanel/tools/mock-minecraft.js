#!/usr/bin/env node
'use strict';
/*
 * ТЕСТОВЫЙ эмулятор сервера Minecraft — только для проверки панели без настоящего сервера.
 * Поднимает:
 *   • Server List Ping (порт --port, по умолчанию 25570);
 *   • RCON (порт --rcon-port, по умолчанию 25576, пароль --rcon-password, по умолчанию "secret");
 *   • пишет логи в формате Paper/Vanilla в файл --log (по умолчанию ./mock/logs/latest.log).
 * Команды RCON: list, say, kick, ban, pardon, whitelist add/remove/list/on/off, mute, unmute.
 * Чтобы «сыграть» сценарий: node tools/mock-minecraft.js --script  (игроки заходят, пишут, умирают, выходят)
 */
const net = require('net');
const fs = require('fs');
const path = require('path');

const args = {};
for (let i = 2; i < process.argv.length; i++) {
  const a = process.argv[i];
  if (a.startsWith('--')) args[a.slice(2)] = process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[++i] : 'true';
}
const PORT = Number(args.port || 25570), RPORT = Number(args['rcon-port'] || 25576), RPASS = args['rcon-password'] || 'secret';
const LOG = args.log || path.join(process.cwd(), 'mock', 'logs', 'latest.log');
fs.mkdirSync(path.dirname(LOG), { recursive: true });
if (!fs.existsSync(LOG)) fs.writeFileSync(LOG, '');

const online = new Map(); // name -> ip
const whitelist = new Set();
let wlOn = false;

function stamp() { return new Date().toTimeString().slice(0, 8); }
function w(msg, lvl = 'INFO') { fs.appendFileSync(LOG, `[${stamp()}] [Server thread/${lvl}]: ${msg}\n`); }

// ── Server List Ping ──
const varint = n => { const o = []; n >>>= 0; do { let b = n & 127; n >>>= 7; if (n) b |= 128; o.push(b); } while (n); return Buffer.from(o); };
const pkt = (id, p) => { const b = Buffer.concat([varint(id), p]); return Buffer.concat([varint(b.length), b]); };
function readVar(buf, off) { let n = 0, s = 0, i = off; for (;;) { if (i >= buf.length) return null; const b = buf[i++]; n |= (b & 127) << s; if (!(b & 128)) break; s += 7; } return { v: n, size: i - off }; }
net.createServer(sock => {
  let buf = Buffer.alloc(0);
  sock.on('error', () => {});
  sock.on('data', d => {
    buf = Buffer.concat([buf, d]);
    for (;;) {
      const len = readVar(buf, 0); if (!len || buf.length < len.size + len.v) return;
      const body = buf.subarray(len.size, len.size + len.v); buf = buf.subarray(len.size + len.v);
      const id = readVar(body, 0);
      if (id.v === 0 && body.length > id.size) continue; // handshake
      if (id.v === 0) {
        const json = JSON.stringify({
          version: { name: 'Paper 1.21.4 (mock)', protocol: 769 },
          players: { max: 100, online: online.size, sample: [...online.keys()].map(n => ({ name: n, id: '00000000-0000-0000-0000-000000000000' })) },
          description: { text: '§aТестовый сервер §7(эмулятор)' },
        });
        const s = Buffer.from(json); sock.write(pkt(0, Buffer.concat([varint(s.length), s])));
      } else if (id.v === 1) sock.write(pkt(1, body.subarray(id.size)));
    }
  });
}).listen(PORT, () => console.log('SLP на порту', PORT));

// ── RCON ──
function rconReply(sock, id, type, body) {
  const b = Buffer.from(body, 'utf8'); const p = Buffer.alloc(14 + b.length);
  p.writeInt32LE(10 + b.length, 0); p.writeInt32LE(id, 4); p.writeInt32LE(type, 8); b.copy(p, 12); sock.write(p);
}
function exec(cmd) {
  const [c, ...r] = cmd.trim().split(/\s+/);
  const rest = r.join(' ');
  switch (c) {
    case 'list': return `There are ${online.size} of a max of 100 players online: ${[...online.keys()].join(', ')}`;
    case 'say': w(`[Rcon] ${rest}`); return '';
    case 'ban': { const [n, ...why] = r; w(`[Rcon: Banned ${n}: ${why.join(' ') || 'Banned by an operator.'}]`); return `Banned ${n}: ${why.join(' ')}`; }
    case 'pardon': w(`[Rcon: Unbanned ${r[0]}]`); return `Unbanned ${r[0]}`;
    case 'kick': { const [n, ...why] = r; if (!online.has(n)) return 'No player was found'; online.delete(n); w(`${n} lost connection: Kicked`); w(`${n} left the game`); return `Kicked ${n}: ${why.join(' ')}`; }
    case 'stop': w('Stopping the server'); setTimeout(() => process.exit(0), 300); return 'Stopping the server';
    case 'tellraw': case 'title': case 'gamemode': case 'tp': case 'time': case 'weather': case 'give': case 'op': case 'deop': case 'difficulty': case 'effect': case 'save-all': return 'ok:' + cmd;
    case 'mute': return `Muted ${r[0]}`;
    case 'unmute': return `Unmuted ${r[0]}`;
    case 'msg': case 'tell': return '';
    case 'whitelist': {
      const [sub, n] = r;
      if (sub === 'add') { whitelist.add(n); return `Added ${n} to the whitelist`; }
      if (sub === 'remove') { whitelist.delete(n); return `Removed ${n} from the whitelist`; }
      if (sub === 'list') return whitelist.size ? `There are ${whitelist.size} whitelisted player(s): ${[...whitelist].join(', ')}` : 'There are no whitelisted players';
      if (sub === 'on') { wlOn = true; return 'Whitelist is now turned on'; }
      if (sub === 'off') { wlOn = false; return 'Whitelist is now turned off'; }
      return 'Usage: whitelist <on|off|list|add|remove|reload>';
    }
    default: return `Unknown or incomplete command, see below for error`;
  }
}
net.createServer(sock => {
  let buf = Buffer.alloc(0), authed = false;
  sock.on('error', () => {});
  sock.on('data', d => {
    buf = Buffer.concat([buf, d]);
    while (buf.length >= 4) {
      const len = buf.readInt32LE(0); if (buf.length < len + 4) break;
      const id = buf.readInt32LE(4), type = buf.readInt32LE(8), body = buf.toString('utf8', 12, len + 2);
      buf = buf.subarray(len + 4);
      if (type === 3) { if (body === RPASS) { authed = true; rconReply(sock, id, 2, ''); } else rconReply(sock, -1, 2, ''); }
      else if (type === 2 && authed) rconReply(sock, id, 0, exec(body));
      else if (authed) rconReply(sock, id, 0, `Unknown request ${type}`);
    }
  });
}).listen(RPORT, () => console.log('RCON на порту', RPORT));

function join(name, ip) {
  w(`UUID of player ${name} is 11111111-2222-3333-4444-${String(name.length).padStart(12, '5')}`);
  w(`${name}[/${ip}:51234] logged in with entity id ${Math.floor(Math.random() * 9000 + 100)} at ([world]${(Math.random() * 100).toFixed(1)}, 64.0, ${(Math.random() * 100).toFixed(1)})`);
  w(`${name} joined the game`); online.set(name, ip);
}
function leave(name) { w(`${name} lost connection: Disconnected`); w(`${name} left the game`); online.delete(name); }

w('Starting minecraft server version 1.21.4');
w('Done (4.321s)! For help, type "help"');
if (args.script) {
  const steps = [
    () => join('Steve', '203.0.113.5'), () => join('Alex', '203.0.113.5'), () => join('Notch', '198.51.100.7'),
    () => w('<Steve> привет всем'), () => w('<Alex> как дела?'), () => w('Steve issued server command: /home base'),
    () => w('Alex was slain by Zombie'), () => w('Notch has made the advancement [Stone Age]'),
    () => w('Steve issued server command: /report Alex использует читы, летает'),
    () => w('[Notch: Banned Griefer123: Грифинг]'), () => w('Alex issued server command: /mute Steve 10m'),
    () => w('[12:00:00] something', 'ERROR'), () => leave('Alex'), () => w('<Steve> пока'),
  ];
  let i = 0;
  const t = setInterval(() => { if (i < steps.length) steps[i++](); else clearInterval(t); }, 700);
}
