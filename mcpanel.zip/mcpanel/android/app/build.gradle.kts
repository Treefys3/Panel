plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.mcpanel.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "ru.mcpanel.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.1"
        // Адрес панели встраивается при сборке (-PpanelUrl=https://...): приложение сразу открывает панель.
        val panelUrl = (project.findProperty("panelUrl") as String?).orEmpty().trim().trimEnd('/').replace("\\", "").replace("\"", "")
        buildConfigField("String", "PANEL_URL", "\"$panelUrl\"")
    }

    buildFeatures {
        buildConfig = true
    }

    // Подпись фиксированным ключом из репозитория: новые сборки ставятся поверх старых без удаления приложения.
    // Для личного использования этого достаточно; для публикации в Google Play создайте свой ключ.
    signingConfigs {
        create("panel") {
            storeFile = file("mcpanel.keystore")
            storePassword = "mcpanel123"
            keyAlias = "mcpanel"
            keyPassword = "mcpanel123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("panel")
        }
        debug {
            signingConfig = signingConfigs.getByName("panel")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
}
