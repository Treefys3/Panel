package ru.mcpanel.app

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ContentValues
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * MC Panel для Android.
 * Сам находит панель в локальной сети (ПК, на котором запущены сервер Minecraft и MC Panel):
 * сначала по UDP-запросу, затем перебором адресов подсети. Ничего вводить не нужно.
 * Панель открывается во весь экран и работает так же, как сайт, с теми же данными в реальном времени.
 */
class MainActivity : AppCompatActivity() {

    data class Found(val url: String, val id: String, val name: String)

    private lateinit var web: WebView
    private lateinit var setup: View
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var foundList: LinearLayout
    private lateinit var tips: TextView
    private lateinit var searchAgain: Button
    private lateinit var manualBox: View
    private lateinit var urlInput: EditText
    private lateinit var setupErr: TextView
    private lateinit var connectBtn: Button

    private var base: String? = null
    private var searchGen = 0
    private var opened = false

    private val prefs get() = getSharedPreferences("panel", MODE_PRIVATE)

    companion object {
        const val DISCOVERY_PORT = 45700
        val DEFAULT_PORTS = listOf(3000)
    }

    // Интерфейс, доступный странице панели как window.MCPanelApp
    inner class Bridge {
        @JavascriptInterface
        fun changeServer() {
            runOnUiThread {
                prefs.edit().remove("url").remove("id").apply()
                startSearch(getString(R.string.searching))
            }
        }

        @JavascriptInterface
        fun canChangeServer(): Boolean = true

        @JavascriptInterface
        fun saveFile(name: String, mime: String, b64: String) {
            try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safe)
                        put(MediaStore.Downloads.MIME_TYPE, mime)
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: throw IllegalStateException("no uri")
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                        ?: throw IllegalStateException("no dir")
                    File(dir, safe).writeBytes(bytes)
                }
                runOnUiThread { toast("Файл сохранён: $safe") }
            } catch (e: Exception) {
                runOnUiThread { toast("Не удалось сохранить файл") }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        web = findViewById(R.id.web)
        setup = findViewById(R.id.setup)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        foundList = findViewById(R.id.found_list)
        tips = findViewById(R.id.tips)
        searchAgain = findViewById(R.id.search_again)
        manualBox = findViewById(R.id.manual_box)
        urlInput = findViewById(R.id.url)
        setupErr = findViewById(R.id.setup_err)
        connectBtn = findViewById(R.id.connect)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.setSupportZoom(false)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.userAgentString = s.userAgentString + " MCPanelApp/1.3"
        CookieManager.getInstance().setAcceptCookie(true)
        web.addJavascriptInterface(Bridge(), "MCPanelApp")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val host = uri.host ?: return false
                val own = Uri.parse(base ?: "").host
                // своя панель и вход через Discord остаются внутри приложения, остальное — во внешнем браузере
                if (host == own || host.endsWith("discord.com") || host.endsWith("discordapp.com")) return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (e: Exception) {
                    toast("Не удалось открыть ссылку")
                }
                return true
            }

            override fun onPageFinished(view: WebView, url: String) {
                CookieManager.getInstance().flush()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                // ПК выключили или сменился его адрес в сети — ищем панель заново
                if (request.isForMainFrame) startSearch("Связь с панелью потеряна. Ищу снова…")
            }
        }

        web.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            if (url.startsWith("blob:") || url.startsWith("data:")) {
                toast("Этот файл нельзя скачать в приложении")
            } else {
                try {
                    val req = DownloadManager.Request(Uri.parse(url))
                    req.addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                    req.addRequestHeader("User-Agent", userAgent)
                    req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    req.setDestinationInExternalPublicDir(
                        Environment.DIRECTORY_DOWNLOADS,
                        URLUtil.guessFileName(url, contentDisposition, mimetype)
                    )
                    (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                    toast("Загрузка начата")
                } catch (e: Exception) {
                    toast("Не удалось начать загрузку")
                }
            }
        }

        searchAgain.setOnClickListener { startSearch(getString(R.string.searching)) }
        findViewById<View>(R.id.manual_toggle).setOnClickListener {
            manualBox.visibility = if (manualBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (manualBox.visibility == View.VISIBLE) {
                if (urlInput.text.isNullOrBlank()) urlInput.setText(prefs.getString("url", "") ?: "")
                urlInput.requestFocus()
            }
        }
        connectBtn.setOnClickListener { connectManual() }
        urlInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                connectManual()
                true
            } else false
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    setup.visibility == View.VISIBLE && opened && base != null -> showPanel()
                    web.visibility == View.VISIBLE && web.canGoBack() -> web.goBack()
                    else -> finish()
                }
            }
        })

        startSearch(getString(R.string.searching))
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_LONG).show()

    // ───────────── Поиск панели ─────────────

    private fun startSearch(message: String) {
        val gen = ++searchGen
        web.visibility = View.GONE
        setup.visibility = View.VISIBLE
        status.text = message
        progress.visibility = View.VISIBLE
        tips.visibility = View.GONE
        searchAgain.visibility = View.GONE
        foundList.removeAllViews()
        val savedUrl = prefs.getString("url", null)
        val savedId = prefs.getString("id", null)
        thread {
            // 1) последний адрес (или встроенный при сборке) — открывается мгновенно
            val preferred = listOfNotNull(savedUrl, BuildConfig.PANEL_URL.takeIf { it.isNotBlank() }).distinct()
            for (u in preferred) {
                val f = check(u, 2500)
                if (f != null && (savedId == null || f.id == savedId || u != savedUrl)) {
                    runOnUiThread { if (gen == searchGen) open(f) }
                    return@thread
                }
            }
            // 2) поиск в локальной сети
            val all = discover(savedUrl)
            runOnUiThread {
                if (gen != searchGen) return@runOnUiThread
                val same = all.firstOrNull { it.id == savedId }
                when {
                    same != null -> open(same)
                    all.size == 1 -> open(all[0])
                    all.size > 1 -> showChoice(all)
                    else -> showNotFound()
                }
            }
        }
    }

    private fun showChoice(list: List<Found>) {
        progress.visibility = View.GONE
        status.text = "Найдено несколько панелей — выберите:"
        foundList.removeAllViews()
        for (f in list) {
            val b = Button(this)
            b.text = "${f.name}\n${f.url.removePrefix("http://")}"
            b.isAllCaps = false
            b.setOnClickListener { open(f) }
            foundList.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        searchAgain.visibility = View.VISIBLE
    }

    private fun showNotFound() {
        progress.visibility = View.GONE
        status.text = if (isOnLan()) "Панель не найдена" else "Нет подключения к Wi-Fi"
        tips.visibility = View.VISIBLE
        searchAgain.visibility = View.VISIBLE
    }

    private fun open(f: Found) {
        prefs.edit().putString("url", f.url).putString("id", f.id).apply()
        val changed = base != f.url
        base = f.url
        opened = true
        if (changed || web.url == null) web.loadUrl(f.url) else web.reload()
        showPanel()
    }

    private fun showPanel() {
        setup.visibility = View.GONE
        web.visibility = View.VISIBLE
    }

    // Проверка адреса: это MC Panel? Возвращает её id.
    private fun check(url: String, timeoutMs: Int): Found? {
        return try {
            val c = URL("$url/healthz").openConnection() as HttpURLConnection
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.instanceFollowRedirects = false
            if (c.responseCode != 200) return null
            val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            if (!j.optBoolean("ok")) return null
            val id = j.optString("id", url)
            Found(url, id.ifBlank { url }, Uri.parse(url).host ?: url)
        } catch (e: Exception) {
            null
        }
    }

    private fun isOnLan(): Boolean = localIpv4() != null

    // IPv4-адрес телефона и длина префикса сети
    private fun localIpv4(): Pair<ByteArray, Int>? {
        return try {
            val cm = getSystemService(ConnectivityManager::class.java) ?: return null
            val lp = cm.getLinkProperties(cm.activeNetwork) ?: return null
            lp.linkAddresses.firstOrNull { it.address is Inet4Address && !it.address.isLoopbackAddress }
                ?.let { it.address.address to it.prefixLength }
        } catch (e: Exception) {
            null
        }
    }

    private fun discover(savedUrl: String?): List<Found> {
        val found = ConcurrentHashMap<String, Found>()
        val net = localIpv4()

        // UDP: панель отвечает на «MCPANEL_DISCOVER» своим id, именем и портом
        try {
            DatagramSocket().use { sock ->
                sock.broadcast = true
                sock.soTimeout = 300
                val msg = "MCPANEL_DISCOVER".toByteArray()
                val targets = mutableListOf(InetAddress.getByName("255.255.255.255"))
                if (net != null) {
                    val ip = net.first
                    val mask = if (net.second <= 0) 0 else (-1 shl (32 - net.second))
                    val ipInt = ((ip[0].toInt() and 255) shl 24) or ((ip[1].toInt() and 255) shl 16) or ((ip[2].toInt() and 255) shl 8) or (ip[3].toInt() and 255)
                    val bc = ipInt or mask.inv()
                    targets.add(InetAddress.getByAddress(byteArrayOf((bc ushr 24).toByte(), (bc ushr 16).toByte(), (bc ushr 8).toByte(), bc.toByte())))
                }
                val deadline = System.currentTimeMillis() + 1800
                var nextSend = 0L
                val buf = ByteArray(2048)
                while (System.currentTimeMillis() < deadline) {
                    if (System.currentTimeMillis() >= nextSend) {
                        for (t in targets) try { sock.send(DatagramPacket(msg, msg.size, t, DISCOVERY_PORT)) } catch (e: Exception) { }
                        nextSend = System.currentTimeMillis() + 600
                    }
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        sock.receive(p)
                        val j = JSONObject(String(p.data, 0, p.length))
                        if (j.optInt("mcpanel") == 1) {
                            val host = p.address.hostAddress ?: continue
                            val url = "http://$host:${j.optInt("port", 3000)}"
                            val id = j.optString("id", url)
                            found[id] = Found(url, id, j.optString("name", host))
                        }
                    } catch (e: SocketTimeoutException) {
                    } catch (e: Exception) {
                    }
                }
            }
        } catch (e: Exception) {
        }
        if (found.isNotEmpty() || net == null) return found.values.toList()

        // Запасной путь (если роутер не пропускает широковещательные пакеты): перебор адресов своей подсети /24
        val ports = (DEFAULT_PORTS + listOfNotNull(savedUrl?.let { Uri.parse(it).port }.takeIf { it != null && it > 0 })).distinct()
        val ip = net.first
        val prefix = "${ip[0].toInt() and 255}.${ip[1].toInt() and 255}.${ip[2].toInt() and 255}."
        val pool = Executors.newFixedThreadPool(48)
        for (i in 1..254) for (port in ports) {
            pool.execute {
                val u = "http://$prefix$i:$port"
                check(u, 700)?.let { found[it.id] = it }
            }
        }
        pool.shutdown()
        pool.awaitTermination(15, TimeUnit.SECONDS)
        pool.shutdownNow()
        return found.values.toList()
    }

    // ───────────── Ручной адрес (для подключения через интернет) ─────────────

    private fun normalize(input: String): String {
        var u = input.trim().trimEnd('/')
        if (!u.contains("://")) {
            val local = Regex("^(\\d{1,3}\\.){3}\\d{1,3}(:\\d+)?$").matches(u) ||
                u.startsWith("localhost") || Regex(":\\d+$").containsMatchIn(u)
            u = (if (local) "http://" else "https://") + u
        }
        return u
    }

    private fun connectManual() {
        val url = normalize(urlInput.text.toString())
        if (url.length < 8) {
            setupErr.text = "Введите адрес панели"
            return
        }
        connectBtn.isEnabled = false
        setupErr.text = "Проверяем…"
        val gen = ++searchGen
        thread {
            val f = check(url, 8000)
            runOnUiThread {
                connectBtn.isEnabled = true
                if (gen != searchGen) return@runOnUiThread
                if (f != null) {
                    setupErr.text = ""
                    manualBox.visibility = View.GONE
                    open(f)
                } else {
                    setupErr.text = "По этому адресу MC Panel не отвечает"
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
        web.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        // вернулись в приложение: если ПК сменил адрес или выключался — переподключаемся сами
        val b = base
        if (opened && b != null && web.visibility == View.VISIBLE) {
            val gen = searchGen
            thread {
                if (check(b, 2500) == null) runOnUiThread { if (gen == searchGen) startSearch("Связь с панелью потеряна. Ищу снова…") }
            }
        }
    }
}
