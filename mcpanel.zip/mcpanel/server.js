#!/usr/bin/env node
'use strict';
process.removeAllListeners('warning'); // убираем предупреждение node:sqlite
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { q } = require('./src/db');
const A = require('./src/auth');
const C = require('./src/core');
const { HttpErr } = require('./src/util');

const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = process.env.HOST || '0.0.0.0';
const TRUST_PROXY = process.env.TRUST_PROXY === '1';
const PUBLIC_DIR = path.join(__dirname, 'public');

// ── Первый запуск: создаём владельца ──
function ensureOwner() {
  if (q.get("SELECT 1 x FROM users WHERE role='owner'")) return;
  const login = process.env.OWNER_LOGIN || 'owner';
  let pass = process.env.OWNER_PASSWORD;
  const generated = !pass;
  if (generated) pass = crypto.randomBytes(12).toString('base64url');
  if (!A.validPassword(pass)) { console.error('OWNER_PASSWORD должен быть от 8 до 128 символов'); process.exit(1); }
  q.run('INSERT INTO users(login,pass_hash,role,display_name,servers,created_at) VALUES(?,?,?,?,?,?)', login, A.hashPassword(pass), 'owner', 'Владелец', '*', Date.now());
  console.log('\n══════════════════════════════════════════════');
  console.log(' Создан аккаунт ВЛАДЕЛЬЦА');
  console.log('   Логин:  ' + login);
  console.log('   Пароль: ' + pass + (generated ? '   (сгенерирован, смените после входа)' : ''));
  console.log('══════════════════════════════════════════════\n');
  if (generated) {
    // пароль сохраняется в файл рядом с базой, чтобы его не потерять, если окно консоли закрыли
    try { fs.writeFileSync(path.join(require('./src/db').DATA_DIR, 'ПАРОЛЬ-ВЛАДЕЛЬЦА.txt'), `Логин: ${login}\r\nПароль: ${pass}\r\n\r\nСмените пароль после первого входа и удалите этот файл.\r\n`); } catch { /* */ }
  }
}

// ── Маршрутизатор ──
const routes = [];
function route(method, pattern, opts, handler) {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:([a-z]+)/gi, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, re, keys, opts: opts || {}, handler });
}
require('./src/routes')(route);
require('./src/routes2')(route);
require('./src/routes3')(route);
const X = require('./src/extra');
const L = require('./src/local');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.txt': 'text/plain; charset=utf-8',
};
const SEC_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
};

function clientIp(req) {
  if (TRUST_PROXY) {
    const x = req.headers['x-forwarded-for'];
    if (x) return String(x).split(',')[0].trim();
  }
  return (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
}
function readBody(req, max) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => {
      size += c.length;
      if (size > max) { reject(new HttpErr(413, 'Слишком большой запрос')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { const b = JSON.parse(Buffer.concat(chunks).toString('utf8')); resolve(b && typeof b === 'object' ? b : {}); }
      catch { reject(new HttpErr(400, 'Некорректный JSON')); }
    });
    req.on('error', reject);
  });
}
function send(res, status, body, headers = {}) {
  const buf = Buffer.isBuffer(body) ? body : Buffer.from(typeof body === 'string' ? body : JSON.stringify(body));
  res.writeHead(status, { ...SEC_HEADERS, 'Content-Length': buf.length, ...headers });
  res.end(buf);
}

async function handleApi(req, res, url) {
  const method = req.method;
  let matched = null, params = {};
  for (const r of routes) {
    if (r.method !== method) continue;
    const m = r.re.exec(url.pathname);
    if (m) { matched = r; r.keys.forEach((k, i) => { try { params[k] = decodeURIComponent(m[i + 1]); } catch { params[k] = m[i + 1]; } }); break; }
  }
  if (!matched) {
    const any = routes.some(r => r.re.test(url.pathname));
    return send(res, any ? 405 : 404, { error: any ? 'Метод не поддерживается' : 'Не найдено' }, { 'Content-Type': 'application/json' });
  }
  const { opts } = matched;
  const ip = clientIp(req);
  const cookies = A.parseCookies(req.headers.cookie);
  const ctx = {
    req, res, ip, params, query: Object.fromEntries(url.searchParams), body: {}, user: null, server: null, token: cookies.sid || null,
    setSession(token) {
      const secure = req.headers['x-forwarded-proto'] === 'https' || process.env.COOKIE_SECURE === '1';
      res.setHeader('Set-Cookie', `sid=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${7 * 86400}${secure ? '; Secure' : ''}`);
    },
    clearSession() { res.setHeader('Set-Cookie', 'sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'); },
  };
  try {
    if (opts.auth === 'agent') {
      const m = /^Bearer\s+(\S+)$/.exec(req.headers.authorization || '');
      const s = m && q.get('SELECT * FROM servers WHERE api_key_hash=?', A.sha(m[1]));
      if (!s) throw new HttpErr(401, 'Неверный ключ сервера');
      ctx.server = s;
    } else {
      if (opts.auth !== false) {
        ctx.user = A.userFromToken(ctx.token);
        if (!ctx.user) throw new HttpErr(401, 'Требуется вход');
      }
      if (method !== 'GET') {
        // Защита от CSRF: кастомный заголовок + проверка Origin
        if (req.headers['x-panel'] !== '1') throw new HttpErr(403, 'Запрос отклонён');
        const origin = req.headers.origin;
        if (origin) { let h = ''; try { h = new URL(origin).host; } catch {} if (h !== req.headers.host) throw new HttpErr(403, 'Запрос отклонён'); }
      }
      if (opts.perm && !A.can(ctx.user, opts.perm)) throw new HttpErr(403, 'Недостаточно прав');
      if (opts.server) {
        const s = C.getServer(Number(params.id));
        if (!s || !A.canServer(ctx.user, s.id)) throw new HttpErr(404, 'Сервер не найден');
        ctx.server = s;
      }
    }
    if (method !== 'GET' && method !== 'HEAD') ctx.body = await readBody(req, opts.maxBody || 1024 * 1024);
    const result = await matched.handler(ctx);
    if (ctx.handled) return;
    if (ctx.raw) return send(res, 200, ctx.raw.body, { 'Content-Type': ctx.raw.type, 'Cache-Control': 'no-store', ...(ctx.raw.headers || {}) });
    send(res, 200, result === undefined ? { ok: true } : result, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  } catch (e) {
    if (e instanceof HttpErr) return send(res, e.status, { error: e.message }, { 'Content-Type': 'application/json; charset=utf-8' });
    console.error('[500]', method, url.pathname, e);
    send(res, 500, { error: 'Внутренняя ошибка сервера' }, { 'Content-Type': 'application/json; charset=utf-8' });
  }
}

function serveStatic(req, res, url) {
  let p = decodeURIComponent(url.pathname);
  if (p === '/') p = '/index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, p));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) return send(res, 403, 'Forbidden', { 'Content-Type': 'text/plain' });
  fs.readFile(file, (err, data) => {
    if (err) return send(res, 404, 'Not found', { 'Content-Type': 'text/plain; charset=utf-8' });
    send(res, 200, data, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
  });
}

// ── Установщик агента: curl -fsSL https://панель/install/КЛЮЧ | bash ──
function installScript(req, srv, key) {
  const proto = req.headers['x-forwarded-proto'] || 'http';
  const host = req.headers['x-forwarded-host'] || req.headers.host || 'localhost';
  const panel = (process.env.PUBLIC_URL || `${proto}://${host}`).replace(/\/+$/, '');
  const name = String(srv.name).replace(/[^\w .\-а-яА-ЯёЁ]/g, '');
  return `#!/usr/bin/env bash
# MC Panel — установка агента для сервера «${name}»
set -e
PANEL="${panel}"
KEY="${key}"
ORIG="$PWD"
if ! command -v node >/dev/null 2>&1; then echo "Нужен Node.js 18+ (https://nodejs.org). Установите и запустите команду снова."; exit 1; fi
DIR="\${MC_AGENT_DIR:-$PWD/mc-panel-agent}"
mkdir -p "$DIR"; cd "$DIR"
dl() { if command -v curl >/dev/null 2>&1; then curl -fsSL "$1" -o "$2"; else wget -qO "$2" "$1"; fi; }
dl "$PANEL/agent-dl/agent.js" agent.js
dl "$PANEL/agent-dl/mc.js" mc.js
PROPS=""
if [ -f "$ORIG/server.properties" ]; then PROPS="$ORIG/server.properties"; fi
START=""
if [ -x "$ORIG/start.sh" ]; then START="./start.sh"
else
  JARS=$(ls "$ORIG"/*.jar 2>/dev/null | head -2 | wc -l)
  if [ "$JARS" = "1" ]; then START="java -jar $(basename "$(ls "$ORIG"/*.jar | head -1)") nogui"; fi
fi
cat > agent.config.json <<CFG
{ "panel": "$PANEL", "key": "$KEY", "properties": "$PROPS", "autoUpdate": true, "startCommand": "$START", "startDir": "$ORIG" }
CFG
chmod 600 agent.config.json
cat > run.sh <<'RUN'
#!/usr/bin/env bash
cd "$(dirname "$0")"
while true; do node agent.js --config agent.config.json; sleep 3; done
RUN
chmod +x run.sh
echo "Файлы агента установлены в $DIR"
if [ -z "$PROPS" ]; then echo "ВНИМАНИЕ: server.properties не найден в $ORIG. Откройте $DIR/agent.config.json и впишите \"properties\": \"/путь/к/server.properties\" (или \"log\": \"/путь/к/latest.log\")."; fi
start_bg() {
  nohup ./run.sh > agent.log 2>&1 &
  echo "Агент запущен в фоне (лог: $DIR/agent.log). Остановить: pkill -f 'agent.js --config'"
  echo "Для автозапуска после перезагрузки запустите установку от root на системе с systemd или добавьте $DIR/run.sh в автозагрузку."
}
if [ "$(id -u)" = "0" ] && [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then
  OWNER="$(stat -c %U "$ORIG" 2>/dev/null || echo root)"
  cat > /etc/systemd/system/mc-panel-agent.service <<UNIT
[Unit]
Description=MC Panel agent (${name})
After=network-online.target
[Service]
User=$OWNER
WorkingDirectory=$DIR
ExecStart=$(command -v node) agent.js --config agent.config.json
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
UNIT
  chown -R "$OWNER" "$DIR"
  if systemctl daemon-reload && systemctl enable --now mc-panel-agent; then
    echo "Агент запущен как служба: systemctl status mc-panel-agent"
  else
    echo "Не удалось запустить службу — запускаю в фоне."
    start_bg
  fi
else
  start_bg
fi
`;
}

const server = http.createServer((req, res) => {
  let url;
  try { url = new URL(req.url, 'http://x'); } catch { return send(res, 400, 'Bad request'); }
  if (url.pathname === '/healthz') {
    try { q.get('SELECT 1 x'); return send(res, 200, { ok: true, mcpanel: 1, id: L.instanceId(), uptime: Math.floor(process.uptime()) }, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }); }
    catch { return send(res, 500, { ok: false }, { 'Content-Type': 'application/json' }); }
  }
  if (url.pathname === '/app.apk') {
    // Android-приложение: положите собранный APK в папку данных под именем app.apk
    const f = require('path').join(require('./src/db').DATA_DIR, 'app.apk');
    if (!require('fs').existsSync(f)) return send(res, 404, 'APK не найден', { 'Content-Type': 'text/plain; charset=utf-8' });
    return send(res, 200, require('fs').readFileSync(f), { 'Content-Type': 'application/vnd.android.package-archive', 'Content-Disposition': 'attachment; filename="mc-panel.apk"' });
  }
  let m;
  if ((m = /^\/install\/([\w-]{10,80})$/.exec(url.pathname))) {
    const srv = q.get('SELECT * FROM servers WHERE api_key_hash=?', A.sha(m[1]));
    if (!srv) return send(res, 404, 'Неверный ключ сервера\n', { 'Content-Type': 'text/plain; charset=utf-8' });
    return send(res, 200, installScript(req, srv, m[1]), { 'Content-Type': 'text/x-shellscript; charset=utf-8', 'Cache-Control': 'no-store' });
  }
  if ((m = /^\/agent-dl\/(agent|mc)\.js$/.exec(url.pathname))) {
    return fs.readFile(path.join(__dirname, 'agent', m[1] + '.js'), (e, d) => e ? send(res, 404, 'Not found') : send(res, 200, d, { 'Content-Type': 'application/javascript; charset=utf-8', 'Cache-Control': 'no-store' }));
  }
  if (url.pathname.startsWith('/api/')) {
    handleApi(req, res, url).catch(e => { console.error(e); try { send(res, 500, { error: 'Ошибка' }); } catch {} });
  } else if (req.method === 'GET' || req.method === 'HEAD') {
    serveStatic(req, res, url);
  } else send(res, 405, 'Method not allowed');
});
server.requestTimeout = 0;
server.headersTimeout = 20000;

ensureOwner();
C.startJobs();
X.startExtraJobs();
require('./src/discord').startDiscordJobs();
server.listen(PORT, HOST, () => {
  console.log(`MC Panel запущена: http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}`);
  if (HOST === '0.0.0.0') for (const a of L.lanAddresses()) console.log(`  в локальной сети: http://${a}:${PORT}   (приложение на телефоне найдёт панель само)`);
  L.startDiscovery(PORT);
  L.init(PORT);
});
server.on('error', e => {
  if (e.code === 'EADDRINUSE') console.error(`Порт ${PORT} занят — панель уже запущена или порт занят другой программой. Укажите другой: PORT=3001`);
  else console.error(e);
  process.exit(1);
});

process.on('SIGTERM', () => process.exit(0));
process.on('SIGINT', () => process.exit(0));
