'use strict';
// Локальный режим: панель запущена на том же ПК, что и сервер Minecraft.
//  - сама находит папку сервера (рядом с панелью или указанную в настройках),
//  - включает RCON в server.properties, если он выключен,
//  - создаёт сервер в панели и запускает встроенного агента (логи, чат, консоль, команды, запуск/перезапуск),
//  - отвечает приложениям в локальной сети (UDP-обнаружение), чтобы телефон находил панель без ввода адреса.
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const dgram = require('dgram');
const { spawn } = require('child_process');
const { q, getSetting, setSetting } = require('./db');
const A = require('./auth');

const DISCOVERY_PORT = 45700;
const VERSION_FILE = () => { try { return require('../package.json').version; } catch { return '?'; } };
const log = (...a) => console.log('[локально]', ...a);

const state = { dir: null, serverId: null, agent: null, agentUp: false, rconChanged: false, error: null, port: 3000, stopping: false };

// ── server.properties ──
function readProps(file) {
  const out = {};
  for (const l of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([^#=\s][^=]*?)\s*=\s*(.*)$/.exec(l);
    if (m) out[m[1]] = m[2];
  }
  return out;
}
function writeProps(file, changes) {
  const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
  const left = { ...changes };
  for (let i = 0; i < lines.length; i++) {
    const m = /^\s*([^#=\s][^=]*?)\s*=/.exec(lines[i]);
    if (m && m[1] in left) { lines[i] = `${m[1]}=${left[m[1]]}`; delete left[m[1]]; }
  }
  while (lines.length && lines[lines.length - 1] === '') lines.pop();
  for (const [k, v] of Object.entries(left)) lines.push(`${k}=${v}`);
  fs.writeFileSync(file, lines.join(os.EOL) + os.EOL);
}

const hasProps = d => { try { return fs.statSync(path.join(d, 'server.properties')).isFile(); } catch { return false; } };
function findMcDir() {
  const cands = [process.env.MC_DIR, getSetting('local_mc_dir'), process.cwd(), path.join(process.cwd(), '..'),
    path.join(__dirname, '..', '..'), path.join(__dirname, '..', '..', '..')].filter(Boolean);
  for (const d of cands) if (hasProps(d)) return path.resolve(d);
  // папка панели лежит рядом с папкой сервера: ищем соседей с server.properties
  for (const base of [path.join(__dirname, '..', '..'), path.join(process.cwd(), '..')]) {
    try {
      for (const n of fs.readdirSync(base)) { const d = path.join(base, n); if (hasProps(d)) return path.resolve(d); }
    } catch { /* нет доступа */ }
  }
  return null;
}

function detectStart(dir) {
  const win = process.platform === 'win32';
  const scripts = win ? ['start.bat', 'run.bat', 'start.cmd', 'run.cmd', 'launch.bat'] : ['start.sh', 'run.sh', 'launch.sh'];
  for (const s of scripts) if (fs.existsSync(path.join(dir, s))) return win ? `"${s}"` : `./${s}`;
  let jars = [];
  try { jars = fs.readdirSync(dir).filter(f => /\.jar$/i.test(f) && !/installer/i.test(f)); } catch { /* */ }
  const pick = jars.length === 1 ? jars[0] : jars.find(j => /server|paper|purpur|spigot|fabric|forge|minecraft/i.test(j));
  return pick ? `java -Xms1G -Xmx${process.env.MC_MEMORY || '2G'} -jar "${pick}" nogui` : '';
}

// Включает RCON с надёжным паролем; возвращает true, если файл пришлось изменить (нужен перезапуск Minecraft)
function ensureRcon(file) {
  const p = readProps(file);
  const ch = {};
  if (p['enable-rcon'] !== 'true') ch['enable-rcon'] = 'true';
  if (!p['rcon.password'] || p['rcon.password'].length < 8) ch['rcon.password'] = crypto.randomBytes(15).toString('base64url');
  if (!p['rcon.port']) ch['rcon.port'] = '25575';
  if (!Object.keys(ch).length) return false;
  writeProps(file, ch);
  return true;
}

// ── сервер в панели ──
function ensureServer(dir) {
  const props = readProps(path.join(dir, 'server.properties'));
  let id = Number(getSetting('local_server_id') || 0);
  let s = id ? q.get('SELECT * FROM servers WHERE id=?', id) : null;
  let key = getSetting('local_agent_key');
  if (!s) {
    key = 'mcp_' + crypto.randomBytes(24).toString('base64url');
    const name = (props['level-name'] && props['level-name'] !== 'world' ? props['level-name'] : 'Мой сервер').slice(0, 40);
    const r = q.run('INSERT INTO servers(name,host,port,api_key_hash,api_key_hint,rcon_mode,color,created_at) VALUES(?,?,?,?,?,?,?,?)',
      name, '127.0.0.1', Number(props['server-port'] || 25565), A.sha(key), key.slice(-4), 'agent', '#3fb950', Date.now());
    id = Number(r.lastInsertRowid);
    try { require('./extra').createDefaultRules(id); } catch { /* */ }
    setSetting('local_server_id', String(id));
    setSetting('local_agent_key', key);
    A.audit(null, 'server.create', name, { via: 'local' });
    log(`Сервер «${name}» добавлен в панель автоматически`);
  } else if (!key || s.api_key_hash !== A.sha(key)) {
    // ключ сменили в панели — выпускаем новый для встроенного агента
    key = 'mcp_' + crypto.randomBytes(24).toString('base64url');
    q.run('UPDATE servers SET api_key_hash=?, api_key_hint=? WHERE id=?', A.sha(key), key.slice(-4), id);
    setSetting('local_agent_key', key);
  }
  return { id, key };
}

// ── встроенный агент ──
let restartTimer = null;
function startAgent() {
  if (state.stopping || !state.dir) return;
  const { id, key } = ensureServer(state.dir);
  state.serverId = id;
  const props = path.join(state.dir, 'server.properties');
  const startCmd = getSetting('local_start_cmd') || detectStart(state.dir);
  const args = [path.join(__dirname, '..', 'agent', 'agent.js'), '--panel', `http://127.0.0.1:${state.port}`, '--key', key, '--properties', props];
  if (startCmd) args.push('--start-command', startCmd);
  const child = spawn(process.execPath, args, { cwd: state.dir, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  state.agent = child;
  const pipe = s => s.on('data', b => { for (const l of String(b).split(/\r?\n/)) if (l.trim()) console.log('[агент]', l); });
  pipe(child.stdout); pipe(child.stderr);
  child.on('exit', code => {
    state.agent = null;
    if (state.stopping) return;
    log(`агент остановился (код ${code}), перезапуск через 5 секунд`);
    clearTimeout(restartTimer); restartTimer = setTimeout(startAgent, 5000);
  });
}
function stopAgent() { clearTimeout(restartTimer); if (state.agent) { const a = state.agent; state.agent = null; a.removeAllListeners('exit'); a.kill(); } }

function init(port) {
  state.port = port;
  state.error = null;
  if (process.env.LOCAL_MODE === '0' || getSetting('local_off') === '1') { log('локальный режим выключен'); return; }
  const dir = findMcDir();
  if (!dir) { state.error = 'Папка сервера Minecraft не найдена'; log('папка сервера Minecraft не найдена — укажите её в панели: Система → Сервер на этом ПК'); return; }
  state.dir = dir;
  try { state.rconChanged = ensureRcon(path.join(dir, 'server.properties')); }
  catch (e) { state.error = 'Не удалось изменить server.properties: ' + e.message; }
  log('папка сервера Minecraft: ' + dir);
  if (state.rconChanged) log('RCON включён в server.properties — перезапустите сервер Minecraft один раз, чтобы команды из панели заработали');
  startAgent();
}

function setDir(dir) {
  dir = String(dir || '').trim().replace(/^"|"$/g, '');
  if (!dir) throw Object.assign(new Error('Укажите папку'), { status: 400 });
  if (!hasProps(dir)) throw Object.assign(new Error('В этой папке нет server.properties. Укажите папку, где лежит сервер Minecraft (запустите его хотя бы один раз)'), { status: 400 });
  setSetting('local_mc_dir', path.resolve(dir));
  setSetting('local_off', '0');
  stopAgent();
  state.dir = null;
  init(state.port);
}
function turnOff() { setSetting('local_off', '1'); stopAgent(); state.dir = null; }

function lanAddresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) for (const a of list || []) {
    if (a.family === 'IPv4' && !a.internal && !/^169\.254\./.test(a.address)) out.push(a.address);
  }
  return out;
}

// предупреждение «перезапустите Minecraft» снимается, как только RCON ответил
async function recheckRcon() {
  if (!state.rconChanged || !state.dir) return;
  try {
    const p = readProps(path.join(state.dir, 'server.properties'));
    await require('../agent/mc').rcon('127.0.0.1', Number(p['rcon.port'] || 25575), p['rcon.password'], 'list', 2500);
    state.rconChanged = false;
  } catch { /* Minecraft ещё не перезапущен */ }
}
function status() {
  return {
    on: !!state.dir, dir: state.dir, server_id: state.serverId, agent_running: !!state.agent, rcon_changed: state.rconChanged, error: state.error,
    start_cmd: getSetting('local_start_cmd') || (state.dir ? detectStart(state.dir) : ''), lan: lanAddresses().map(a => `http://${a}:${state.port}`),
  };
}

// ── обнаружение в локальной сети ──
function instanceId() {
  let id = getSetting('instance_id');
  if (!id) { id = crypto.randomBytes(8).toString('hex'); setSetting('instance_id', id); }
  return id;
}
function startDiscovery(port) {
  if (process.env.DISCOVERY === '0') return;
  const sock = dgram.createSocket({ type: 'udp4', reuseAddr: true });
  sock.on('error', e => { log('обнаружение в сети недоступно: ' + e.message); try { sock.close(); } catch { /* */ } });
  sock.on('message', (msg, rinfo) => {
    if (String(msg).trim() !== 'MCPANEL_DISCOVER') return;
    const reply = JSON.stringify({ mcpanel: 1, id: instanceId(), name: getSetting('panel_name') || os.hostname(), port, version: VERSION_FILE() });
    sock.send(reply, rinfo.port, rinfo.address);
  });
  sock.bind(DISCOVERY_PORT, () => { try { sock.setBroadcast(true); } catch { /* */ } });
}

function shutdown() { state.stopping = true; stopAgent(); }
process.on('exit', shutdown); // server.js завершает процесс по SIGINT/SIGTERM — агент останавливается вместе с панелью

module.exports = { recheckRcon, init, setDir, turnOff, status, startDiscovery, lanAddresses, instanceId, DISCOVERY_PORT, readProps, writeProps, detectStart };
