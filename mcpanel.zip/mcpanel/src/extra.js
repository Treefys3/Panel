'use strict';
// Расширенные функции: автомодерация, планировщик команд, вебхуки (Discord/Telegram), резервные копии.
const fs = require('fs');
const path = require('path');
const dns = require('dns').promises;
const net = require('net');
const { db, q, DATA_DIR, getSetting, setSetting } = require('./db');
const C = require('./core');
const { audit } = require('./auth');
const { HttpErr, clean } = require('./util');

const now = () => Date.now();
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ═════════════ Вебхуки ═════════════ */
const WEBHOOK_EVENTS = {
  report: 'Новые репорты', ban: 'Баны', server: 'Сервер в сети / недоступен', automod: 'Срабатывания автомодерации',
};
const KIND_TO_EVENT = { report: 'report', punish: 'ban', server: 'server', automod: 'automod' };

function publicUrl() { return (process.env.PUBLIC_URL || getSetting('public_url') || '').replace(/\/+$/, ''); }

function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
  }
  const l = ip.toLowerCase();
  return l === '::1' || l === '::' || l.startsWith('fc') || l.startsWith('fd') || l.startsWith('fe80') || l.startsWith('::ffff:127.') || l.startsWith('::ffff:10.') || l.startsWith('::ffff:192.168.');
}
async function checkUrl(u) {
  let url;
  try { url = new URL(u); } catch { throw new HttpErr(400, 'Некорректный адрес вебхука'); }
  if (!['http:', 'https:'].includes(url.protocol)) throw new HttpErr(400, 'Адрес должен начинаться с http:// или https://');
  if (process.env.ALLOW_PRIVATE_WEBHOOKS === '1') return url;
  let addrs;
  try { addrs = await dns.lookup(url.hostname, { all: true }); } catch { throw new HttpErr(400, 'Не удаётся определить адрес вебхука (проверьте домен)'); }
  if (addrs.some(a => isPrivateIp(a.address))) throw new HttpErr(400, 'Вебхуки на внутренние адреса запрещены');
  return url;
}

async function sendWebhook(w, n) {
  const link = n.link && publicUrl() ? publicUrl() + '/' + n.link : '';
  const text = `${n.title}${n.body ? '\n' + n.body : ''}${link ? '\n' + link : ''}`;
  let res;
  if (w.type === 'telegram') {
    res = await fetch(`https://api.telegram.org/bot${w.token}/sendMessage`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: AbortSignal.timeout(10000),
      body: JSON.stringify({ chat_id: w.chat_id, text: text.slice(0, 4000), disable_web_page_preview: true }),
    });
  } else {
    await checkUrl(w.url);
    const body = w.type === 'discord'
      ? { username: 'MC Panel', content: `**${n.title}**${n.body ? '\n' + n.body : ''}${link ? '\n' + link : ''}`.slice(0, 1900) }
      : { kind: n.kind, title: n.title, body: n.body || null, server_id: n.serverId || null, link: link || null, ts: n.ts };
    res = await fetch(w.url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(10000) });
  }
  if (!res.ok) throw new Error('HTTP ' + res.status);
}
async function deliver(w, n) {
  let status = 'ok';
  try { await sendWebhook(w, n); } catch (e) { status = 'ошибка: ' + e.message; }
  q.run('UPDATE webhooks SET last_status=?, last_at=? WHERE id=?', status, now(), w.id);
  return status;
}
C.hooks.notify = n => {
  const ev = KIND_TO_EVENT[n.kind];
  if (!ev) return;
  for (const w of q.all('SELECT * FROM webhooks WHERE enabled=1')) {
    let evs = []; try { evs = JSON.parse(w.events); } catch {}
    if (evs.includes(ev)) deliver(w, n).catch(() => {});
  }
};

/* ═════════════ Автомодерация ═════════════ */
const RULE_TYPES = {
  words: 'Запрещённые слова', caps: 'Капс', ads: 'Реклама и IP-адреса', spam: 'Флуд и повторы',
  ban_evasion: 'Обход бана (общий IP с забаненным)', commands: 'Слежение за командами',
};
const ACTIONS = ['notify', 'warn', 'mute', 'kick', 'ban'];
const AD_RE = /(?:\b\d{1,3}(?:\.\d{1,3}){3}(?::\d{2,5})?\b|https?:\/\/|\b[a-z0-9-]{2,}\.(?:ru|com|net|org|io|gg|me|su|xyz|club|fun|ml|tk|ua|by|kz|pro|online|site|tech|co|top|cc)\b)/i;
const PSEUDO = { id: null, login: 'automod', display_name: 'Автомодерация' };
const hist = new Map();
const cooldown = new Map();
let staffCache = { t: 0, set: new Set() };
function staffNicks() {
  if (now() - staffCache.t > 30000) {
    staffCache = { t: now(), set: new Set(q.all("SELECT mc_nick FROM users WHERE mc_nick IS NOT NULL AND mc_nick<>'' AND disabled=0").map(r => r.mc_nick.toLowerCase())) };
  }
  return staffCache.set;
}
function cfgOf(r) { try { return JSON.parse(r.config || '{}'); } catch { return {}; } }

// Проверка текстовых правил (без состояния). Возвращает описание нарушения или null
function textMatch(rule, text) {
  const c = cfgOf(rule), t = String(text || '');
  if (rule.type === 'words') {
    const words = (c.words || []).map(w => String(w).toLowerCase()).filter(Boolean);
    const low = t.toLowerCase();
    for (const w of words) {
      if (c.mode === 'word') {
        const re = new RegExp('(^|[^\\p{L}\\p{N}])' + w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '($|[^\\p{L}\\p{N}])', 'iu');
        if (re.test(t)) return `слово «${w}»`;
      } else if (low.includes(w)) return `слово «${w}»`;
    }
    return null;
  }
  if (rule.type === 'caps') {
    const letters = t.replace(/[^\p{L}]/gu, '');
    const min = c.min_len || 8, pct = c.percent || 70;
    if (letters.length >= min) {
      const up = letters.replace(/[^\p{Lu}]/gu, '').length;
      if ((up / letters.length) * 100 >= pct) return `капс (${Math.round((up / letters.length) * 100)}%)`;
    }
    return null;
  }
  if (rule.type === 'ads') {
    const m = AD_RE.exec(t);
    if (!m) return null;
    const allow = (c.allow || []).map(a => String(a).toLowerCase());
    if (allow.some(a => m[0].toLowerCase().includes(a))) return null;
    return `реклама/адрес «${m[0]}»`;
  }
  return null;
}

function fire(server, rule, player, detail, ts) {
  q.run('UPDATE automod_rules SET hits=hits+1, last_hit=? WHERE id=?', now(), rule.id);
  C.insertEvent(server.id, ts || now(), 'automod', player, `«${rule.name}»: ${detail}`, { rule: rule.id, action: rule.action });
  C.broadcast('events', {}, server.id);
  C.notify('automod', `Автомодерация · ${server.name}`, `${player}: «${rule.name}» — ${detail}`, server.id, `#/s/${server.id}/players/${encodeURIComponent(player)}`);
  if (rule.action !== 'notify') {
    C.applyPunishment(PSEUDO, server, { player, type: rule.action, reason: rule.reason || `Автомодерация: ${rule.name}`, duration: rule.duration })
      .catch(e => console.error('[automod action]', e.message));
  }
}

C.hooks.event = (server, ev) => {
  const rules = q.all('SELECT * FROM automod_rules WHERE server_id=? AND enabled=1', server.id);
  if (!rules.length) return;
  const lowName = ev.player.toLowerCase();
  const isStaff = staffNicks().has(lowName);
  const t = now();
  for (const r of rules) {
    let detail = null;
    const c = cfgOf(r);
    if (ev.type === 'chat' && ['words', 'caps', 'ads'].includes(r.type)) {
      if (isStaff) continue;
      detail = textMatch(r, ev.message);
    } else if (ev.type === 'chat' && r.type === 'spam') {
      if (isStaff) continue;
      const key = server.id + '|' + lowName;
      const arr = (hist.get(key) || []).filter(x => t - x.ts < 60000);
      arr.push({ ts: t, msg: String(ev.message || '').toLowerCase() });
      hist.set(key, arr);
      const n = c.messages || 5, secs = (c.seconds || 6) * 1000;
      const recent = arr.filter(x => t - x.ts <= secs);
      if (recent.length >= n) detail = `${recent.length} сообщений за ${c.seconds || 6} с`;
      else if (arr.filter(x => x.msg === arr[arr.length - 1].msg && t - x.ts <= 30000).length >= 3 && arr[arr.length - 1].msg.length > 1) detail = 'одинаковое сообщение 3 раза подряд';
    } else if (ev.type === 'command' && r.type === 'commands') {
      const cmd = String(ev.message || '').replace(/^\//, '').split(/\s+/)[0].toLowerCase().replace(/^[\w.-]+:/, '');
      if ((c.commands || []).map(x => String(x).toLowerCase().replace(/^\//, '')).includes(cmd)) detail = `команда ${ev.message}`;
    } else if (ev.type === 'join' && r.type === 'ban_evasion') {
      const hit = q.get(`SELECT p2.name AS other FROM players p1 JOIN player_ips a ON a.player_id=p1.id JOIN player_ips b ON b.ip=a.ip AND b.server_id=a.server_id AND b.player_id<>a.player_id
        JOIN players p2 ON p2.id=b.player_id WHERE p1.server_id=? AND p1.name=? AND EXISTS(SELECT 1 FROM punishments x WHERE x.server_id=p1.server_id AND x.player=p2.name AND x.type='ban' AND x.active=1) LIMIT 1`, server.id, ev.player);
      if (hit) detail = `общий IP с забаненным ${hit.other}`;
    }
    if (!detail) continue;
    const ck = r.id + '|' + lowName;
    if (t - (cooldown.get(ck) || 0) < (r.type === 'ban_evasion' ? 300000 : 30000)) continue;
    cooldown.set(ck, t);
    fire(server, r, ev.player, detail, ev.ts);
  }
};
setInterval(() => { const t = now(); for (const [k, v] of cooldown) if (t - v > 600000) cooldown.delete(k); for (const [k, a] of hist) if (!a.length || t - a[a.length - 1].ts > 120000) hist.delete(k); }, 60000).unref();

// Проверка текста на всех текстовых правилах сервера (кнопка «Проверить фразу»)
function dryRun(serverId, text) {
  return q.all('SELECT * FROM automod_rules WHERE server_id=?', serverId)
    .filter(r => ['words', 'caps', 'ads'].includes(r.type))
    .map(r => ({ id: r.id, name: r.name, enabled: !!r.enabled, match: textMatch(r, text) })).filter(x => x.match);
}

function createDefaultRules(serverId) {
  const add = (name, type, config, action = 'notify') => q.run('INSERT INTO automod_rules(server_id,name,type,enabled,config,action) VALUES(?,?,?,?,?,?)', serverId, name, type, 1, JSON.stringify(config), action);
  add('Реклама и IP-адреса в чате', 'ads', { allow: [] });
  add('Флуд в чате', 'spam', { messages: 5, seconds: 6 });
  add('Обход бана (общий IP)', 'ban_evasion', {});
  add('Опасные команды', 'commands', { commands: ['op', 'deop', 'gamemode', 'give', 'execute', 'stop'] });
}

function readRule(b, partial) {
  const o = {};
  if (!partial || b.name !== undefined) { o.name = clean(b.name, 60); if (!o.name) throw new HttpErr(400, 'Укажите название правила'); }
  if (!partial || b.type !== undefined) { if (!RULE_TYPES[b.type]) throw new HttpErr(400, 'Неизвестный тип правила'); o.type = b.type; }
  if (b.enabled !== undefined) o.enabled = b.enabled ? 1 : 0;
  if (b.action !== undefined) { if (!ACTIONS.includes(b.action)) throw new HttpErr(400, 'Неизвестное действие'); o.action = b.action; }
  if (b.duration !== undefined) o.duration = b.duration ? Math.min(Number(b.duration) || 0, 315360000) || null : null;
  if (b.reason !== undefined) o.reason = clean(b.reason, 200) || null;
  if (b.config !== undefined) {
    const c = b.config || {}, type = o.type || b.type;
    const cfg = {};
    if (type === 'words') {
      cfg.words = (Array.isArray(c.words) ? c.words : String(c.words || '').split(/[\n,]+/)).map(w => clean(w, 40)).filter(Boolean).slice(0, 500);
      cfg.mode = c.mode === 'word' ? 'word' : 'contains';
      if (!cfg.words.length) throw new HttpErr(400, 'Добавьте хотя бы одно слово');
    } else if (type === 'caps') {
      cfg.min_len = Math.min(100, Math.max(3, parseInt(c.min_len, 10) || 8)); cfg.percent = Math.min(100, Math.max(30, parseInt(c.percent, 10) || 70));
    } else if (type === 'ads') {
      cfg.allow = (Array.isArray(c.allow) ? c.allow : String(c.allow || '').split(/[\n,\s]+/)).map(w => clean(w, 60)).filter(Boolean).slice(0, 100);
    } else if (type === 'spam') {
      cfg.messages = Math.min(30, Math.max(3, parseInt(c.messages, 10) || 5)); cfg.seconds = Math.min(60, Math.max(2, parseInt(c.seconds, 10) || 6));
    } else if (type === 'commands') {
      cfg.commands = (Array.isArray(c.commands) ? c.commands : String(c.commands || '').split(/[\n,\s]+/)).map(w => clean(w, 40).replace(/^\//, '').toLowerCase()).filter(Boolean).slice(0, 100);
      if (!cfg.commands.length) throw new HttpErr(400, 'Добавьте хотя бы одну команду');
    }
    o.config = JSON.stringify(cfg);
  }
  return o;
}

/* ═════════════ Планировщик ═════════════ */
const running = new Set();
function readSchedule(b, partial) {
  const o = {};
  if (!partial || b.name !== undefined) { o.name = clean(b.name, 60); if (!o.name) throw new HttpErr(400, 'Укажите название задачи'); }
  if (b.enabled !== undefined) o.enabled = b.enabled ? 1 : 0;
  if (!partial || b.kind !== undefined) { if (!['interval', 'daily'].includes(b.kind)) throw new HttpErr(400, 'Неверный тип расписания'); o.kind = b.kind; }
  const kind = o.kind || b.kind;
  if (kind === 'interval' && (!partial || b.every_min !== undefined)) {
    const n = parseInt(b.every_min, 10);
    if (!(n >= 1 && n <= 10080)) throw new HttpErr(400, 'Интервал: от 1 до 10080 минут');
    o.every_min = n;
  }
  if (kind === 'daily' && (!partial || b.at_time !== undefined)) {
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(String(b.at_time))) throw new HttpErr(400, 'Время в формате ЧЧ:ММ');
    o.at_time = b.at_time;
  }
  if (b.days !== undefined) {
    const d = (Array.isArray(b.days) ? b.days : String(b.days).split(',')).map(Number).filter(n => n >= 1 && n <= 7);
    if (!d.length) throw new HttpErr(400, 'Выберите хотя бы один день');
    o.days = [...new Set(d)].sort().join(',');
  }
  if (!partial || b.commands !== undefined) {
    const cmds = String(b.commands || '').split('\n').map(x => x.trim().replace(/^\//, '')).filter(Boolean);
    if (!cmds.length) throw new HttpErr(400, 'Добавьте хотя бы одну команду');
    if (cmds.length > 20 || cmds.some(x => x.length > 500)) throw new HttpErr(400, 'Не больше 20 команд, каждая до 500 символов');
    o.commands = cmds.join('\n');
  }
  return o;
}
function nextRunFor(s, from = now()) { return s.kind === 'interval' ? from + s.every_min * 60000 : null; }

async function runSchedule(s) {
  if (running.has(s.id)) return 'уже выполняется';
  running.add(s.id);
  let result;
  try {
    const server = C.getServer(s.server_id);
    const cmds = s.commands.split('\n').filter(Boolean);
    if (!server) result = 'сервер удалён';
    else if (!server.online) result = 'пропущено: сервер недоступен';
    else if (!C.canCommand(server)) result = 'пропущено: нет связи для команд (агент/RCON)';
    else {
      let ok = 0, err = '';
      for (const c of cmds) {
        const r = await C.runCommand(server, c);
        if (r.ok) ok++; else if (!err) err = r.error;
        if (cmds.length > 1) await sleep(1000);
      }
      result = `выполнено ${ok}/${cmds.length}` + (err ? ` · ${err}` : '');
    }
  } catch (e) { result = 'ошибка: ' + e.message; }
  q.run('UPDATE schedules SET last_run=?, last_result=?, next_run=? WHERE id=?', now(), result, nextRunFor(s), s.id);
  running.delete(s.id);
  return result;
}
function dueSchedule(s, t) {
  if (s.kind === 'interval') return !!s.next_run && s.next_run <= t;
  const [hh, mm] = String(s.at_time).split(':').map(Number);
  const d = new Date(t); d.setHours(hh, mm, 0, 0);
  const trig = d.getTime();
  const dow = ((new Date(t).getDay() + 6) % 7) + 1;
  return s.days.split(',').includes(String(dow)) && t >= trig && t - trig < 10 * 60000 && (!s.last_run || s.last_run < trig);
}
function schedulerTick() {
  const t = now();
  for (const s of q.all('SELECT * FROM schedules WHERE enabled=1')) {
    if (dueSchedule(s, t)) runSchedule(s).catch(e => console.error('[scheduler]', e.message));
  }
}

/* ═════════════ Резервные копии ═════════════ */
const BK_DIR = path.join(DATA_DIR, 'backups');
function listBackups() {
  try {
    return fs.readdirSync(BK_DIR).filter(f => /^panel-[\d-]+\.db$/.test(f)).map(f => {
      const st = fs.statSync(path.join(BK_DIR, f));
      return { name: f, size: st.size, ts: st.mtimeMs };
    }).sort((a, b) => b.ts - a.ts);
  } catch { return []; }
}
function createBackup() {
  fs.mkdirSync(BK_DIR, { recursive: true });
  const d = new Date(), p2 = n => String(n).padStart(2, '0');
  const name = `panel-${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}${p2(d.getSeconds())}.db`;
  const file = path.join(BK_DIR, name);
  db.exec(`VACUUM INTO '${file.replace(/'/g, "''")}'`);
  const keep = Math.max(1, parseInt(getSetting('backup_keep', '7'), 10) || 7);
  for (const b of listBackups().slice(keep)) { try { fs.unlinkSync(path.join(BK_DIR, b.name)); } catch {} }
  return name;
}
function backupFile(name) {
  if (!/^panel-[\d-]+\.db$/.test(name)) throw new HttpErr(404, 'Копия не найдена');
  const f = path.join(BK_DIR, name);
  if (!fs.existsSync(f)) throw new HttpErr(404, 'Копия не найдена');
  return f;
}
function backupTick() {
  const last = listBackups()[0];
  if (!last || now() - last.ts > 24 * 3600 * 1000) { try { createBackup(); console.log('[backup] создана резервная копия'); } catch (e) { console.error('[backup]', e.message); } }
}

function startExtraJobs() {
  setInterval(schedulerTick, 15000).unref();
  setInterval(backupTick, 3600 * 1000).unref();
  setTimeout(backupTick, 20000).unref();
  // у задач «каждые N минут», созданных до перезапуска, нет next_run — не копим пропущенное
  const t = now();
  for (const s of q.all("SELECT * FROM schedules WHERE kind='interval' AND enabled=1 AND (next_run IS NULL OR next_run<?)", t)) q.run('UPDATE schedules SET next_run=? WHERE id=?', nextRunFor(s, t), s.id);
}

module.exports = {
  WEBHOOK_EVENTS, RULE_TYPES, ACTIONS, checkUrl, deliver, publicUrl, readRule, dryRun, createDefaultRules,
  readSchedule, nextRunFor, runSchedule, listBackups, createBackup, backupFile, startExtraJobs, setSetting, getSetting,
};
