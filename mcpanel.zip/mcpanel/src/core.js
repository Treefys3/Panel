'use strict';
const { q, tx, getSetting } = require('./db');
const { canServer, audit } = require('./auth');
const { HttpErr, clean, fmtDur, validName, NAME_RE } = require('./util');
const mc = require('../agent/mc');

const now = () => Date.now();
const hooks = {}; // onNotify / onEvent — подключаются из extra.js

// ───────────── Реалтайм (SSE) ─────────────
const clients = new Set();
function sseAdd(res, user) {
  const c = { res, user };
  clients.add(c);
  res.on('close', () => clients.delete(c));
}
function broadcast(type, payload = {}, serverId = null) {
  const msg = `data: ${JSON.stringify({ t: type, server: serverId, ...payload })}\n\n`;
  for (const c of clients) {
    if (serverId != null && !canServer(c.user, serverId)) continue;
    try { c.res.write(msg); } catch { /* клиент отвалился */ }
  }
}
setInterval(() => { for (const c of clients) { try { c.res.write(': ping\n\n'); } catch {} } }, 25000).unref();

function notify(kind, title, body, serverId, link) {
  const r = q.run('INSERT INTO notifications(ts,kind,title,body,server_id,link) VALUES(?,?,?,?,?,?)',
    now(), kind, title, body || null, serverId || null, link || null);
  broadcast('notif', { id: Number(r.lastInsertRowid) }, serverId || null);
  if (hooks.notify) { try { hooks.notify({ kind, title, body, serverId, link, ts: now() }); } catch (e) { console.error('[notify hook]', e.message); } }
}

// ───────────── Серверы ─────────────
const DEFAULT_TEMPLATES = {
  ban: 'ban {player} {reason}',
  unban: 'pardon {player}',
  kick: 'kick {player} {reason}',
  mute: 'mute {player} {duration} {reason}',
  unmute: 'unmute {player}',
  warn: 'msg {player} [Предупреждение] {reason}',
  whitelist_add: 'whitelist add {player}',
  whitelist_remove: 'whitelist remove {player}',
};
function getServer(id) { return q.get('SELECT * FROM servers WHERE id=?', id); }
function templatesOf(s) {
  let t = {};
  try { t = JSON.parse(s.templates || '{}'); } catch {}
  return { ...DEFAULT_TEMPLATES, ...t };
}
function agentAlive(s) { return !!s.last_agent && now() - s.last_agent < 45000; }
function canCommand(s) {
  if (s.rcon_mode === 'direct') return !!(s.host && s.rcon_port && s.rcon_password);
  return agentAlive(s) && !!s.agent_rcon;
}
function publicServer(s) {
  return {
    id: s.id, name: s.name, host: s.host, port: s.port, rcon_mode: s.rcon_mode, rcon_port: s.rcon_port,
    has_rcon_password: !!s.rcon_password, templates: templatesOf(s), color: s.color, icon: s.icon,
    online: !!s.online, players_online: s.players_online, players_max: s.players_max, version: s.version, motd: s.motd,
    latency: s.latency, last_check: s.last_check, last_agent: s.last_agent, agent_alive: agentAlive(s),
    agent_rcon: !!s.agent_rcon, agent_version: s.agent_version, api_key_hint: s.api_key_hint,
    can_command: canCommand(s), created_at: s.created_at,
  };
}
function visibleServers(user) { return q.all('SELECT * FROM servers ORDER BY id').filter(s => canServer(user, s.id)); }
function totalOnline(user) { return visibleServers(user).reduce((a, s) => a + (s.online ? s.players_online : 0), 0); }

// ───────────── Выполнение команд (RCON напрямую или через агента) ─────────────
const cmdWaiters = new Map();
const agentPollers = new Map();

async function runCommand(server, command) {
  command = String(command).replace(/[\r\n\0]/g, ' ').trim().slice(0, 500);
  if (!command) return { ok: false, error: 'Пустая команда' };
  if (server.rcon_mode === 'direct' && command.startsWith('@@')) return { ok: false, error: 'Запуск и перезапуск работают только через агента' };
  if (server.rcon_mode === 'direct') {
    if (!(server.host && server.rcon_port && server.rcon_password)) return { ok: false, error: 'RCON не настроен для этого сервера' };
    try { return { ok: true, response: await mc.rcon(server.host, server.rcon_port, server.rcon_password, command) }; }
    catch (e) { return { ok: false, error: e.message }; }
  }
  if (!agentAlive(server)) return { ok: false, error: 'Агент сервера не подключён' };
  if (!server.agent_rcon && !command.startsWith('@@')) return { ok: false, error: 'Агент подключён без RCON — укажите RCON в настройках агента' };
  const r = q.run('INSERT INTO commands(server_id,command,created_at) VALUES(?,?,?)', server.id, command, now());
  const id = Number(r.lastInsertRowid);
  const p = new Promise(res => {
    cmdWaiters.set(id, res);
    setTimeout(() => {
      if (cmdWaiters.delete(id)) {
        q.run("UPDATE commands SET status='timeout' WHERE id=? AND status<>'done'", id);
        res({ ok: false, error: 'Агент не ответил за 15 секунд' });
      }
    }, 15000).unref();
  });
  const w = agentPollers.get(server.id);
  if (w) { clearTimeout(w.timer); agentPollers.delete(server.id); w.resolve(); }
  return p;
}
async function takeCommands(server, waitSec) {
  const sel = () => q.all("SELECT id,command FROM commands WHERE server_id=? AND status='pending' ORDER BY id", server.id);
  let list = sel();
  if (!list.length && waitSec > 0) {
    await new Promise(res => {
      const old = agentPollers.get(server.id);
      if (old) { clearTimeout(old.timer); old.resolve(); }
      const timer = setTimeout(() => { agentPollers.delete(server.id); res(); }, waitSec * 1000);
      agentPollers.set(server.id, { resolve: res, timer });
    });
    list = sel();
  }
  for (const c of list) q.run("UPDATE commands SET status='sent' WHERE id=?", c.id);
  return list;
}
function completeCommand(serverId, id, result) {
  const row = q.get('SELECT * FROM commands WHERE id=? AND server_id=?', id, serverId);
  if (!row) return false;
  q.run("UPDATE commands SET status='done', response=? WHERE id=?", String(result.ok ? result.response || '' : result.error || '').slice(0, 4000), id);
  const w = cmdWaiters.get(id);
  if (w) {
    cmdWaiters.delete(id);
    w(result.ok ? { ok: true, response: mc.stripCodes(String(result.response || '')) } : { ok: false, error: String(result.error || 'Ошибка агента') });
  }
  return true;
}

// ───────────── Игроки и сессии ─────────────
function getPlayer(sid, name, ts) {
  let p = q.get('SELECT * FROM players WHERE server_id=? AND name=?', sid, name);
  if (!p) {
    const r = q.run('INSERT INTO players(server_id,name,first_seen,last_seen) VALUES(?,?,?,?)', sid, name, ts, ts);
    p = q.get('SELECT * FROM players WHERE id=?', r.lastInsertRowid);
  }
  return p;
}
function closeSession(p, ts) {
  const s = q.get('SELECT * FROM play_sessions WHERE player_id=? AND left IS NULL ORDER BY id DESC LIMIT 1', p.id);
  let dur = 0;
  if (s) {
    const end = Math.max(ts, s.joined);
    dur = Math.round((end - s.joined) / 1000);
    q.run('UPDATE play_sessions SET left=? WHERE player_id=? AND left IS NULL', end, p.id);
  }
  q.run('UPDATE players SET online=0, last_seen=MAX(last_seen,?), playtime=playtime+? WHERE id=?', ts, dur, p.id);
}
function markAllOffline(sid, ts) {
  const rows = q.all('SELECT * FROM players WHERE server_id=? AND online=1', sid);
  for (const p of rows) closeSession(p, ts);
  q.run('UPDATE play_sessions SET left=? WHERE server_id=? AND left IS NULL', ts, sid);
  if (rows.length) broadcast('online', {}, sid);
}
function openSession(p, ts) {
  closeSession(p, ts);
  q.run('INSERT INTO play_sessions(server_id,player_id,joined) VALUES(?,?,?)', p.server_id, p.id, ts);
  q.run('UPDATE players SET online=1,last_seen=MAX(last_seen,?) WHERE id=?', ts, p.id);
}

// ───────────── Репорты ─────────────
function createReport(server, { reporter, target, reason, source, ts }) {
  const t = ts || now();
  const r = q.run('INSERT INTO reports(server_id,reporter,target,reason,status,source,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)',
    server.id, reporter || null, target || null, clean(reason, 1000) || 'Без описания', 'open', source || 'game', t, t);
  const id = Number(r.lastInsertRowid);
  notify('report', `Новый репорт #${id} · ${server.name}`,
    `${reporter || 'Игрок'}${target ? ' → ' + target : ''}: ${clean(reason, 120)}`, server.id, `#/s/${server.id}/reports`);
  broadcast('reports', {}, server.id);
  return id;
}

// ───────────── Приём событий от агента/плагина ─────────────
const TYPE_RE = /^[a-z0-9_.-]{1,32}$/;
const ACTIVITY = new Set(['chat', 'command', 'death', 'advancement']);

function insertEvent(sid, ts, type, player, message, data) {
  let d = null;
  if (data && typeof data === 'object') { try { d = JSON.stringify(data).slice(0, 4000); } catch {} }
  q.run('INSERT INTO events(server_id,ts,type,player,message,data) VALUES(?,?,?,?,?,?)', sid, ts, type, player, message, d);
}

function processEvent(server, raw, t) {
  if (!raw || typeof raw !== 'object') return false;
  const type = String(raw.type || '').toLowerCase();
  if (!TYPE_RE.test(type)) return false;
  let ts = Number(raw.ts);
  if (!(ts > t - 7 * 864e5 && ts < t + 60000)) ts = t;
  ts = Math.floor(ts);
  let player = raw.player == null ? null : String(raw.player).trim();
  if (player && !NAME_RE.test(player)) player = null;
  const message = raw.message == null ? null : mc.stripCodes(String(raw.message)).slice(0, 2000);
  const data = raw.data && typeof raw.data === 'object' && !Array.isArray(raw.data) ? raw.data : null;
  const sid = server.id;

  switch (type) {
    case 'console': {
      let lvl = String(data && data.level || 'INFO').toUpperCase();
      if (!['INFO', 'WARN', 'ERROR', 'FATAL', 'DEBUG'].includes(lvl)) lvl = 'INFO';
      q.run('INSERT INTO console_lines(server_id,ts,level,line) VALUES(?,?,?,?)', sid, ts, lvl, (message || '').slice(0, 1500));
      return true;
    }
    case 'sync': {
      const names = ((data && data.players) || []).map(String).filter(n => NAME_RE.test(n));
      const set = new Set(names.map(n => n.toLowerCase()));
      for (const p of q.all('SELECT * FROM players WHERE server_id=? AND online=1', sid)) {
        if (!set.has(p.name.toLowerCase())) closeSession(p, ts);
      }
      for (const n of names) {
        const p = getPlayer(sid, n, ts);
        if (!p.online) openSession(p, ts);
      }
      broadcast('online', {}, sid);
      return true;
    }
    case 'server_start':
    case 'server_stop':
      markAllOffline(sid, ts);
      insertEvent(sid, ts, type, null, message || (type === 'server_start' ? 'Сервер запущен' : 'Сервер остановлен'), data);
      return true;
    case 'join': {
      if (!player) return false;
      const p = getPlayer(sid, player, ts);
      openSession(p, ts);
      const ip = data && data.ip ? String(data.ip).slice(0, 64) : null;
      q.run(`UPDATE players SET name=?, joins=joins+1, last_ip=COALESCE(?,last_ip), uuid=COALESCE(?,uuid),
        client_brand=COALESCE(?,client_brand), client_version=COALESCE(?,client_version), last_world=COALESCE(?,last_world) WHERE id=?`,
        player, ip, data && data.uuid ? String(data.uuid).slice(0, 40) : null,
        data && data.client_brand ? clean(data.client_brand, 40) : null, data && data.client_version ? clean(data.client_version, 40) : null,
        data && data.world ? clean(data.world, 60) : null, p.id);
      if (ip) {
        q.run(`INSERT INTO player_ips(player_id,server_id,ip,first_seen,last_seen,cnt) VALUES(?,?,?,?,?,1)
          ON CONFLICT(player_id,ip) DO UPDATE SET last_seen=excluded.last_seen, cnt=cnt+1`, p.id, sid, ip, ts, ts);
      }
      broadcast('online', {}, sid);
      break;
    }
    case 'leave': {
      if (!player) return false;
      const p = q.get('SELECT * FROM players WHERE server_id=? AND name=?', sid, player);
      if (p) closeSession(p, ts);
      broadcast('online', {}, sid);
      break;
    }
    case 'report': {
      const target = data && data.target && NAME_RE.test(String(data.target)) ? String(data.target) : null;
      if (player) getPlayer(sid, player, ts);
      createReport(server, { reporter: player, target, reason: message || '', source: 'game', ts });
      break;
    }
    case 'punish': {
      // Наказание, выданное прямо на сервере (по логам): ban / unban / kick
      const kind = String(data && data.kind || '').toLowerCase();
      const actor = clean(data && data.actor || 'Server', 40);
      if (!player || !['ban', 'unban', 'kick'].includes(kind) || actor.toLowerCase() === 'rcon') return false;
      recordPunishment(server, { type: kind, player, reason: message, actorName: actor, userId: null, source: 'game', ts, applied: 1 });
      return true;
    }
    case 'item': {
      const item = String(message || '').toLowerCase().replace(/^minecraft:/, '').slice(0, 80);
      const amount = Math.floor(Number(data && data.amount));
      if (!player || !/^[a-z0-9_.:-]+$/.test(item) || !(amount >= 1 && amount <= 1000000)) return false;
      q.run("INSERT INTO item_log(server_id,player,item,amount,ts,source) VALUES(?,?,?,?,?,'plugin')", sid, player, item, amount, ts);
      insertEvent(sid, ts, type, player, `${item} ×${amount}`, data);
      return true;
    }
    default:
      if (player) {
        const p = getPlayer(sid, player, ts);
        if (ACTIVITY.has(type) && !p.online) openSession(p, ts);
        else q.run('UPDATE players SET last_seen=MAX(last_seen,?) WHERE id=?', ts, p.id);
        if (data && data.world) q.run('UPDATE players SET last_world=? WHERE id=?', clean(data.world, 60), p.id);
      }
  }
  insertEvent(sid, ts, type, player, message, data);
  if (hooks.event && player && (type === 'chat' || type === 'command' || type === 'join')) {
    try { hooks.event(server, { type, player, message, data, ts }); } catch (e) { console.error('[event hook]', e.message); }
  }
  return true;
}

function ingest(server, list) {
  let accepted = 0, console_ = 0;
  const t = now();
  tx(() => {
    for (const raw of list) {
      try {
        if (processEvent(server, raw, t)) { accepted++; if (raw.type === 'console') console_++; }
      } catch (e) { console.error('[ingest]', e.message); }
    }
  });
  if (accepted - console_ > 0) broadcast('events', {}, server.id);
  if (console_) broadcast('console', {}, server.id);
  return accepted;
}

function heartbeat(server, info) {
  const t = now();
  const wasAlive = agentAlive(server);
  q.run('UPDATE servers SET last_agent=?, agent_rcon=?, agent_version=? WHERE id=?', t,
    info && info.rcon ? 1 : 0, info && info.v ? clean(info.v, 20) : server.agent_version, server.id);
  if (info && info.status && typeof info.status === 'object') {
    const st = info.status;
    agentStatus.set(server.id, {
      ts: t,
      st: {
        online: !!st.online, players_online: Number(st.players_online) || 0, players_max: Number(st.players_max) || 0,
        version: st.version ? clean(st.version, 60) : null, motd: st.motd ? clean(st.motd, 300) : null,
        favicon: typeof st.favicon === 'string' && st.favicon.length < 70000 && st.favicon.startsWith('data:image/') ? st.favicon : null,
        latency: Number.isFinite(st.latency) ? st.latency : null,
      },
    });
  }
  if (!wasAlive) {
    insertEvent(server.id, t, 'agent', null, 'Агент подключён', { version: info && info.v });
    broadcast('events', {}, server.id);
    broadcast('status', {}, server.id);
  }
}

// ───────────── Наказания ─────────────
const PUNISH_LABEL = { ban: 'Бан', unban: 'Разбан', kick: 'Кик', mute: 'Мут', unmute: 'Размут', warn: 'Предупреждение' };

function recordPunishment(server, { type, player, reason, duration, actorName, userId, source, ts, applied, response }) {
  const t = ts || now();
  const sid = server.id;
  if (type === 'ban' || type === 'mute') {
    q.run("UPDATE punishments SET active=0, ended_at=?, ended_by='заменено новым' WHERE server_id=? AND player=? AND type=? AND active=1", t, sid, player, type);
  }
  if (type === 'unban') q.run("UPDATE punishments SET active=0, ended_at=?, ended_by=? WHERE server_id=? AND player=? AND type='ban' AND active=1", t, actorName, sid, player);
  if (type === 'unmute') q.run("UPDATE punishments SET active=0, ended_at=?, ended_by=? WHERE server_id=? AND player=? AND type='mute' AND active=1", t, actorName, sid, player);
  const active = type === 'ban' || type === 'mute' ? 1 : 0;
  const r = q.run(`INSERT INTO punishments(server_id,player,type,reason,duration,created_at,expires_at,active,issued_by,issued_name,source,applied,response)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`, sid, player, type, reason || null, duration || null, t,
    active && duration ? t + duration * 1000 : null, active, userId, actorName, source, applied ? 1 : 0, response ? String(response).slice(0, 1000) : null);
  getPlayer(sid, player, t);
  insertEvent(sid, t, 'punishment', player, `${PUNISH_LABEL[type]}${reason ? ': ' + reason : ''}`,
    { kind: type, by: actorName, duration: duration || null, id: Number(r.lastInsertRowid), source });
  if (type === 'ban') notify('punish', `${PUNISH_LABEL[type]}: ${player} · ${server.name}`, `${actorName}${reason ? ' — ' + clean(reason, 100) : ''}`, sid, `#/s/${sid}/players/${encodeURIComponent(player)}`);
  broadcast('events', {}, sid);
  broadcast('punish', {}, sid);
  return Number(r.lastInsertRowid);
}

function buildPunishCommand(server, type, player, reason, duration, issuer) {
  const tpl = templatesOf(server)[type];
  if (!tpl) throw new HttpErr(400, 'Нет шаблона команды для этого наказания');
  const vars = {
    player, reason: reason || (type === 'warn' || type === 'kick' || type === 'ban' || type === 'mute' ? 'Нарушение правил' : ''),
    duration: fmtDur(duration), issuer,
  };
  return tpl.replace(/\{(\w+)\}/g, (m, k) => (vars[k] !== undefined ? String(vars[k]) : m)).replace(/\s+/g, ' ').trim();
}

async function applyPunishment(user, server, { player, type, reason, duration, ip }) {
  if (!validName(player)) throw new HttpErr(400, 'Некорректный ник игрока');
  if (!PUNISH_LABEL[type]) throw new HttpErr(400, 'Неизвестный тип наказания');
  reason = clean(reason, 200);
  if (type !== 'ban' && type !== 'mute') duration = null;
  const cmd = buildPunishCommand(server, type, player, reason, duration, user.login);
  const r = await runCommand(server, cmd);
  const id = recordPunishment(server, {
    type, player, reason, duration, actorName: user.display_name || user.login, userId: user.id, source: 'panel',
    applied: r.ok, response: r.ok ? r.response : r.error,
  });
  audit(user, 'punish.' + type, `${server.name}:${player}`, { reason, duration, command: cmd, ok: r.ok }, ip);
  return { id, applied: r.ok, response: r.ok ? r.response : null, error: r.ok ? null : r.error };
}

async function retryPunishment(user, id, ip) {
  const p = q.get('SELECT * FROM punishments WHERE id=?', id);
  if (!p) throw new HttpErr(404, 'Наказание не найдено');
  const server = getServer(p.server_id);
  const cmd = buildPunishCommand(server, p.type, p.player, p.reason, p.duration, user.login);
  const r = await runCommand(server, cmd);
  q.run('UPDATE punishments SET applied=?, response=? WHERE id=?', r.ok ? 1 : 0, String(r.ok ? r.response : r.error).slice(0, 1000), id);
  audit(user, 'punish.retry', `${server.name}:${p.player}`, { id, command: cmd, ok: r.ok }, ip);
  return { applied: r.ok, response: r.ok ? r.response : null, error: r.ok ? null : r.error };
}

async function expireJob() {
  const rows = q.all('SELECT * FROM punishments WHERE active=1 AND expires_at IS NOT NULL AND expires_at<=?', now());
  for (const p of rows) {
    q.run("UPDATE punishments SET active=0, ended_at=?, ended_by='истёк срок' WHERE id=?", now(), p.id);
    const s = getServer(p.server_id);
    if (!s || (p.type !== 'ban' && p.type !== 'mute')) continue;
    const tpl = templatesOf(s);
    if (tpl[p.type].includes('{duration}')) continue; // срок контролирует плагин
    const cmd = buildPunishCommand(s, p.type === 'ban' ? 'unban' : 'unmute', p.player, '', null, 'panel');
    const r = await runCommand(s, cmd);
    insertEvent(s.id, now(), 'punishment', p.player, `Автоснятие: ${PUNISH_LABEL[p.type]} истёк`, { kind: 'expire', ok: r.ok });
    if (!r.ok) notify('punish', `Не удалось снять ${p.type === 'ban' ? 'бан' : 'мут'}: ${p.player}`, r.error, s.id, `#/s/${s.id}/players/${encodeURIComponent(p.player)}`);
    broadcast('events', {}, s.id);
  }
  if (rows.length) rows.forEach(p => broadcast('punish', {}, p.server_id));
}

// ───────────── Опрос статуса серверов ─────────────
const agentStatus = new Map();
const failCount = new Map();
const lastSample = new Map();

function applyStatus(s, st) {
  const t = now();
  const wasOnline = !!s.online;
  q.run(`UPDATE servers SET online=?, players_online=?, players_max=?, version=COALESCE(?,version), motd=COALESCE(?,motd),
    latency=?, icon=COALESCE(?,icon), last_check=? WHERE id=?`,
    st.online ? 1 : 0, st.online ? st.players_online || 0 : 0, st.online ? (st.players_max || s.players_max || 0) : s.players_max,
    st.online ? st.version || null : null, st.online && st.motd != null ? st.motd : null,
    st.online ? (st.latency == null ? null : st.latency) : null, st.online ? st.favicon || null : null, t, s.id);
  if (s.last_check) {
    if (st.online && !wasOnline) {
      notify('server', `${s.name}: сервер в сети`, null, s.id, `#/s/${s.id}/status`);
      insertEvent(s.id, t, 'status', null, 'Сервер доступен', null);
      broadcast('events', {}, s.id);
    } else if (!st.online && wasOnline) {
      notify('server', `${s.name}: сервер недоступен`, 'Не удаётся получить статус сервера', s.id, `#/s/${s.id}/status`);
      insertEvent(s.id, t, 'status', null, 'Сервер недоступен', null);
      markAllOffline(s.id, t);
      broadcast('events', {}, s.id);
    }
  }
  if (st.online && (st.players_online || 0) === 0) {
    if (q.get('SELECT 1 x FROM players WHERE server_id=? AND online=1 LIMIT 1', s.id)) markAllOffline(s.id, t);
  }
  if (t - (lastSample.get(s.id) || 0) >= 55000) {
    lastSample.set(s.id, t);
    q.run('INSERT INTO online_samples(server_id,ts,up,online,max,latency) VALUES(?,?,?,?,?,?)', s.id, t, st.online ? 1 : 0,
      st.online ? st.players_online || 0 : 0, st.players_max || s.players_max || 0, st.online ? st.latency : null);
  }
  broadcast('status', {}, s.id);
}

async function pollServer(s) {
  let st;
  if (s.host) {
    try { st = await mc.ping(s.host, s.port || 25565, 4000); failCount.delete(s.id); }
    catch {
      const n = (failCount.get(s.id) || 0) + 1;
      failCount.set(s.id, n);
      if (n < 2 && s.online) return; // один сбой не считаем падением
      st = { online: false };
    }
  } else {
    const a = agentStatus.get(s.id);
    if (a && now() - a.ts < 45000) st = a.st;
    else if (agentAlive(s)) {
      st = { online: true, players_online: q.get('SELECT COUNT(*) c FROM players WHERE server_id=? AND online=1', s.id).c, players_max: s.players_max };
    } else st = { online: false };
  }
  applyStatus(getServer(s.id), st);
}
let polling = false;
async function pollAll() {
  if (polling) return;
  polling = true;
  try { await Promise.allSettled(q.all('SELECT * FROM servers').map(pollServer)); }
  finally { polling = false; }
}

function cleanup() {
  const days = Math.max(1, parseInt(getSetting('retention_days', process.env.EVENT_RETENTION_DAYS || '90'), 10) || 90);
  const t = now();
  q.run('DELETE FROM events WHERE ts<?', t - days * 864e5);
  q.run('DELETE FROM online_samples WHERE ts<?', t - 180 * 864e5);
  q.run('DELETE FROM sessions WHERE expires_at<?', t);
  q.run('DELETE FROM commands WHERE created_at<?', t - 864e5);
  q.run('DELETE FROM notifications WHERE ts<?', t - 60 * 864e5);
  for (const s of q.all('SELECT id FROM servers')) {
    q.run('DELETE FROM console_lines WHERE server_id=? AND id < COALESCE((SELECT id FROM console_lines WHERE server_id=? ORDER BY id DESC LIMIT 1 OFFSET 5000),0)', s.id, s.id);
  }
}

function startJobs() {
  pollAll();
  setInterval(pollAll, 15000).unref();
  setInterval(() => expireJob().catch(e => console.error('[expire]', e.message)), 30000).unref();
  setInterval(() => { try { cleanup(); } catch (e) { console.error('[cleanup]', e.message); } }, 3600 * 1000).unref();
  setTimeout(() => { try { cleanup(); } catch {} }, 30000).unref();
}

module.exports = {
  sseAdd, broadcast, notify, DEFAULT_TEMPLATES, getServer, templatesOf, agentAlive, canCommand, publicServer, visibleServers,
  totalOnline, runCommand, takeCommands, completeCommand, getPlayer, closeSession, markAllOffline, createReport,
  ingest, heartbeat, applyPunishment, retryPunishment, recordPunishment, PUNISH_LABEL, startJobs, pollAll, insertEvent,
  fmtDur, agentPollers, hooks,
};
