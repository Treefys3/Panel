'use strict';
const { DatabaseSync } = require('node:sqlite');
const fs = require('fs');
const path = require('path');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_FILE = path.join(DATA_DIR, 'panel.db');
const db = new DatabaseSync(DB_FILE);
db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');

db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY,
  login TEXT NOT NULL UNIQUE COLLATE NOCASE,
  pass_hash TEXT NOT NULL,
  role TEXT NOT NULL,
  display_name TEXT,
  mc_nick TEXT COLLATE NOCASE,
  servers TEXT NOT NULL DEFAULT '*',
  disabled INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  created_by INTEGER,
  last_login INTEGER,
  notif_read INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sessions(
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  last_seen INTEGER NOT NULL,
  ip TEXT, ua TEXT
);
CREATE TABLE IF NOT EXISTS servers(
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  host TEXT,
  port INTEGER NOT NULL DEFAULT 25565,
  api_key_hash TEXT NOT NULL UNIQUE,
  api_key_hint TEXT,
  rcon_mode TEXT NOT NULL DEFAULT 'agent',
  rcon_port INTEGER,
  rcon_password TEXT,
  templates TEXT,
  color TEXT NOT NULL DEFAULT '#4f7cff',
  icon TEXT,
  online INTEGER NOT NULL DEFAULT 0,
  players_online INTEGER NOT NULL DEFAULT 0,
  players_max INTEGER NOT NULL DEFAULT 0,
  version TEXT, motd TEXT, latency INTEGER,
  last_check INTEGER,
  last_agent INTEGER,
  agent_rcon INTEGER NOT NULL DEFAULT 0,
  agent_version TEXT,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS players(
  id INTEGER PRIMARY KEY,
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  name TEXT NOT NULL COLLATE NOCASE,
  uuid TEXT,
  first_seen INTEGER NOT NULL,
  last_seen INTEGER NOT NULL,
  online INTEGER NOT NULL DEFAULT 0,
  last_ip TEXT,
  client_brand TEXT, client_version TEXT,
  last_world TEXT,
  playtime INTEGER NOT NULL DEFAULT 0,
  joins INTEGER NOT NULL DEFAULT 0,
  UNIQUE(server_id, name)
);
CREATE INDEX IF NOT EXISTS players_online ON players(server_id, online);
CREATE TABLE IF NOT EXISTS player_ips(
  player_id INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  server_id INTEGER NOT NULL,
  ip TEXT NOT NULL,
  first_seen INTEGER NOT NULL,
  last_seen INTEGER NOT NULL,
  cnt INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY(player_id, ip)
);
CREATE INDEX IF NOT EXISTS ips_ip ON player_ips(server_id, ip);
CREATE TABLE IF NOT EXISTS play_sessions(
  id INTEGER PRIMARY KEY,
  server_id INTEGER NOT NULL,
  player_id INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  joined INTEGER NOT NULL,
  left INTEGER
);
CREATE INDEX IF NOT EXISTS ps_player ON play_sessions(player_id, joined);
CREATE INDEX IF NOT EXISTS ps_server ON play_sessions(server_id, joined);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY,
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  ts INTEGER NOT NULL,
  type TEXT NOT NULL,
  player TEXT COLLATE NOCASE,
  message TEXT,
  data TEXT
);
CREATE INDEX IF NOT EXISTS ev_srv ON events(server_id, id);
CREATE INDEX IF NOT EXISTS ev_type ON events(server_id, type, id);
CREATE INDEX IF NOT EXISTS ev_player ON events(server_id, player, id);
CREATE INDEX IF NOT EXISTS ev_ts ON events(ts);
CREATE TABLE IF NOT EXISTS console_lines(
  id INTEGER PRIMARY KEY,
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  ts INTEGER NOT NULL,
  level TEXT NOT NULL,
  line TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS cl_srv ON console_lines(server_id, id);
CREATE TABLE IF NOT EXISTS punishments(
  id INTEGER PRIMARY KEY,
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  player TEXT NOT NULL COLLATE NOCASE,
  type TEXT NOT NULL,
  reason TEXT,
  duration INTEGER,
  created_at INTEGER NOT NULL,
  expires_at INTEGER,
  active INTEGER NOT NULL DEFAULT 0,
  issued_by INTEGER,
  issued_name TEXT,
  source TEXT NOT NULL DEFAULT 'panel',
  ended_at INTEGER,
  ended_by TEXT,
  applied INTEGER NOT NULL DEFAULT 0,
  response TEXT
);
CREATE INDEX IF NOT EXISTS pun_srv ON punishments(server_id, id);
CREATE INDEX IF NOT EXISTS pun_player ON punishments(server_id, player);
CREATE INDEX IF NOT EXISTS pun_active ON punishments(active, expires_at);
CREATE TABLE IF NOT EXISTS reports(
  id INTEGER PRIMARY KEY,
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  reporter TEXT COLLATE NOCASE,
  target TEXT COLLATE NOCASE,
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  resolution TEXT,
  assignee_id INTEGER,
  source TEXT NOT NULL DEFAULT 'game',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  closed_at INTEGER,
  closed_by INTEGER
);
CREATE INDEX IF NOT EXISTS rep_srv ON reports(server_id, status, id);
CREATE TABLE IF NOT EXISTS report_comments(
  id INTEGER PRIMARY KEY,
  report_id INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
  user_id INTEGER, user_name TEXT,
  ts INTEGER NOT NULL,
  text TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS notes(
  id INTEGER PRIMARY KEY,
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  player TEXT NOT NULL COLLATE NOCASE,
  user_id INTEGER, user_name TEXT,
  ts INTEGER NOT NULL,
  text TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS notes_player ON notes(server_id, player);
CREATE TABLE IF NOT EXISTS whitelist(
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  name TEXT NOT NULL COLLATE NOCASE,
  added_by TEXT,
  added_at INTEGER NOT NULL,
  PRIMARY KEY(server_id, name)
);
CREATE TABLE IF NOT EXISTS online_samples(
  server_id INTEGER NOT NULL,
  ts INTEGER NOT NULL,
  up INTEGER NOT NULL,
  online INTEGER NOT NULL,
  max INTEGER NOT NULL,
  latency INTEGER
);
CREATE INDEX IF NOT EXISTS samples_srv ON online_samples(server_id, ts);
CREATE TABLE IF NOT EXISTS quotas(
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  hours REAL NOT NULL DEFAULT 0,
  punishments INTEGER NOT NULL DEFAULT 0,
  reports INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(server_id, role)
);
CREATE TABLE IF NOT EXISTS audit(
  id INTEGER PRIMARY KEY,
  ts INTEGER NOT NULL,
  user_id INTEGER,
  user_login TEXT,
  action TEXT NOT NULL,
  target TEXT,
  details TEXT,
  ip TEXT
);
CREATE INDEX IF NOT EXISTS audit_ts ON audit(id);
CREATE TABLE IF NOT EXISTS notifications(
  id INTEGER PRIMARY KEY,
  ts INTEGER NOT NULL,
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT,
  server_id INTEGER,
  link TEXT
);
CREATE TABLE IF NOT EXISTS roles(
  key TEXT PRIMARY KEY,
  label TEXT NOT NULL,
  color TEXT NOT NULL DEFAULT '#4f7cff',
  perms TEXT NOT NULL DEFAULT '[]',
  builtin INTEGER NOT NULL DEFAULT 0,
  position INTEGER NOT NULL DEFAULT 100
);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS automod_rules(
  id INTEGER PRIMARY KEY,
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1,
  config TEXT NOT NULL DEFAULT '{}',
  action TEXT NOT NULL DEFAULT 'notify',
  duration INTEGER,
  reason TEXT,
  hits INTEGER NOT NULL DEFAULT 0,
  last_hit INTEGER
);
CREATE INDEX IF NOT EXISTS am_srv ON automod_rules(server_id, enabled);
CREATE TABLE IF NOT EXISTS schedules(
  id INTEGER PRIMARY KEY,
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1,
  kind TEXT NOT NULL DEFAULT 'interval',
  every_min INTEGER,
  at_time TEXT,
  days TEXT NOT NULL DEFAULT '1,2,3,4,5,6,7',
  commands TEXT NOT NULL,
  next_run INTEGER,
  last_run INTEGER,
  last_result TEXT,
  created_by TEXT
);
CREATE TABLE IF NOT EXISTS webhooks(
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  url TEXT,
  token TEXT,
  chat_id TEXT,
  events TEXT NOT NULL DEFAULT '[]',
  enabled INTEGER NOT NULL DEFAULT 1,
  last_status TEXT,
  last_at INTEGER
);
CREATE TABLE IF NOT EXISTS commands(
  id INTEGER PRIMARY KEY,
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  command TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  response TEXT,
  created_at INTEGER NOT NULL
);
`);

// Миграции для баз, созданных старыми версиями
const userCols = db.prepare("PRAGMA table_info(users)").all().map(c => c.name);
for (const [col, def] of [['discord_id', 'TEXT'], ['discord_name', 'TEXT'], ['discord_off', 'INTEGER NOT NULL DEFAULT 0']]) {
  if (!userCols.includes(col)) db.exec(`ALTER TABLE users ADD COLUMN ${col} ${def}`);
}
db.exec('CREATE UNIQUE INDEX IF NOT EXISTS users_discord ON users(discord_id) WHERE discord_id IS NOT NULL');
const roleCols = db.prepare("PRAGMA table_info(roles)").all().map(c => c.name);
if (roleCols.length) for (const [col, def] of [['description', 'TEXT'], ['discord_role_id', 'TEXT'], ['from_discord', 'INTEGER NOT NULL DEFAULT 0']]) {
  if (!roleCols.includes(col)) db.exec(`ALTER TABLE roles ADD COLUMN ${col} ${def}`);
}
db.exec(`
CREATE TABLE IF NOT EXISTS item_norms(
  server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  role TEXT NOT NULL, item TEXT NOT NULL, amount INTEGER NOT NULL,
  PRIMARY KEY(server_id, role, item)
);
CREATE TABLE IF NOT EXISTS item_log(
  id INTEGER PRIMARY KEY, server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  player TEXT NOT NULL COLLATE NOCASE, item TEXT NOT NULL, amount INTEGER NOT NULL, ts INTEGER NOT NULL,
  source TEXT NOT NULL DEFAULT 'manual', by_user TEXT
);
CREATE INDEX IF NOT EXISTS item_log_idx ON item_log(server_id, player, ts);
`);
if (!userCols.includes('pw_changed')) db.exec('ALTER TABLE users ADD COLUMN pw_changed INTEGER NOT NULL DEFAULT 0');

// ── Лёгкая обёртка над prepared statements (с кэшем) ──
const cache = new Map();
function stmt(sql) {
  let s = cache.get(sql);
  if (!s) { s = db.prepare(sql); cache.set(sql, s); }
  return s;
}
const norm = p => p.map(v => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v));
const q = {
  get: (sql, ...p) => stmt(sql).get(...norm(p)),
  all: (sql, ...p) => stmt(sql).all(...norm(p)),
  run: (sql, ...p) => stmt(sql).run(...norm(p)),
};
function tx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { try { db.exec('ROLLBACK'); } catch {} throw e; }
}
function likeEscape(s) { return String(s).replace(/[\\%_]/g, c => '\\' + c); }

function getSetting(key, def = null) {
  const r = q.get('SELECT value FROM settings WHERE key=?', key);
  return r ? r.value : def;
}
function setSetting(key, value) {
  q.run('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', key, value == null ? null : String(value));
}
module.exports = { db, q, tx, DATA_DIR, DB_FILE, likeEscape, getSetting, setSetting };
