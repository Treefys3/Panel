'use strict';
const crypto = require('crypto');
const { q, getSetting, setSetting } = require('./db');

const SESSION_TTL = 7 * 24 * 3600 * 1000;

// ───────────── Роли и права ─────────────
// Каталог прав: каждое право открывает конкретный раздел или действие.
const PERM_CATALOG = [
  { group: 'Сервер', items: [
    ['status', 'Статус серверов', 'Пинг, версия, онлайн, доступность и графики'],
    ['online', 'Онлайн', 'Кто сейчас в игре, графики онлайна, пик и уникальные игроки'],
    ['logs', 'Логи', 'Лента всех событий: входы, чат, команды, смерти, наказания'],
    ['console', 'Консоль', 'Вывод консоли и отправка команд на сервер (RCON)'],
    ['chat', 'Чат', 'Видеть чат сервера в реальном времени'],
    ['chat.send', 'Чат: писать', 'Писать в чат сервера от имени панели и личные сообщения игрокам'],
    ['control', 'Управление сервером', 'Сохранение мира, объявления, время, погода, режим игры, телепорт'],
    ['control.admin', 'Управление: опасное', 'Запуск/остановка/перезапуск, оп, выдача предметов, сложность'],
  ] },
  { group: 'Игроки', items: [
    ['players', 'Список игроков', 'Профили игроков, история, заметки, список наказаний'],
    ['clients', 'Клиент дата', 'Клиенты, версии, платформы игроков'],
    ['ips', 'IP-адреса и твинки', 'Видеть IP игроков и аккаунты с общим IP'],
    ['whitelist.view', 'Вайтлист: просмотр', 'Смотреть список вайтлиста'],
    ['whitelist', 'Вайтлист: управление', 'Добавлять и убирать игроков, синхронизация с сервером'],
  ] },
  { group: 'Модерация', items: [
    ['reports', 'Репорты', 'Читать и обрабатывать жалобы игроков'],
    ['punish', 'Кик, мут, предупреждения', 'Выдавать мягкие наказания'],
    ['ban', 'Бан и разбан', 'Банить и разбанивать игроков'],
    ['automod', 'Автомодерация', 'Правила автоматической реакции на чат, команды и твинков'],
  ] },
  { group: 'Персонал', items: [
    ['quotas.view', 'Минималки: просмотр', 'Видеть выполнение норм сотрудниками'],
    ['quotas', 'Минималки: настройка', 'Менять нормы для ролей, в том числе по предметам'],
    ['items', 'Предметы: учёт сдачи', 'Записывать сдачу предметов сотрудниками'],
  ] },
  { group: 'Администрирование', items: [
    ['scheduler', 'Планировщик', 'Команды и объявления по расписанию'],
    ['integrations', 'Интеграции', 'Уведомления в Discord / Telegram и вебхуки'],
    ['servers.manage', 'Настройки серверов', 'Добавление серверов, RCON, шаблоны команд, ключи агента'],
    ['audit', 'Журнал действий', 'Что делали сотрудники в панели'],
  ] },
];
// «Минималки» временно отключены (вернуть: FEATURE_QUOTAS=1)
const FEATURES = { quotas: process.env.FEATURE_QUOTAS === '1' };
const QUOTA_PERMS = ['quotas.view', 'quotas', 'items'];
if (!FEATURES.quotas) for (const g of PERM_CATALOG) g.items = g.items.filter(i => !QUOTA_PERMS.includes(i[0]));
const ALL_PERMS = PERM_CATALOG.flatMap(g => g.items.map(i => i[0]));
const OWNER_ONLY = ['users.manage', 'roles.manage', 'system'];

const BUILTIN_ROLES = {
  admin: { label: 'Администратор', color: '#f0524f', position: 1, perms: ALL_PERMS },
  moderator: { label: 'Модератор', color: '#f5a623', position: 2,
    perms: ['status', 'online', 'logs', 'players', 'clients', 'ips', 'whitelist.view', 'whitelist', 'reports', 'punish', 'ban', 'quotas.view'] },
  helper: { label: 'Хелпер', color: '#38bdf8', position: 3,
    perms: ['status', 'online', 'logs', 'players', 'whitelist.view', 'reports', 'punish', 'quotas.view'] },
};
let rolesCache = null;
function seedRoles() {
  for (const [key, r] of Object.entries(BUILTIN_ROLES)) {
    if (!q.get('SELECT 1 x FROM roles WHERE key=?', key)) {
      q.run('INSERT INTO roles(key,label,color,perms,builtin,position) VALUES(?,?,?,?,1,?)', key, r.label, r.color, JSON.stringify(r.perms), r.position);
    }
  }
}
function upgradeRoles() {
  // новые права для уже существующих баз: админ получает всё, модератор/хелпер — чат
  if (getSetting('perms_v3') === '1') return;
  q.run('UPDATE roles SET perms=? WHERE key=?', JSON.stringify(ALL_PERMS), 'admin');
  for (const k of ['moderator', 'helper']) {
    const r = q.get('SELECT perms FROM roles WHERE key=?', k);
    if (!r) continue;
    let p = []; try { p = JSON.parse(r.perms); } catch {}
    if (!p.includes('chat')) q.run('UPDATE roles SET perms=? WHERE key=?', JSON.stringify([...p, 'chat']), k);
  }
  setSetting('perms_v3', '1');
}
function reloadRoles() {
  seedRoles(); upgradeRoles();
  const out = { owner: { key: 'owner', label: 'Владелец', color: '#a78bfa', perms: ['*'], builtin: 1 } };
  for (const r of q.all('SELECT * FROM roles ORDER BY position, key')) {
    let perms = [];
    try { perms = JSON.parse(r.perms); } catch {}
    out[r.key] = { key: r.key, label: r.label, color: r.color, perms: perms.filter(p => ALL_PERMS.includes(p)), builtin: r.builtin, description: r.description || '', discord_role_id: r.discord_role_id || null, from_discord: !!r.from_discord, position: r.position };
  }
  rolesCache = out;
  return out;
}
const roles = () => rolesCache || reloadRoles();
const assignableRoles = () => Object.keys(roles()).filter(k => k !== 'owner');

function can(user, perm) {
  if (!user) return false;
  const r = roles()[user.role];
  if (!r) return false;
  return r.perms.includes('*') || r.perms.includes(perm);
}
function permsOf(user) {
  const r = roles()[user.role];
  if (!r) return [];
  return r.perms.includes('*') ? ['*'] : r.perms;
}
function canServer(user, serverId) {
  if (!user) return false;
  if (user.role === 'owner' || user.servers === '*') return true;
  return String(user.servers).split(',').includes(String(serverId));
}

// ── Пароли (scrypt) ──
const SCRYPT = { N: 16384, r: 8, p: 1 };
function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const h = crypto.scryptSync(pw, salt, 64, SCRYPT);
  return `scrypt$${salt.toString('hex')}$${h.toString('hex')}`;
}
function verifyPassword(pw, stored) {
  try {
    const [alg, s, h] = String(stored).split('$');
    if (alg !== 'scrypt') return false;
    const hh = crypto.scryptSync(pw, Buffer.from(s, 'hex'), 64, SCRYPT);
    const ref = Buffer.from(h, 'hex');
    return ref.length === hh.length && crypto.timingSafeEqual(hh, ref);
  } catch { return false; }
}
const DUMMY_HASH = hashPassword('dummy-password-for-timing');

function validLogin(l) { return typeof l === 'string' && /^[A-Za-z0-9_.-]{3,32}$/.test(l); }
function validPassword(p) { return typeof p === 'string' && p.length >= 8 && p.length <= 128; }

// ── Сессии ──
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
function createSession(userId, ip, ua) {
  const token = crypto.randomBytes(32).toString('base64url');
  const now = Date.now();
  q.run('INSERT INTO sessions(token_hash,user_id,created_at,expires_at,last_seen,ip,ua) VALUES(?,?,?,?,?,?,?)',
    sha(token), userId, now, now + SESSION_TTL, now, ip, String(ua || '').slice(0, 200));
  return token;
}
function destroySession(token) { if (token) q.run('DELETE FROM sessions WHERE token_hash=?', sha(token)); }
function destroyUserSessions(userId, exceptToken) {
  if (exceptToken) q.run('DELETE FROM sessions WHERE user_id=? AND token_hash<>?', userId, sha(exceptToken));
  else q.run('DELETE FROM sessions WHERE user_id=?', userId);
}
function parseCookies(h) {
  const out = {};
  String(h || '').split(';').forEach(p => {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}
function userFromToken(token) {
  if (!token) return null;
  const now = Date.now();
  const row = q.get(`SELECT u.*, s.last_seen AS s_seen FROM sessions s JOIN users u ON u.id=s.user_id
    WHERE s.token_hash=? AND s.expires_at>? AND u.disabled=0`, sha(token), now);
  if (!row) return null;
  if (now - row.s_seen > 60000) {
    q.run('UPDATE sessions SET last_seen=?, expires_at=? WHERE token_hash=?', now, now + SESSION_TTL, sha(token));
  }
  return row;
}

// ── Защита от перебора пароля ──
const fails = new Map();
function lockLeft(ip, login) {
  const now = Date.now();
  for (const k of [`${ip}|${String(login).toLowerCase()}`, `${ip}|*`]) {
    const f = fails.get(k);
    if (f && f.until > now) return Math.ceil((f.until - now) / 1000);
  }
  return 0;
}
function recordFail(ip, login) {
  const now = Date.now();
  for (const [k, limit] of [[`${ip}|${String(login).toLowerCase()}`, 5], [`${ip}|*`, 20]]) {
    let f = fails.get(k);
    if (!f || now - f.first > 15 * 60000) f = { n: 0, first: now, until: 0 };
    f.n++;
    if (f.n >= limit) { f.until = now + 5 * 60000; f.n = 0; f.first = now; }
    fails.set(k, f);
  }
}
function recordSuccess(ip, login) { fails.delete(`${ip}|${String(login).toLowerCase()}`); }
setInterval(() => {
  const now = Date.now();
  for (const [k, f] of fails) if (now - f.first > 15 * 60000 && f.until < now) fails.delete(k);
}, 60000).unref();

// ── Журнал действий в панели ──
function audit(user, action, target, details, ip) {
  q.run('INSERT INTO audit(ts,user_id,user_login,action,target,details,ip) VALUES(?,?,?,?,?,?,?)',
    Date.now(), user ? user.id : null, user ? user.login : null, action, target == null ? null : String(target),
    details == null ? null : (typeof details === 'string' ? details : JSON.stringify(details)).slice(0, 2000), ip || null);
}

module.exports = {
  FEATURES, PERM_CATALOG, ALL_PERMS, OWNER_ONLY, roles, assignableRoles, reloadRoles, can, permsOf, canServer, hashPassword, verifyPassword, DUMMY_HASH, validLogin, validPassword,
  createSession, destroySession, destroyUserSessions, parseCookies, userFromToken, sha,
  lockLeft, recordFail, recordSuccess, audit,
};
