'use strict';

class HttpErr extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

// Убирает управляющие символы и обрезает строку
function clean(s, max = 500) {
  return String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
}
// Многострочный текст (комментарии, заметки)
function cleanText(s, max = 4000) {
  return String(s == null ? '' : s).replace(/\r/g, '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim().slice(0, max);
}

// "1d12h30m" | "2w" | число секунд -> секунды (или null — навсегда)
function parseDuration(v) {
  if (v == null || v === '' || v === 'perm' || v === 'forever') return null;
  if (typeof v === 'number') return v > 0 ? Math.min(Math.floor(v), 10 * 365 * 86400) : null;
  const s = String(v).trim().toLowerCase();
  if (/^\d+$/.test(s)) return Math.min(parseInt(s, 10), 10 * 365 * 86400) || null;
  const re = /(\d+)\s*(w|d|h|m|s)/g;
  const mult = { w: 604800, d: 86400, h: 3600, m: 60, s: 1 };
  let total = 0, m, matched = 0;
  while ((m = re.exec(s))) { total += parseInt(m[1], 10) * mult[m[2]]; matched += m[0].length; }
  if (!total || matched < s.replace(/\s+/g, '').length) throw new HttpErr(400, 'Неверный срок. Примеры: 30m, 2h, 7d, 1w, 1d12h');
  return Math.min(total, 10 * 365 * 86400);
}
function fmtDur(sec) {
  if (!sec) return '';
  let out = '';
  for (const [c, n] of [['w', 604800], ['d', 86400], ['h', 3600], ['m', 60], ['s', 1]]) {
    if (sec >= n) { const k = Math.floor(sec / n); sec -= k * n; out += k + c; }
  }
  return out;
}

const NAME_RE = /^[A-Za-z0-9_.\-]{1,40}$/;
function validName(n) { return typeof n === 'string' && NAME_RE.test(n); }

// Начало недели (понедельник 00:00 по времени сервера панели)
function weekStart(ts) {
  const d = new Date(ts);
  d.setHours(0, 0, 0, 0);
  const day = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - day);
  return d.getTime();
}

module.exports = { HttpErr, clean, cleanText, parseDuration, fmtDur, validName, NAME_RE, weekStart };
