'use strict';
// Вход через Discord, чат сервера, управление сервером, минималки на предметы.
const { q, tx } = require('./db');
const A = require('./auth');
const C = require('./core');
const X = require('./extra');
const D = require('./discord');
const { HttpErr, clean, weekStart } = require('./util');

const now = () => Date.now();
const PLAYER_RE = /^\.?[A-Za-z0-9_]{1,16}$/;
const ITEM_RE = /^[a-z0-9_.:-]{1,80}$/;
const normItem = v => String(v || '').trim().toLowerCase().replace(/^minecraft:/, '').replace(/\s+/g, '_');
const page = (to, msg) => `<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="0;url=${to}"><title>MC Panel</title><body style="font-family:sans-serif;background:#0e1228;color:#e7eafa;padding:30px"><p>${msg || 'Переходим в панель…'}</p><a style="color:#7aa2ff" href="${to}">Продолжить</a></body></html>`;
const origin = ctx => {
  const host = ctx.req.headers['x-forwarded-host'] || ctx.req.headers.host;
  const proto = ctx.req.headers['x-forwarded-proto'] || 'http';
  if (!host || !/^[\w.\-:]+$/.test(host)) throw new HttpErr(400, 'Неверный Host');
  return `${proto}://${host}`;
};

module.exports = function register(route0) {
  // раздел «Минималки» (в т. ч. предметы) временно отключён флагом
  const route = (method, pattern, opts, handler) => route0(method, pattern, opts, pattern.includes('/items') && !A.FEATURES.quotas
    ? () => { throw new HttpErr(404, 'Раздел отключён'); } : handler);
  /* ═════════ Discord ═════════ */
  const mask = s => (s ? '••••' + String(s).slice(-4) : '');
  route('GET', '/api/discord/status', { auth: false }, () => ({ enabled: D.enabled() }));
  route('POST', '/api/discord/start', { auth: false }, ctx => ({ url: D.authorizeUrl('login', origin(ctx)) }));
  route('POST', '/api/discord/link', {}, ctx => ({ url: D.authorizeUrl('link', origin(ctx), ctx.user.id) }));
  route('POST', '/api/discord/unlink', {}, ctx => {
    if (ctx.user.role !== 'owner' && D.cfg().guild_id) throw new HttpErr(400, 'Привязка управляется ролями Discord-сервера — отвязать может владелец');
    q.run('UPDATE users SET discord_id=NULL, discord_name=NULL WHERE id=?', ctx.user.id);
    A.audit(ctx.user, 'discord.unlink', ctx.user.login, null, ctx.ip);
  });
  route('DELETE', '/api/users/:id/discord', { perm: 'users.manage' }, ctx => {
    const u = q.get('SELECT * FROM users WHERE id=?', ctx.params.id);
    if (!u) throw new HttpErr(404, 'Пользователь не найден');
    q.run('UPDATE users SET discord_id=NULL, discord_name=NULL WHERE id=?', u.id);
    A.audit(ctx.user, 'discord.unlink', u.login, null, ctx.ip);
  });
  route('GET', '/api/discord/callback', { auth: false }, async ctx => {
    const back = e => { ctx.raw = { type: 'text/html; charset=utf-8', body: page('/?dc_error=' + encodeURIComponent(e), e) }; };
    try {
      if (ctx.query.error) throw new HttpErr(400, 'Вход через Discord отменён');
      const st = D.takeState(String(ctx.query.state || ''));
      if (!st || !ctx.query.code) throw new HttpErr(400, 'Ссылка входа устарела — попробуйте ещё раз');
      const token = await D.exchange(String(ctx.query.code), st.redirect);
      const du = await D.dfetch('/users/@me', { token });
      if (!du || !du.id) throw new HttpErr(502, 'Не удалось получить профиль Discord');
      if (st.purpose === 'link') {
        await D.linkAccount(st.userId, du);
        A.audit({ id: st.userId, login: (q.get('SELECT login FROM users WHERE id=?', st.userId) || {}).login }, 'discord.link', du.username, null, ctx.ip);
        ctx.raw = { type: 'text/html; charset=utf-8', body: page('/#/', 'Discord привязан') };
        return;
      }
      const lock = A.lockLeft(ctx.ip, 'discord:' + du.id);
      if (lock) throw new HttpErr(429, 'Слишком много попыток входа');
      const u = await D.resolveLogin(du, token, ctx.ip);
      const sess = A.createSession(u.id, ctx.ip, ctx.req.headers['user-agent']);
      q.run('UPDATE users SET last_login=?, discord_name=? WHERE id=?', now(), du.username, u.id);
      A.audit(u, 'login', null, { via: 'discord' }, ctx.ip);
      ctx.setSession(sess);
      ctx.raw = { type: 'text/html; charset=utf-8', body: page('/#/') };
    } catch (e) { back(e.message || 'Ошибка входа через Discord'); }
  });

  // настройки (владелец)
  route('GET', '/api/discord/settings', { perm: 'system' }, ctx => {
    const c = D.cfg();
    return { client_id: c.client_id, has_secret: !!c.client_secret, secret_hint: mask(c.client_secret), guild_id: c.guild_id, has_bot: !!c.bot_token, bot_hint: mask(c.bot_token),
      redirect_uri: D.redirectUri(origin(ctx)), enabled: D.enabled(), auto_admin: X.getSetting('discord_auto_admin') !== '0' };
  });
  route('PUT', '/api/discord/settings', { perm: 'system' }, ctx => {
    const b = ctx.body;
    const id = (v, label) => { v = String(v || '').trim(); if (v && !/^\d{5,25}$/.test(v)) throw new HttpErr(400, label + ': только цифры'); return v; };
    const cid = b.client_id !== undefined ? id(b.client_id, 'Application ID') : undefined;
    const gid = b.guild_id !== undefined ? id(b.guild_id, 'ID сервера') : undefined;
    if (cid !== undefined) X.setSetting('discord_client_id', cid);
    if (gid !== undefined) X.setSetting('discord_guild_id', gid);
    if (b.client_secret) X.setSetting('discord_client_secret', clean(b.client_secret, 200));
    if (b.bot_token) X.setSetting('discord_bot_token', clean(b.bot_token, 200));
    if (b.auto_admin !== undefined) X.setSetting('discord_auto_admin', b.auto_admin ? '1' : '0');
    if (b.clear_bot) X.setSetting('discord_bot_token', '');
    if (b.clear_secret) X.setSetting('discord_client_secret', '');
    A.audit(ctx.user, 'discord.settings', null, { client_id: b.client_id, guild_id: b.guild_id }, ctx.ip);
  });
  route('POST', '/api/discord/sync', { perm: 'system' }, async ctx => {
    if (!D.cfg().bot_token) throw new HttpErr(400, 'Нужен токен бота');
    const r = await D.syncAll(ctx.ip);
    A.audit(ctx.user, 'discord.sync', null, r, ctx.ip);
    return r;
  });
  route('POST', '/api/discord/import-roles', { perm: 'system' }, async ctx => {
    if (!D.cfg().bot_token) throw new HttpErr(400, 'Для синхронизации ролей нужен токен бота (Система → Вход через Discord)');
    const r = await D.importRoles({ force: true });
    A.audit(ctx.user, 'discord.roles', null, r, ctx.ip);
    return r;
  });
  route('GET', '/api/discord/roles', { perm: 'roles.manage' }, async () => ({ roles: await D.guildRoles() }));

  /* ═════════ Чат ═════════ */
  const CHAT_TYPES = "'chat','join','leave','death','advancement','kick'";
  route('GET', '/api/servers/:id/chat', { perm: 'chat', server: true }, ctx => {
    const after = Number(ctx.query.after) || 0;
    const limit = Math.min(300, Math.max(1, parseInt(ctx.query.limit, 10) || 120));
    const rows = after
      ? q.all(`SELECT id,ts,type,player,message,data FROM events WHERE server_id=? AND type IN (${CHAT_TYPES}) AND id>? ORDER BY id LIMIT ?`, ctx.server.id, after, limit)
      : q.all(`SELECT id,ts,type,player,message,data FROM events WHERE server_id=? AND type IN (${CHAT_TYPES}) ORDER BY id DESC LIMIT ?`, ctx.server.id, limit).reverse();
    const online = q.all('SELECT name FROM players WHERE server_id=? AND online=1 ORDER BY name', ctx.server.id).map(p => p.name);
    return {
      items: rows.map(r => { let data = null; try { data = r.data ? JSON.parse(r.data) : null; } catch {} return { id: r.id, ts: r.ts, type: r.type, player: r.player, message: r.message, panel: !!(data && data.panel), by: data && data.by }; }),
      online, can_command: C.canCommand(ctx.server),
    };
  });
  route('POST', '/api/servers/:id/chat', { perm: 'chat.send', server: true }, async ctx => {
    const text = clean(ctx.body.text, 240).replace(/[\r\n]+/g, ' ');
    if (!text) throw new HttpErr(400, 'Введите сообщение');
    const to = ctx.body.to ? String(ctx.body.to) : '';
    if (to && !PLAYER_RE.test(to)) throw new HttpErr(400, 'Неверный ник');
    const name = ctx.user.display_name || ctx.user.login;
    const parts = to
      ? [{ text: '[ЛС от ', color: 'light_purple' }, { text: name, color: 'gold' }, { text: '] ', color: 'light_purple' }, { text: text, color: 'white' }]
      : [{ text: '[Панель] ', color: 'aqua' }, { text: name, color: 'gold' }, { text: ': ', color: 'gray' }, { text: text, color: 'white' }];
    const r = await C.runCommand(ctx.server, `tellraw ${to || '@a'} ${JSON.stringify(['', ...parts])}`);
    if (!r.ok) throw new HttpErr(502, r.error || 'Не удалось отправить');
    C.insertEvent(ctx.server.id, now(), 'chat', name.slice(0, 16), (to ? `→ ${to}: ` : '') + text, { panel: true, by: ctx.user.login, to: to || undefined });
    C.broadcast('events', {}, ctx.server.id);
    A.audit(ctx.user, 'chat.send', ctx.server.name, { to: to || null, text }, ctx.ip);
    return { ok: true };
  });

  /* ═════════ Управление сервером ═════════ */
  const oneOf = (v, list, label) => { v = String(v || ''); if (!list.includes(v)) throw new HttpErr(400, `${label}: ${list.join(', ')}`); return v; };
  const player = v => { v = String(v || '').trim(); if (!PLAYER_RE.test(v)) throw new HttpErr(400, 'Укажите ник игрока'); return v; };
  const json = o => JSON.stringify(o);
  const ACTIONS = {
    save: { perm: 'control', label: 'Сохранение мира', cmd: () => 'save-all' },
    say: { perm: 'control', label: 'Объявление', cmd: b => { const t = clean(b.text, 200); if (!t) throw new HttpErr(400, 'Введите текст'); return `tellraw @a ${json(['', { text: '[Объявление] ', color: 'gold', bold: true }, { text: t, color: 'yellow' }])}`; } },
    title: { perm: 'control', label: 'Титр на экране', cmd: b => { const t = clean(b.text, 80); if (!t) throw new HttpErr(400, 'Введите текст'); return `title @a title ${json({ text: t, color: 'gold' })}`; } },
    time: { perm: 'control', label: 'Время', cmd: b => `time set ${oneOf(b.value, ['day', 'noon', 'night', 'midnight'], 'Время')}` },
    weather: { perm: 'control', label: 'Погода', cmd: b => `weather ${oneOf(b.value, ['clear', 'rain', 'thunder'], 'Погода')}` },
    gamemode: { perm: 'control', label: 'Режим игры', cmd: b => `gamemode ${oneOf(b.value, ['survival', 'creative', 'adventure', 'spectator'], 'Режим')} ${player(b.player)}` },
    tp: { perm: 'control', label: 'Телепорт', cmd: b => `tp ${player(b.player)} ${player(b.target)}` },
    heal: { perm: 'control', label: 'Восстановить здоровье', cmd: b => `effect give ${player(b.player)} minecraft:instant_health 1 5` },
    whitelist_reload: { perm: 'control', label: 'Перечитать вайтлист', cmd: () => 'whitelist reload' },
    list: { perm: 'control', label: 'Список игроков', cmd: () => 'list' },
    difficulty: { perm: 'control.admin', label: 'Сложность', cmd: b => `difficulty ${oneOf(b.value, ['peaceful', 'easy', 'normal', 'hard'], 'Сложность')}` },
    op: { perm: 'control.admin', label: 'Выдать оператора', cmd: b => `op ${player(b.player)}` },
    deop: { perm: 'control.admin', label: 'Снять оператора', cmd: b => `deop ${player(b.player)}` },
    give: { perm: 'control.admin', label: 'Выдать предмет', cmd: b => {
      const item = normItem(b.item); if (!ITEM_RE.test(item)) throw new HttpErr(400, 'Неверный предмет, например diamond');
      const n = Math.min(2304, Math.max(1, parseInt(b.amount, 10) || 1));
      return `give ${player(b.player)} minecraft:${item} ${n}`;
    } },
    stop: { perm: 'control.admin', label: 'Остановка сервера', cmd: () => 'stop' },
    start: { perm: 'control.admin', label: 'Запуск сервера', cmd: () => '@@start' },
    restart: { perm: 'control.admin', label: 'Перезапуск сервера', cmd: () => '@@restart' },
  };
  route('GET', '/api/servers/:id/control', { perm: 'control', server: true }, ctx => ({
    online: q.all('SELECT name FROM players WHERE server_id=? AND online=1 ORDER BY name', ctx.server.id).map(p => p.name),
    server: C.publicServer(ctx.server),
    admin: A.can(ctx.user, 'control.admin'),
  }));
  route('POST', '/api/servers/:id/control', { perm: 'control', server: true }, async ctx => {
    const a = ACTIONS[ctx.body.action];
    if (!a) throw new HttpErr(400, 'Неизвестное действие');
    if (!A.can(ctx.user, a.perm)) throw new HttpErr(403, 'Недостаточно прав для этого действия');
    const cmd = a.cmd(ctx.body);
    const r = await C.runCommand(ctx.server, cmd);
    const t = now();
    q.run('INSERT INTO console_lines(server_id,ts,level,line) VALUES(?,?,?,?)', ctx.server.id, t, 'CMD', `${ctx.user.login}> ${cmd.startsWith('@@') ? cmd.slice(2) : cmd}`.slice(0, 1500));
    const text = r.ok ? r.response : r.error;
    if (text) for (const ln of String(text).split('\n').slice(0, 50)) q.run('INSERT INTO console_lines(server_id,ts,level,line) VALUES(?,?,?,?)', ctx.server.id, t, r.ok ? 'RCON' : 'ERROR', ln.slice(0, 1500));
    A.audit(ctx.user, 'control.' + ctx.body.action, ctx.server.name, { label: a.label, ok: r.ok, player: ctx.body.player, value: ctx.body.value }, ctx.ip);
    C.broadcast('console', {}, ctx.server.id);
    if (['start', 'restart', 'stop'].includes(ctx.body.action) && r.ok) C.notify('server', `${a.label}: ${ctx.server.name}`, `Выполнил ${ctx.user.login}`, ctx.server.id, `#/s/${ctx.server.id}/status`);
    return { ok: r.ok, label: a.label, response: r.ok ? (r.response || '') : undefined, error: r.ok ? undefined : r.error };
  });

  /* ═════════ Минималки на предметы ═════════ */
  function itemsData(server, ws) {
    const we = ws + 7 * 864e5;
    const norms = q.all('SELECT role,item,amount FROM item_norms WHERE server_id=? ORDER BY role,item', server.id);
    const users = q.all("SELECT * FROM users WHERE disabled=0 AND mc_nick IS NOT NULL AND mc_nick<>'' ORDER BY id").filter(u => A.canServer(u, server.id));
    const staff = users.map(u => {
      const need = norms.filter(n => n.role === u.role);
      const items = need.map(n => {
        const have = q.get('SELECT COALESCE(SUM(amount),0) s FROM item_log WHERE server_id=? AND player=? AND item=? AND ts>=? AND ts<?', server.id, u.mc_nick, n.item, ws, we).s;
        return { item: n.item, need: n.amount, have };
      });
      return { id: u.id, login: u.login, name: u.display_name || u.login, role: u.role, mc_nick: u.mc_nick, items, done: items.length ? items.every(i => i.have >= i.need) : null };
    });
    const log = q.all('SELECT * FROM item_log WHERE server_id=? AND ts>=? AND ts<? ORDER BY id DESC LIMIT 100', server.id, ws, we);
    return { week_start: ws, week_end: we, norms, staff, log };
  }
  route('GET', '/api/servers/:id/items', { perm: 'quotas.view', server: true }, ctx => {
    const w = Number(ctx.query.week);
    return itemsData(ctx.server, weekStart(Number.isFinite(w) && w > 0 ? w : now()));
  });
  route('PUT', '/api/servers/:id/items/norms', { perm: 'quotas', server: true }, ctx => {
    const list = Array.isArray(ctx.body.norms) ? ctx.body.norms : [];
    const clean2 = [];
    for (const n of list.slice(0, 200)) {
      const item = normItem(n.item), amount = Math.floor(Number(n.amount));
      if (!ITEM_RE.test(item)) throw new HttpErr(400, `Неверный предмет: ${n.item}`);
      if (!A.roles()[n.role] || n.role === 'owner') throw new HttpErr(400, 'Неверная роль');
      if (!(amount >= 1 && amount <= 1000000)) throw new HttpErr(400, 'Количество от 1 до 1 000 000');
      clean2.push({ role: n.role, item, amount });
    }
    tx(() => {
      q.run('DELETE FROM item_norms WHERE server_id=?', ctx.server.id);
      for (const n of clean2) q.run('INSERT OR REPLACE INTO item_norms(server_id,role,item,amount) VALUES(?,?,?,?)', ctx.server.id, n.role, n.item, n.amount);
    });
    A.audit(ctx.user, 'items.norms', ctx.server.name, { count: clean2.length }, ctx.ip);
  });
  route('POST', '/api/servers/:id/items/log', { perm: 'items', server: true }, ctx => {
    const u = q.get('SELECT * FROM users WHERE id=?', Number(ctx.body.user_id));
    if (!u || !u.mc_nick || !A.canServer(u, ctx.server.id)) throw new HttpErr(400, 'Выберите сотрудника с ником в Minecraft');
    const item = normItem(ctx.body.item), amount = Math.floor(Number(ctx.body.amount));
    if (!ITEM_RE.test(item)) throw new HttpErr(400, 'Неверный предмет, например diamond');
    if (!(amount >= 1 && amount <= 1000000)) throw new HttpErr(400, 'Количество от 1 до 1 000 000');
    const r = q.run("INSERT INTO item_log(server_id,player,item,amount,ts,source,by_user) VALUES(?,?,?,?,?,'manual',?)", ctx.server.id, u.mc_nick, item, amount, now(), ctx.user.login);
    A.audit(ctx.user, 'items.add', `${ctx.server.name}: ${u.login}`, { item, amount }, ctx.ip);
    return { id: Number(r.lastInsertRowid) };
  });
  route('DELETE', '/api/servers/:id/items/log/:lid', { perm: 'items', server: true }, ctx => {
    const r = q.get('SELECT * FROM item_log WHERE id=? AND server_id=?', ctx.params.lid, ctx.server.id);
    if (!r) throw new HttpErr(404, 'Запись не найдена');
    q.run('DELETE FROM item_log WHERE id=?', r.id);
    A.audit(ctx.user, 'items.delete', `${ctx.server.name}: ${r.player}`, { item: r.item, amount: r.amount }, ctx.ip);
  });

  // ── Сервер Minecraft на этом же ПК (локальный режим) ──
  const L = require('./local');
  const { getSetting, setSetting } = require('./db');
  route('GET', '/api/local', { perm: 'system' }, async () => { await L.recheckRcon(); return L.status(); });
  // команда запуска выполняется на ПК — менять её может только владелец
  const ownerOnly = ctx => { if (ctx.user.role !== 'owner') throw new HttpErr(403, 'Только владелец может менять настройки сервера на этом ПК'); };
  route('PUT', '/api/local', { perm: 'system' }, ctx => {
    ownerOnly(ctx);
    const b = ctx.body || {};
    if (b.start_cmd !== undefined) {
      const c = clean(b.start_cmd, 300);
      if (/[\r\n]/.test(c)) throw new HttpErr(400, 'Команда запуска — одна строка');
      setSetting('local_start_cmd', c);
    }
    if (b.dir !== undefined) {
      try { L.setDir(b.dir); } catch (e) { throw new HttpErr(e.status || 400, e.message); }
    } else if (b.start_cmd !== undefined && L.status().on) L.setDir(getSetting('local_mc_dir') || L.status().dir);
    A.audit(ctx.user, 'local.update', null, { dir: b.dir, start_cmd: b.start_cmd }, ctx.ip);
    return L.status();
  });
  route('POST', '/api/local/off', { perm: 'system' }, ctx => {
    ownerOnly(ctx);
    L.turnOff();
    A.audit(ctx.user, 'local.off', null, {}, ctx.ip);
    return L.status();
  });
};
