'use strict';
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { q, tx, db, DB_FILE, likeEscape } = require('./db');
const A = require('./auth');
const C = require('./core');
const X = require('./extra');
const { HttpErr, clean, cleanText, parseDuration, validName, weekStart } = require('./util');

const now = () => Date.now();
const VERSION = '1.3.0';
let AGENT_VERSION = '0';
try { AGENT_VERSION = (/const VERSION = '([^']+)'/.exec(fs.readFileSync(path.join(__dirname, '..', 'agent', 'agent.js'), 'utf8')) || [])[1] || '0'; } catch {}
const START = now();

function pubServer(u, s) {
  const p = C.publicServer(s);
  if (!A.can(u, 'servers.manage')) { delete p.host; delete p.port; delete p.rcon_port; delete p.templates; delete p.api_key_hint; }
  return p;
}
function pubUser(u) {
  return { id: u.id, login: u.login, display_name: u.display_name, role: u.role, role_label: (A.roles()[u.role] || {}).label || u.role, mc_nick: u.mc_nick, servers: u.servers, discord_name: u.discord_name || null };
}
function genKey() { return 'mcp_' + crypto.randomBytes(24).toString('base64url'); }
function intIn(v, def, min, max) { const n = parseInt(v, 10); return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : def; }
function idList(user) { const ids = C.visibleServers(user).map(s => s.id); return ids.length ? ids.join(',') : '0'; }
function parseData(row) {
  let d = null;
  if (row.data) { try { d = JSON.parse(row.data); } catch {} }
  return d;
}
function parseNames(v) {
  const arr = Array.isArray(v) ? v : String(v || '').split(/[\s,;]+/);
  return [...new Set(arr.map(x => String(x).trim()).filter(Boolean))];
}

module.exports = function register(route) {
  // ═══════════ Авторизация ═══════════
  route('POST', '/api/login', { auth: false }, ctx => {
    const { login, password } = ctx.body;
    if (typeof login !== 'string' || typeof password !== 'string' || login.length > 64 || password.length > 200) throw new HttpErr(400, 'Введите логин и пароль');
    const lock = A.lockLeft(ctx.ip, login);
    if (lock) throw new HttpErr(429, `Слишком много попыток входа. Повторите через ${Math.ceil(lock / 60)} мин.`);
    const u = q.get('SELECT * FROM users WHERE login=?', login);
    const okPass = A.verifyPassword(password, u ? u.pass_hash : A.DUMMY_HASH);
    if (!u || !okPass || u.disabled) {
      A.recordFail(ctx.ip, login);
      A.audit(null, 'login.fail', login, null, ctx.ip);
      throw new HttpErr(401, 'Неверный логин или пароль');
    }
    A.recordSuccess(ctx.ip, login);
    const token = A.createSession(u.id, ctx.ip, ctx.req.headers['user-agent']);
    q.run('UPDATE users SET last_login=? WHERE id=?', now(), u.id);
    A.audit(u, 'login', null, null, ctx.ip);
    ctx.setSession(token);
    if (u.role === 'owner' && !process.env.PUBLIC_URL) {
      const host = ctx.req.headers['x-forwarded-host'] || ctx.req.headers.host;
      const proto = ctx.req.headers['x-forwarded-proto'] || 'http';
      if (host && /^[\w.\-:]+$/.test(host)) X.setSetting('public_url', `${proto}://${host}`);
    }
    return { ok: true };
  });

  route('POST', '/api/logout', {}, ctx => {
    A.audit(ctx.user, 'logout', null, null, ctx.ip);
    A.destroySession(ctx.token);
    ctx.clearSession();
  });

  route('GET', '/api/me', {}, ctx => {
    const u = ctx.user;
    const unread = q.all('SELECT id,server_id FROM notifications WHERE id>?', u.notif_read).filter(n => !n.server_id || A.canServer(u, n.server_id)).length;
    return {
      user: pubUser(u), perms: A.permsOf(u),
      roles: Object.fromEntries(Object.entries(A.roles()).map(([k, v]) => [k, v.label])),
      features: A.FEATURES,
    has_apk: require('fs').existsSync(require('path').join(require('./db').DATA_DIR, 'app.apk')),
    role_list: Object.values(A.roles()).map(r => ({ key: r.key, label: r.label, color: r.color, description: r.description })),
      role_perms: Object.fromEntries(Object.entries(A.roles()).map(([k, v]) => [k, v.perms])),
      perm_catalog: A.PERM_CATALOG,
      servers: C.visibleServers(u).map(s => pubServer(u, s)),
      online_total: C.totalOnline(u), unread,
    };
  });

  route('POST', '/api/me/password', {}, ctx => {
    const { old_password, new_password } = ctx.body;
    if (!A.verifyPassword(String(old_password || ''), ctx.user.pass_hash)) throw new HttpErr(400, 'Текущий пароль неверен');
    if (!A.validPassword(new_password)) throw new HttpErr(400, 'Новый пароль: от 8 до 128 символов');
    q.run('UPDATE users SET pass_hash=?, pw_changed=1 WHERE id=?', A.hashPassword(new_password), ctx.user.id);
    A.destroyUserSessions(ctx.user.id, ctx.token);
    A.audit(ctx.user, 'password.change', ctx.user.login, null, ctx.ip);
  });

  route('GET', '/api/stream', {}, ctx => {
    ctx.res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    ctx.res.write('retry: 3000\n\n');
    C.sseAdd(ctx.res, ctx.user);
    ctx.handled = true;
  });

  // ═══════════ Обзор ═══════════
  route('GET', '/api/overview', {}, ctx => {
    const u = ctx.user, ids = idList(u), t = now(), d1 = t - 864e5;
    const servers = C.visibleServers(u);
    const one = (sql, ...p) => q.get(sql, ...p).c;
    const totals = {
      online: C.totalOnline(u),
      servers_up: servers.filter(s => s.online).length,
      servers_total: servers.length,
      open_reports: one(`SELECT COUNT(*) c FROM reports WHERE server_id IN (${ids}) AND status<>'closed'`),
      punishments_24h: one(`SELECT COUNT(*) c FROM punishments WHERE server_id IN (${ids}) AND created_at>? AND type IN ('ban','mute','kick','warn')`, d1),
      events_24h: one(`SELECT COUNT(*) c FROM events WHERE server_id IN (${ids}) AND ts>?`, d1),
      new_players_24h: one(`SELECT COUNT(*) c FROM players WHERE server_id IN (${ids}) AND first_seen>?`, d1),
      players_total: one(`SELECT COUNT(*) c FROM players WHERE server_id IN (${ids})`),
    };
    const chart = q.all(`SELECT b AS ts, SUM(a) AS online FROM (SELECT server_id, ts/900000*900000 AS b, AVG(online) AS a
      FROM online_samples WHERE server_id IN (${ids}) AND ts>? GROUP BY server_id, b) GROUP BY b ORDER BY b`, d1)
      .map(r => ({ ts: r.ts, online: Math.round(r.online * 10) / 10 }));
    const recent = !A.can(u, 'logs') ? [] : q.all(`SELECT e.id,e.ts,e.type,e.player,e.message,e.server_id,s.name AS server FROM events e JOIN servers s ON s.id=e.server_id
      WHERE e.server_id IN (${ids}) AND e.type IN ('punishment','report','status','server_start','server_stop','agent','error') ORDER BY e.id DESC LIMIT 12`);
    const reports = !A.can(u, 'reports') ? [] : q.all(`SELECT r.id,r.server_id,r.reporter,r.target,r.reason,r.status,r.created_at,s.name AS server FROM reports r JOIN servers s ON s.id=r.server_id
      WHERE r.server_id IN (${ids}) AND r.status<>'closed' ORDER BY r.id DESC LIMIT 6`);
    return { totals, chart, recent, reports, servers: servers.map(s => pubServer(u, s)) };
  });

  // ═══════════ Серверы ═══════════
  function readServerBody(b, partial) {
    const o = {};
    if (!partial || b.name !== undefined) {
      const name = clean(b.name, 40);
      if (!name) throw new HttpErr(400, 'Укажите название сервера');
      o.name = name;
    }
    if (b.host !== undefined) {
      const h = clean(b.host, 255);
      if (h && !/^[A-Za-z0-9.\-_:]+$/.test(h)) throw new HttpErr(400, 'Некорректный адрес сервера');
      o.host = h || null;
    }
    if (b.port !== undefined && b.port !== '') o.port = intIn(b.port, 25565, 1, 65535);
    if (b.rcon_mode !== undefined) {
      if (!['agent', 'direct'].includes(b.rcon_mode)) throw new HttpErr(400, 'Неверный режим RCON');
      o.rcon_mode = b.rcon_mode;
    }
    if (b.rcon_port !== undefined) o.rcon_port = b.rcon_port === '' || b.rcon_port == null ? null : intIn(b.rcon_port, 25575, 1, 65535);
    if (b.rcon_password) o.rcon_password = String(b.rcon_password).slice(0, 200);
    if (b.clear_rcon_password) o.rcon_password = null;
    if (b.color !== undefined) {
      if (!/^#[0-9a-fA-F]{6}$/.test(b.color)) throw new HttpErr(400, 'Цвет в формате #RRGGBB');
      o.color = b.color;
    }
    return o;
  }

  route('POST', '/api/servers', { perm: 'servers.manage' }, ctx => {
    const o = readServerBody(ctx.body, false);
    if (o.rcon_mode === 'direct' && !o.host) throw new HttpErr(400, 'Для прямого RCON нужен адрес сервера');
    const key = genKey();
    const r = q.run(`INSERT INTO servers(name,host,port,api_key_hash,api_key_hint,rcon_mode,rcon_port,rcon_password,color,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)`,
      o.name, o.host || null, o.port || 25565, A.sha(key), key.slice(-4), o.rcon_mode || 'agent', o.rcon_port || null, o.rcon_password || null, o.color || '#4f7cff', now());
    const s = C.getServer(r.lastInsertRowid);
    X.createDefaultRules(s.id);
    A.audit(ctx.user, 'server.create', s.name, { id: s.id }, ctx.ip);
    C.pollAll();
    return { server: pubServer(ctx.user, s), api_key: key };
  });

  route('PATCH', '/api/servers/:id', { perm: 'servers.manage', server: true }, ctx => {
    const b = ctx.body, o = readServerBody(b, true);
    if (b.templates && typeof b.templates === 'object') {
      const cur = C.templatesOf(ctx.server);
      for (const k of Object.keys(C.DEFAULT_TEMPLATES)) {
        if (typeof b.templates[k] === 'string') cur[k] = clean(b.templates[k], 200) || C.DEFAULT_TEMPLATES[k];
      }
      o.templates = JSON.stringify(cur);
    }
    const keys = Object.keys(o);
    if (keys.length) q.run(`UPDATE servers SET ${keys.map(k => k + '=?').join(',')} WHERE id=?`, ...keys.map(k => o[k]), ctx.server.id);
    const s = C.getServer(ctx.server.id);
    if (s.rcon_mode === 'direct' && !s.host) throw new HttpErr(400, 'Для прямого RCON нужен адрес сервера');
    A.audit(ctx.user, 'server.update', s.name, Object.fromEntries(keys.filter(k => k !== 'rcon_password').map(k => [k, o[k]])), ctx.ip);
    C.pollAll();
    return { server: pubServer(ctx.user, s) };
  });

  route('DELETE', '/api/servers/:id', { perm: 'servers.manage', server: true }, ctx => {
    if (clean(ctx.body.confirm, 80) !== ctx.server.name) throw new HttpErr(400, 'Для удаления введите точное название сервера');
    tx(() => {
      q.run('DELETE FROM online_samples WHERE server_id=?', ctx.server.id);
      q.run('DELETE FROM play_sessions WHERE server_id=?', ctx.server.id);
      q.run('DELETE FROM player_ips WHERE server_id=?', ctx.server.id);
      q.run('DELETE FROM notifications WHERE server_id=?', ctx.server.id);
      q.run('DELETE FROM servers WHERE id=?', ctx.server.id);
    });
    A.audit(ctx.user, 'server.delete', ctx.server.name, { id: ctx.server.id }, ctx.ip);
  });

  route('POST', '/api/servers/:id/key', { perm: 'servers.manage', server: true }, ctx => {
    const key = genKey();
    q.run('UPDATE servers SET api_key_hash=?, api_key_hint=?, last_agent=NULL WHERE id=?', A.sha(key), key.slice(-4), ctx.server.id);
    A.audit(ctx.user, 'server.key', ctx.server.name, null, ctx.ip);
    return { api_key: key };
  });

  route('POST', '/api/servers/:id/refresh', { perm: 'status', server: true }, async ctx => {
    await C.pollAll();
    return { server: pubServer(ctx.user, C.getServer(ctx.server.id)) };
  });

  route('GET', '/api/servers/:id/status', { perm: 'status', server: true }, ctx => {
    const s = ctx.server, t = now();
    const samples = q.all(`SELECT ts/300000*300000 AS ts, MAX(up) AS up, ROUND(AVG(online),1) AS online, MAX(max) AS max, ROUND(AVG(latency)) AS latency
      FROM online_samples WHERE server_id=? AND ts>? GROUP BY ts/300000 ORDER BY ts`, s.id, t - 864e5);
    const up = (from) => {
      const r = q.get('SELECT AVG(up) a, COUNT(*) n FROM online_samples WHERE server_id=? AND ts>?', s.id, from);
      return r.n ? Math.round(r.a * 1000) / 10 : null;
    };
    const counts = {
      players: q.get('SELECT COUNT(*) c FROM players WHERE server_id=?', s.id).c,
      events_24h: q.get('SELECT COUNT(*) c FROM events WHERE server_id=? AND ts>?', s.id, t - 864e5).c,
      last_event: q.get('SELECT MAX(ts) m FROM events WHERE server_id=?', s.id).m,
    };
    const all = C.visibleServers(ctx.user).map(x => pubServer(ctx.user, x));
    return { server: pubServer(ctx.user, s), samples, uptime: { h24: up(t - 864e5), d7: up(t - 7 * 864e5) }, counts, all };
  });

  route('POST', '/api/servers/:id/rcon-test', { server: true }, async ctx => {
    if (!A.can(ctx.user, 'console') && !A.can(ctx.user, 'servers.manage')) throw new HttpErr(403, 'Недостаточно прав');
    const t0 = now();
    const r = await C.runCommand(ctx.server, 'list');
    return { ...r, ms: now() - t0 };
  });

  // ═══════════ Логи событий ═══════════
  route('GET', '/api/servers/:id/events', { perm: 'logs', server: true }, ctx => {
    const Q = ctx.query, where = ['server_id=?'], params = [ctx.server.id];
    const limit = intIn(Q.limit, 100, 1, 500);
    if (Q.types) {
      const t = String(Q.types).split(',').filter(x => /^[a-z0-9_.-]{1,32}$/.test(x)).slice(0, 30);
      if (t.length) { where.push(`type IN (${t.map(() => '?').join(',')})`); params.push(...t); }
    }
    if (Q.player) { where.push('player=? COLLATE NOCASE'); params.push(String(Q.player).slice(0, 40)); }
    if (Q.q) {
      const l = '%' + likeEscape(String(Q.q).slice(0, 100)) + '%';
      where.push("(message LIKE ? ESCAPE '\\' OR player LIKE ? ESCAPE '\\')"); params.push(l, l);
    }
    if (Q.from) { where.push('ts>=?'); params.push(Number(Q.from) || 0); }
    if (Q.to) { where.push('ts<=?'); params.push(Number(Q.to) || now()); }
    let order = 'DESC';
    if (Q.after) { where.push('id>?'); params.push(Number(Q.after) || 0); order = 'ASC'; }
    else if (Q.before) { where.push('id<?'); params.push(Number(Q.before) || 0); }
    const rows = q.all(`SELECT id,ts,type,player,message,data FROM events WHERE ${where.join(' AND ')} ORDER BY id ${order} LIMIT ?`, ...params, limit + 1);
    const has_more = rows.length > limit;
    if (has_more) rows.pop();
    if (order === 'ASC') rows.reverse();
    const ips = A.can(ctx.user, 'ips');
    const items = rows.map(r => {
      const d = parseData(r);
      if (d && !ips) delete d.ip;
      return { id: r.id, ts: r.ts, type: r.type, player: r.player, message: r.message, data: d };
    });
    return { items, has_more };
  });

  route('GET', '/api/servers/:id/event-types', { perm: 'logs', server: true }, ctx => ({
    types: q.all('SELECT type, COUNT(*) AS c FROM events WHERE server_id=? AND ts>? GROUP BY type ORDER BY c DESC', ctx.server.id, now() - 7 * 864e5),
  }));

  // ═══════════ Консоль ═══════════
  route('GET', '/api/servers/:id/console', { perm: 'console', server: true }, ctx => {
    const after = Number(ctx.query.after) || 0;
    let rows;
    if (after) rows = q.all('SELECT id,ts,level,line FROM console_lines WHERE server_id=? AND id>? ORDER BY id LIMIT 500', ctx.server.id, after);
    else rows = q.all('SELECT id,ts,level,line FROM console_lines WHERE server_id=? ORDER BY id DESC LIMIT 300', ctx.server.id).reverse();
    return { lines: rows, can_command: C.canCommand(ctx.server) };
  });

  route('POST', '/api/servers/:id/console', { perm: 'console', server: true }, async ctx => {
    const command = clean(ctx.body.command, 500).replace(/^\//, '');
    if (!command) throw new HttpErr(400, 'Введите команду');
    if (command.startsWith('@@')) throw new HttpErr(400, 'Неизвестная команда');
    const r = await C.runCommand(ctx.server, command);
    const t = now();
    q.run('INSERT INTO console_lines(server_id,ts,level,line) VALUES(?,?,?,?)', ctx.server.id, t, 'CMD', `${ctx.user.login}> ${command}`);
    const text = r.ok ? r.response : r.error;
    if (text) for (const ln of String(text).split('\n').slice(0, 100)) q.run('INSERT INTO console_lines(server_id,ts,level,line) VALUES(?,?,?,?)', ctx.server.id, t, r.ok ? 'RCON' : 'ERROR', ln.slice(0, 1500));
    else if (r.ok) q.run('INSERT INTO console_lines(server_id,ts,level,line) VALUES(?,?,?,?)', ctx.server.id, t, 'RCON', '(пустой ответ)');
    A.audit(ctx.user, 'console.exec', ctx.server.name, { command, ok: r.ok }, ctx.ip);
    C.broadcast('console', {}, ctx.server.id);
    return r;
  });

  // ═══════════ Онлайн ═══════════
  route('GET', '/api/servers/:id/online', { perm: 'online', server: true }, ctx => {
    const s = ctx.server, t = now();
    const range = { '24h': 864e5, '7d': 7 * 864e5, '30d': 30 * 864e5 }[ctx.query.range] || 864e5;
    const bucket = Math.max(60000, Math.round(range / 160 / 60000) * 60000);
    const chart = q.all(`SELECT ts/?*? AS ts, ROUND(AVG(online),1) AS online, MAX(online) AS peak FROM online_samples WHERE server_id=? AND ts>? GROUP BY ts/? ORDER BY ts`,
      bucket, bucket, s.id, t - range, bucket);
    const players = q.all(`SELECT p.name, p.last_world, p.client_brand, p.playtime,
      (SELECT joined FROM play_sessions x WHERE x.player_id=p.id AND x.left IS NULL ORDER BY x.id DESC LIMIT 1) AS since,
      (SELECT COUNT(*) FROM punishments m WHERE m.server_id=p.server_id AND m.player=p.name AND m.active=1 AND m.type='mute') AS muted
      FROM players p WHERE p.server_id=? AND p.online=1 ORDER BY p.name`, s.id);
    const peak = q.get('SELECT MAX(online) m, AVG(online) a FROM online_samples WHERE server_id=? AND ts>?', s.id, t - range);
    const uniq = d => q.get('SELECT COUNT(DISTINCT player_id) c FROM play_sessions WHERE server_id=? AND COALESCE(left,?)>?', s.id, t, t - d).c;
    return {
      server: pubServer(ctx.user, s), players, chart,
      peak: peak.m || 0, avg: peak.a ? Math.round(peak.a * 10) / 10 : 0,
      unique_24h: uniq(864e5), unique_7d: uniq(7 * 864e5),
      joins_24h: q.get("SELECT COUNT(*) c FROM events WHERE server_id=? AND type='join' AND ts>?", s.id, t - 864e5).c,
    };
  });

  // ═══════════ Игроки ═══════════
  route('GET', '/api/servers/:id/players', { perm: 'players', server: true }, ctx => {
    const Q = ctx.query, sid = ctx.server.id, where = ['p.server_id=?'], params = [sid];
    if (Q.q) { where.push("p.name LIKE ? ESCAPE '\\'"); params.push('%' + likeEscape(String(Q.q).slice(0, 40)) + '%'); }
    const f = Q.filter;
    if (f === 'online') where.push('p.online=1');
    if (f === 'banned') where.push("EXISTS(SELECT 1 FROM punishments x WHERE x.server_id=p.server_id AND x.player=p.name AND x.active=1 AND x.type='ban')");
    if (f === 'muted') where.push("EXISTS(SELECT 1 FROM punishments x WHERE x.server_id=p.server_id AND x.player=p.name AND x.active=1 AND x.type='mute')");
    const sort = { last: 'p.last_seen DESC', playtime: 'p.playtime DESC', name: 'p.name ASC', joins: 'p.joins DESC', first: 'p.first_seen DESC' }[Q.sort] || 'p.last_seen DESC';
    const limit = intIn(Q.limit, 50, 1, 200), offset = (intIn(Q.page, 1, 1, 100000) - 1) * limit;
    const total = q.get(`SELECT COUNT(*) c FROM players p WHERE ${where.join(' AND ')}`, ...params).c;
    const rows = q.all(`SELECT p.name,p.uuid,p.online,p.first_seen,p.last_seen,p.joins,p.last_ip,
      p.playtime + COALESCE((SELECT (${now()} - s.joined)/1000 FROM play_sessions s WHERE s.player_id=p.id AND s.left IS NULL),0) AS playtime,
      (SELECT COUNT(*) FROM punishments x WHERE x.server_id=p.server_id AND x.player=p.name AND x.active=1 AND x.type='ban') AS banned,
      (SELECT COUNT(*) FROM punishments x WHERE x.server_id=p.server_id AND x.player=p.name AND x.active=1 AND x.type='mute') AS muted
      FROM players p WHERE ${where.join(' AND ')} ORDER BY ${sort} LIMIT ? OFFSET ?`, ...params, limit, offset);
    const ips = A.can(ctx.user, 'ips');
    if (!ips) rows.forEach(r => delete r.last_ip);
    return { items: rows, total, page: Math.floor(offset / limit) + 1, pages: Math.max(1, Math.ceil(total / limit)) };
  });

  route('GET', '/api/servers/:id/players/:name', { perm: 'players', server: true }, ctx => {
    const sid = ctx.server.id;
    const p = q.get('SELECT * FROM players WHERE server_id=? AND name=?', sid, ctx.params.name);
    if (!p) throw new HttpErr(404, 'Игрок не найден');
    const ips = A.can(ctx.user, 'ips');
    const sessions = q.all('SELECT joined, left FROM play_sessions WHERE player_id=? ORDER BY id DESC LIMIT 30', p.id);
    const out = {
      player: { name: p.name, uuid: p.uuid, online: !!p.online, first_seen: p.first_seen, last_seen: p.last_seen, joins: p.joins,
        playtime: p.playtime + (sessions[0] && !sessions[0].left ? Math.round((now() - sessions[0].joined) / 1000) : 0),
        client_brand: p.client_brand, client_version: p.client_version, last_world: p.last_world, last_ip: ips ? p.last_ip : undefined },
      sessions,
      punishments: q.all('SELECT * FROM punishments WHERE server_id=? AND player=? ORDER BY id DESC LIMIT 100', sid, p.name),
      notes: q.all('SELECT id,ts,user_id,user_name,text FROM notes WHERE server_id=? AND player=? ORDER BY id DESC', sid, p.name),
      reports_against: q.all('SELECT id,reporter,reason,status,created_at FROM reports WHERE server_id=? AND target=? ORDER BY id DESC LIMIT 30', sid, p.name),
      reports_by: q.all('SELECT id,target,reason,status,created_at FROM reports WHERE server_id=? AND reporter=? ORDER BY id DESC LIMIT 30', sid, p.name),
      stats: Object.fromEntries(q.all('SELECT type, COUNT(*) c FROM events WHERE server_id=? AND player=? GROUP BY type', sid, p.name).map(r => [r.type, r.c])),
      whitelisted: !!q.get('SELECT 1 x FROM whitelist WHERE server_id=? AND name=?', sid, p.name),
    };
    out.punishments.forEach(x => { x.response = undefined; });
    if (ips) {
      out.ips = q.all('SELECT ip, first_seen, last_seen, cnt FROM player_ips WHERE player_id=? ORDER BY last_seen DESC', p.id);
      out.alts = q.all(`SELECT p2.name, p2.online, p2.last_seen,
        (SELECT COUNT(*) FROM punishments x WHERE x.server_id=p2.server_id AND x.player=p2.name AND x.active=1 AND x.type='ban') AS banned,
        GROUP_CONCAT(DISTINCT a.ip) AS shared_ips
        FROM player_ips a JOIN player_ips b ON b.ip=a.ip AND b.server_id=a.server_id AND b.player_id<>a.player_id
        JOIN players p2 ON p2.id=b.player_id WHERE a.player_id=? GROUP BY p2.id ORDER BY p2.last_seen DESC LIMIT 50`, p.id);
    }
    return out;
  });

  route('POST', '/api/servers/:id/players/:name/punish', { perm: 'punish', server: true }, async ctx => {
    const type = String(ctx.body.type || '');
    if ((type === 'ban' || type === 'unban') && !A.can(ctx.user, 'ban')) throw new HttpErr(403, 'У вашей роли нет права банить');
    return C.applyPunishment(ctx.user, ctx.server, {
      player: ctx.params.name, type, reason: ctx.body.reason, duration: parseDuration(ctx.body.duration), ip: ctx.ip,
    });
  });

  route('POST', '/api/punishments/:pid/retry', { perm: 'punish' }, async ctx => {
    const p = q.get('SELECT * FROM punishments WHERE id=?', ctx.params.pid);
    if (!p || !A.canServer(ctx.user, p.server_id)) throw new HttpErr(404, 'Не найдено');
    if ((p.type === 'ban' || p.type === 'unban') && !A.can(ctx.user, 'ban')) throw new HttpErr(403, 'У вашей роли нет права банить');
    return C.retryPunishment(ctx.user, p.id, ctx.ip);
  });

  route('GET', '/api/servers/:id/punishments', { perm: 'players', server: true }, ctx => {
    const Q = ctx.query, where = ['server_id=?'], params = [ctx.server.id];
    if (Q.type && ['ban', 'unban', 'kick', 'mute', 'unmute', 'warn'].includes(Q.type)) { where.push('type=?'); params.push(Q.type); }
    if (Q.active === '1') where.push('active=1');
    if (Q.q) { where.push("(player LIKE ? ESCAPE '\\' OR issued_name LIKE ? ESCAPE '\\')"); const l = '%' + likeEscape(String(Q.q).slice(0, 40)) + '%'; params.push(l, l); }
    if (Q.before) { where.push('id<?'); params.push(Number(Q.before) || 0); }
    const limit = intIn(Q.limit, 50, 1, 200);
    const rows = q.all(`SELECT id,player,type,reason,duration,created_at,expires_at,active,issued_name,source,ended_at,ended_by,applied FROM punishments WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT ?`, ...params, limit + 1);
    const has_more = rows.length > limit;
    if (has_more) rows.pop();
    return { items: rows, has_more };
  });

  route('POST', '/api/servers/:id/players/:name/notes', { perm: 'players', server: true }, ctx => {
    const text = cleanText(ctx.body.text, 1000);
    if (!text) throw new HttpErr(400, 'Пустая заметка');
    if (!validName(ctx.params.name)) throw new HttpErr(400, 'Некорректный ник');
    C.getPlayer(ctx.server.id, ctx.params.name, now());
    q.run('INSERT INTO notes(server_id,player,user_id,user_name,ts,text) VALUES(?,?,?,?,?,?)', ctx.server.id, ctx.params.name, ctx.user.id, ctx.user.display_name || ctx.user.login, now(), text);
    A.audit(ctx.user, 'note.add', `${ctx.server.name}:${ctx.params.name}`, text.slice(0, 200), ctx.ip);
  });

  route('DELETE', '/api/servers/:id/notes/:nid', { perm: 'players', server: true }, ctx => {
    const n = q.get('SELECT * FROM notes WHERE id=? AND server_id=?', ctx.params.nid, ctx.server.id);
    if (!n) throw new HttpErr(404, 'Заметка не найдена');
    if (n.user_id !== ctx.user.id && !A.can(ctx.user, 'servers.manage')) throw new HttpErr(403, 'Удалить можно только свою заметку');
    q.run('DELETE FROM notes WHERE id=?', n.id);
    A.audit(ctx.user, 'note.delete', `${ctx.server.name}:${n.player}`, null, ctx.ip);
  });

  // ═══════════ Клиент дата ═══════════
  route('GET', '/api/servers/:id/clients', { perm: 'clients', server: true }, ctx => {
    const sid = ctx.server.id, Q = ctx.query, ips = A.can(ctx.user, 'ips');
    const brands = q.all("SELECT COALESCE(client_brand,'не передан') AS name, COUNT(*) AS c FROM players WHERE server_id=? GROUP BY 1 ORDER BY c DESC LIMIT 12", sid);
    const versions = q.all("SELECT COALESCE(client_version,'не передана') AS name, COUNT(*) AS c FROM players WHERE server_id=? GROUP BY 1 ORDER BY c DESC LIMIT 12", sid);
    const platform = q.get("SELECT SUM(CASE WHEN name LIKE '.%' THEN 1 ELSE 0 END) AS bedrock, SUM(CASE WHEN name NOT LIKE '.%' THEN 1 ELSE 0 END) AS java FROM players WHERE server_id=?", sid);
    const where = ['p.server_id=?'], params = [sid];
    if (Q.q) { where.push("p.name LIKE ? ESCAPE '\\'"); params.push('%' + likeEscape(String(Q.q).slice(0, 40)) + '%'); }
    const limit = 50, offset = (intIn(Q.page, 1, 1, 100000) - 1) * limit;
    const total = q.get(`SELECT COUNT(*) c FROM players p WHERE ${where.join(' AND ')}`, ...params).c;
    const items = q.all(`SELECT p.name, p.uuid, p.client_brand, p.client_version, p.last_world, p.last_seen, p.online, p.last_ip,
      (SELECT COUNT(*) FROM player_ips i WHERE i.player_id=p.id) AS ip_count,
      (SELECT COUNT(DISTINCT b.player_id) FROM player_ips a JOIN player_ips b ON b.ip=a.ip AND b.server_id=a.server_id AND b.player_id<>a.player_id WHERE a.player_id=p.id) AS alts
      FROM players p WHERE ${where.join(' AND ')} ORDER BY p.last_seen DESC LIMIT ? OFFSET ?`, ...params, limit, offset);
    if (!ips) items.forEach(r => delete r.last_ip);
    const shared = ips ? q.all(`SELECT i.ip, COUNT(DISTINCT p.id) AS n, GROUP_CONCAT(DISTINCT p.name) AS names
      FROM player_ips i JOIN players p ON p.id=i.player_id WHERE i.server_id=? GROUP BY i.ip HAVING n>1 ORDER BY n DESC, MAX(i.last_seen) DESC LIMIT 50`, sid) : null;
    return { brands, versions, platform, items, total, pages: Math.max(1, Math.ceil(total / limit)), page: Math.floor(offset / limit) + 1, shared };
  });

  // ═══════════ Репорты ═══════════
  route('GET', '/api/servers/:id/reports', { perm: 'reports', server: true }, ctx => {
    const Q = ctx.query, where = ['r.server_id=?'], params = [ctx.server.id];
    if (Q.status === 'active') where.push("r.status<>'closed'");
    else if (['open', 'progress', 'closed'].includes(Q.status)) { where.push('r.status=?'); params.push(Q.status); }
    if (Q.q) { where.push("(r.reason LIKE ? ESCAPE '\\' OR r.target LIKE ? ESCAPE '\\' OR r.reporter LIKE ? ESCAPE '\\')"); const l = '%' + likeEscape(String(Q.q).slice(0, 60)) + '%'; params.push(l, l, l); }
    if (Q.before) { where.push('r.id<?'); params.push(Number(Q.before) || 0); }
    const limit = intIn(Q.limit, 50, 1, 200);
    const rows = q.all(`SELECT r.*, COALESCE(u.display_name,u.login) AS assignee_name,
      (SELECT COUNT(*) FROM report_comments c WHERE c.report_id=r.id) AS comments
      FROM reports r LEFT JOIN users u ON u.id=r.assignee_id WHERE ${where.join(' AND ')} ORDER BY r.id DESC LIMIT ?`, ...params, limit + 1);
    const has_more = rows.length > limit;
    if (has_more) rows.pop();
    const counts = Object.fromEntries(q.all('SELECT status, COUNT(*) c FROM reports WHERE server_id=? GROUP BY status', ctx.server.id).map(r => [r.status, r.c]));
    return { items: rows, has_more, counts };
  });

  route('POST', '/api/servers/:id/reports', { perm: 'reports', server: true }, ctx => {
    const reason = cleanText(ctx.body.reason, 1000);
    const target = ctx.body.target ? String(ctx.body.target).trim() : null;
    const reporter = ctx.body.reporter ? String(ctx.body.reporter).trim() : null;
    if (!reason) throw new HttpErr(400, 'Опишите причину репорта');
    if ((target && !validName(target)) || (reporter && !validName(reporter))) throw new HttpErr(400, 'Некорректный ник');
    const id = C.createReport(ctx.server, { reporter, target, reason, source: 'panel' });
    A.audit(ctx.user, 'report.create', `#${id}`, null, ctx.ip);
    return { id };
  });

  function loadReport(ctx) {
    const r = q.get(`SELECT r.*, s.name AS server_name, COALESCE(u.display_name,u.login) AS assignee_name, COALESCE(c.display_name,c.login) AS closed_by_name
      FROM reports r JOIN servers s ON s.id=r.server_id LEFT JOIN users u ON u.id=r.assignee_id LEFT JOIN users c ON c.id=r.closed_by WHERE r.id=?`, ctx.params.rid);
    if (!r || !A.canServer(ctx.user, r.server_id)) throw new HttpErr(404, 'Репорт не найден');
    return r;
  }
  route('GET', '/api/reports/:rid', { perm: 'reports' }, ctx => {
    const r = loadReport(ctx);
    return { report: r, comments: q.all('SELECT id,user_name,ts,text FROM report_comments WHERE report_id=? ORDER BY id', r.id) };
  });
  route('PATCH', '/api/reports/:rid', { perm: 'reports' }, ctx => {
    const r = loadReport(ctx), b = ctx.body, t = now();
    let status = r.status, assignee = r.assignee_id, resolution = r.resolution, closed_at = r.closed_at, closed_by = r.closed_by;
    if (b.status !== undefined) {
      if (!['open', 'progress', 'closed'].includes(b.status)) throw new HttpErr(400, 'Неверный статус');
      status = b.status;
      if (status === 'progress' && !assignee) assignee = ctx.user.id;
      if (status === 'closed') { closed_at = t; closed_by = ctx.user.id; if (!assignee) assignee = ctx.user.id; }
      if (status !== 'closed') { closed_at = null; closed_by = null; }
    }
    if (b.resolution !== undefined) resolution = cleanText(b.resolution, 1000) || null;
    if (b.assignee_id !== undefined) {
      if (b.assignee_id === null) assignee = null;
      else {
        const id = b.assignee_id === 'me' ? ctx.user.id : Number(b.assignee_id);
        const u = q.get('SELECT * FROM users WHERE id=? AND disabled=0', id);
        if (!u || !A.canServer(u, r.server_id)) throw new HttpErr(400, 'Исполнитель не найден');
        assignee = id;
      }
    }
    q.run('UPDATE reports SET status=?,assignee_id=?,resolution=?,closed_at=?,closed_by=?,updated_at=? WHERE id=?', status, assignee, resolution, closed_at, closed_by, t, r.id);
    A.audit(ctx.user, 'report.update', `#${r.id}`, { status, assignee, resolution }, ctx.ip);
    C.broadcast('reports', {}, r.server_id);
    return { report: loadReport(ctx) };
  });
  route('POST', '/api/reports/:rid/comments', { perm: 'reports' }, ctx => {
    const r = loadReport(ctx), text = cleanText(ctx.body.text, 1000);
    if (!text) throw new HttpErr(400, 'Пустой комментарий');
    q.run('INSERT INTO report_comments(report_id,user_id,user_name,ts,text) VALUES(?,?,?,?,?)', r.id, ctx.user.id, ctx.user.display_name || ctx.user.login, now(), text);
    q.run('UPDATE reports SET updated_at=? WHERE id=?', now(), r.id);
    C.broadcast('reports', {}, r.server_id);
  });
  route('GET', '/api/reports-staff/:id', { perm: 'reports', server: true }, ctx =>
    ({ staff: q.all('SELECT id, COALESCE(display_name,login) AS name, role, servers FROM users WHERE disabled=0').filter(u => A.canServer(u, ctx.server.id)).map(u => ({ id: u.id, name: u.name, role: u.role })) }));

  // ═══════════ Вайтлист ═══════════
  route('GET', '/api/servers/:id/whitelist', { perm: 'whitelist.view', server: true }, ctx => ({
    items: q.all('SELECT name, added_by, added_at FROM whitelist WHERE server_id=? ORDER BY name', ctx.server.id),
    can_command: C.canCommand(ctx.server),
  }));

  function wlCommand(server, type, name) {
    return C.runCommand(server, (C.templatesOf(server)[type] || '').replace('{player}', name));
  }
  route('POST', '/api/servers/:id/whitelist', { perm: 'whitelist', server: true }, async ctx => {
    const names = parseNames(ctx.body.names || ctx.body.name).slice(0, 200);
    if (!names.length) throw new HttpErr(400, 'Укажите хотя бы один ник');
    const bad = names.filter(n => !validName(n));
    if (bad.length) throw new HttpErr(400, 'Некорректные ники: ' + bad.slice(0, 5).join(', '));
    const can = C.canCommand(ctx.server);
    let added = 0, applied = 0; const errors = [];
    for (const n of names) {
      const r = q.run('INSERT OR IGNORE INTO whitelist(server_id,name,added_by,added_at) VALUES(?,?,?,?)', ctx.server.id, n, ctx.user.login, now());
      if (r.changes) added++;
      if (can) {
        const res = await wlCommand(ctx.server, 'whitelist_add', n);
        if (res.ok) applied++; else errors.push(`${n}: ${res.error}`);
      }
    }
    A.audit(ctx.user, 'whitelist.add', ctx.server.name, { names, applied }, ctx.ip);
    return { added, applied, errors: errors.slice(0, 5), synced: can };
  });
  route('DELETE', '/api/servers/:id/whitelist/:name', { perm: 'whitelist', server: true }, async ctx => {
    const name = ctx.params.name;
    q.run('DELETE FROM whitelist WHERE server_id=? AND name=?', ctx.server.id, name);
    let res = { ok: false, error: 'RCON не настроен' };
    if (C.canCommand(ctx.server) && validName(name)) res = await wlCommand(ctx.server, 'whitelist_remove', name);
    A.audit(ctx.user, 'whitelist.remove', `${ctx.server.name}:${name}`, { ok: res.ok }, ctx.ip);
    return { applied: res.ok, error: res.ok ? null : res.error };
  });
  route('POST', '/api/servers/:id/whitelist/sync', { perm: 'whitelist', server: true }, async ctx => {
    const dir = ctx.body.direction;
    if (!C.canCommand(ctx.server)) throw new HttpErr(400, 'Нет связи с сервером: подключите агента с RCON или настройте прямой RCON');
    if (dir === 'pull') {
      const r = await C.runCommand(ctx.server, 'whitelist list');
      if (!r.ok) throw new HttpErr(502, r.error);
      const text = String(r.response || '');
      const i = text.indexOf(':');
      const names = /no whitelisted/i.test(text) || i < 0 ? [] : text.slice(i + 1).split(',').map(s => s.trim()).filter(validName);
      tx(() => {
        const set = new Set(names.map(n => n.toLowerCase()));
        for (const row of q.all('SELECT name FROM whitelist WHERE server_id=?', ctx.server.id)) if (!set.has(row.name.toLowerCase())) q.run('DELETE FROM whitelist WHERE server_id=? AND name=?', ctx.server.id, row.name);
        for (const n of names) q.run('INSERT OR IGNORE INTO whitelist(server_id,name,added_by,added_at) VALUES(?,?,?,?)', ctx.server.id, n, 'server', now());
      });
      A.audit(ctx.user, 'whitelist.pull', ctx.server.name, { count: names.length }, ctx.ip);
      return { count: names.length };
    }
    if (dir === 'push') {
      const rows = q.all('SELECT name FROM whitelist WHERE server_id=? ORDER BY name LIMIT 500', ctx.server.id);
      let ok = 0; const errors = [];
      for (const row of rows) {
        const r = await wlCommand(ctx.server, 'whitelist_add', row.name);
        if (r.ok) ok++; else if (errors.length < 3) errors.push(`${row.name}: ${r.error}`);
      }
      A.audit(ctx.user, 'whitelist.push', ctx.server.name, { ok, total: rows.length }, ctx.ip);
      return { count: ok, total: rows.length, errors };
    }
    throw new HttpErr(400, 'Неверное направление синхронизации');
  });
  route('POST', '/api/servers/:id/whitelist/toggle', { perm: 'whitelist', server: true }, async ctx => {
    const on = !!ctx.body.on;
    const r = await C.runCommand(ctx.server, on ? 'whitelist on' : 'whitelist off');
    A.audit(ctx.user, on ? 'whitelist.on' : 'whitelist.off', ctx.server.name, { ok: r.ok }, ctx.ip);
    if (!r.ok) throw new HttpErr(502, r.error);
    return { response: r.response };
  });

  // ═══════════ Минималки (нормы персонала) ═══════════
  const PUNISH_CMD = /^\/(?:[\w.-]+:)?(mute|tempmute|warn|tempwarn|tempban|ipban|tempipban|banip|jail)\b/i;
  function computeQuotas(server, ws) {
    const we = ws + 7 * 864e5, t = now();
    const norms = {};
    for (const r of q.all('SELECT * FROM quotas WHERE server_id=?', server.id)) norms[r.role] = { hours: r.hours, punishments: r.punishments, reports: r.reports };
    const users = q.all("SELECT * FROM users WHERE disabled=0 AND mc_nick IS NOT NULL AND mc_nick<>'' ORDER BY id").filter(u => A.canServer(u, server.id));
    const staff = users.map(u => {
      const ms = q.get(`SELECT COALESCE(SUM(MIN(COALESCE(s.left,?),?) - MAX(s.joined,?)),0) AS ms FROM play_sessions s JOIN players p ON p.id=s.player_id
        WHERE s.server_id=? AND p.name=? AND s.joined<? AND COALESCE(s.left,?)>?`, t, we, ws, server.id, u.mc_nick, we, t, ws).ms;
      const direct = q.get(`SELECT COUNT(*) c FROM punishments WHERE server_id=? AND created_at>=? AND created_at<? AND type IN ('ban','mute','kick','warn')
        AND (issued_by=? OR issued_name=? COLLATE NOCASE)`, server.id, ws, we, u.id, u.mc_nick).c;
      const cmds = q.all("SELECT message FROM events WHERE server_id=? AND player=? AND type='command' AND ts>=? AND ts<? AND message LIKE '/%' LIMIT 5000", server.id, u.mc_nick, ws, we)
        .filter(r => PUNISH_CMD.test(r.message || '')).length;
      const reports = q.get('SELECT COUNT(*) c FROM reports WHERE server_id=? AND closed_by=? AND closed_at>=? AND closed_at<?', server.id, u.id, ws, we).c;
      const norm = norms[u.role] || null;
      const hours = Math.round(ms / 36000) / 100;
      const pun = direct + cmds;
      const hasNorm = norm && (norm.hours > 0 || norm.punishments > 0 || norm.reports > 0);
      return {
        id: u.id, login: u.login, name: u.display_name || u.login, role: u.role, mc_nick: u.mc_nick, hours, punishments: pun, reports,
        norm: hasNorm ? norm : null,
        done: hasNorm ? hours >= norm.hours && pun >= norm.punishments && reports >= norm.reports : null,
      };
    });
    return { week_start: ws, week_end: we, norms, staff };
  }
  route('GET', '/api/servers/:id/quotas', { perm: 'quotas.view', server: true }, ctx => {
    if (!A.FEATURES.quotas) throw new HttpErr(404, 'Раздел отключён');
    const w = Number(ctx.query.week);
    return computeQuotas(ctx.server, weekStart(Number.isFinite(w) && w > 0 ? w : now()));
  });
  route('PUT', '/api/servers/:id/quotas', { perm: 'quotas', server: true }, ctx => {
    if (!A.FEATURES.quotas) throw new HttpErr(404, 'Раздел отключён');
    const norms = ctx.body.norms || {};
    tx(() => {
      for (const role of A.assignableRoles()) {
        const n = norms[role];
        if (!n) continue;
        const hours = Math.min(168, Math.max(0, Number(n.hours) || 0)), pun = intIn(n.punishments, 0, 0, 100000), rep = intIn(n.reports, 0, 0, 100000);
        q.run('INSERT INTO quotas(server_id,role,hours,punishments,reports) VALUES(?,?,?,?,?) ON CONFLICT(server_id,role) DO UPDATE SET hours=excluded.hours, punishments=excluded.punishments, reports=excluded.reports',
          ctx.server.id, role, hours, pun, rep);
      }
    });
    A.audit(ctx.user, 'quotas.update', ctx.server.name, norms, ctx.ip);
  });

  // ═══════════ Пользователи (только владелец) ═══════════
  function pubStaff(u) {
    return {
      id: u.id, login: u.login, display_name: u.display_name, role: u.role, mc_nick: u.mc_nick, servers: u.servers,
      disabled: !!u.disabled, created_at: u.created_at, last_login: u.last_login, discord_name: u.discord_name || null, discord_off: !!u.discord_off,
      online: !!q.get('SELECT 1 x FROM sessions WHERE user_id=? AND last_seen>? AND expires_at>?', u.id, now() - 5 * 60000, now()),
      sessions: q.get('SELECT COUNT(*) c FROM sessions WHERE user_id=? AND expires_at>?', u.id, now()).c,
    };
  }
  function readUserBody(b, partial, existing) {
    const o = {};
    if (!partial) {
      if (!A.validLogin(b.login)) throw new HttpErr(400, 'Логин: 3–32 символа (латиница, цифры, _ . -)');
      if (q.get('SELECT 1 x FROM users WHERE login=?', b.login)) throw new HttpErr(409, 'Такой логин уже существует');
      o.login = b.login;
    }
    if (b.role !== undefined) {
      if (!A.assignableRoles().includes(b.role)) throw new HttpErr(400, 'Недопустимая роль');
      o.role = b.role;
    } else if (!partial) throw new HttpErr(400, 'Выберите роль');
    if (b.display_name !== undefined) o.display_name = clean(b.display_name, 40) || null;
    if (b.mc_nick !== undefined) {
      const n = clean(b.mc_nick, 40);
      if (n && !validName(n)) throw new HttpErr(400, 'Некорректный игровой ник');
      o.mc_nick = n || null;
    }
    if (b.servers !== undefined) {
      if (b.servers === '*' || (Array.isArray(b.servers) && b.servers.includes('*'))) o.servers = '*';
      else {
        const ids = (Array.isArray(b.servers) ? b.servers : []).map(Number).filter(n => q.get('SELECT 1 x FROM servers WHERE id=?', n));
        o.servers = ids.length ? ids.join(',') : '';
      }
    }
    if (b.disabled !== undefined) o.disabled = b.disabled ? 1 : 0;
    return o;
  }
  route('GET', '/api/users', { perm: 'users.manage' }, () => ({ items: q.all('SELECT * FROM users ORDER BY id').map(pubStaff) }));
  route('POST', '/api/users', { perm: 'users.manage' }, ctx => {
    const o = readUserBody(ctx.body, false);
    if (!A.validPassword(ctx.body.password)) throw new HttpErr(400, 'Пароль: от 8 до 128 символов');
    const r = q.run('INSERT INTO users(login,pass_hash,role,display_name,mc_nick,servers,created_at,created_by) VALUES(?,?,?,?,?,?,?,?)',
      o.login, A.hashPassword(ctx.body.password), o.role, o.display_name || null, o.mc_nick || null, o.servers === undefined ? '*' : o.servers, now(), ctx.user.id);
    A.audit(ctx.user, 'user.create', o.login, { role: o.role }, ctx.ip);
    return { user: pubStaff(q.get('SELECT * FROM users WHERE id=?', r.lastInsertRowid)) };
  });
  function targetUser(ctx) {
    const u = q.get('SELECT * FROM users WHERE id=?', ctx.params.uid);
    if (!u) throw new HttpErr(404, 'Пользователь не найден');
    return u;
  }
  route('PATCH', '/api/users/:uid', { perm: 'users.manage' }, ctx => {
    const u = targetUser(ctx);
    const o = readUserBody(ctx.body, true);
    if (u.role === 'owner') { delete o.role; delete o.disabled; delete o.servers; }
    const keys = Object.keys(o);
    if (keys.length) q.run(`UPDATE users SET ${keys.map(k => k + '=?').join(',')} WHERE id=?`, ...keys.map(k => o[k]), u.id);
    if (o.disabled) A.destroyUserSessions(u.id);
    if (o.role && o.role !== u.role) A.destroyUserSessions(u.id);
    A.audit(ctx.user, 'user.update', u.login, o, ctx.ip);
    return { user: pubStaff(q.get('SELECT * FROM users WHERE id=?', u.id)) };
  });
  route('POST', '/api/users/:uid/password', { perm: 'users.manage' }, ctx => {
    const u = targetUser(ctx);
    if (!A.validPassword(ctx.body.password)) throw new HttpErr(400, 'Пароль: от 8 до 128 символов');
    q.run('UPDATE users SET pass_hash=? WHERE id=?', A.hashPassword(ctx.body.password), u.id);
    if (u.id !== ctx.user.id) A.destroyUserSessions(u.id); else A.destroyUserSessions(u.id, ctx.token);
    A.audit(ctx.user, 'user.password', u.login, null, ctx.ip);
  });
  route('POST', '/api/users/:uid/logout', { perm: 'users.manage' }, ctx => {
    const u = targetUser(ctx);
    A.destroyUserSessions(u.id, u.id === ctx.user.id ? ctx.token : null);
    A.audit(ctx.user, 'user.logout', u.login, null, ctx.ip);
  });
  route('DELETE', '/api/users/:uid', { perm: 'users.manage' }, ctx => {
    const u = targetUser(ctx);
    if (u.role === 'owner') throw new HttpErr(400, 'Владельца удалить нельзя');
    q.run('DELETE FROM users WHERE id=?', u.id);
    A.audit(ctx.user, 'user.delete', u.login, null, ctx.ip);
  });

  // ═══════════ Журнал действий панели ═══════════
  route('GET', '/api/audit', { perm: 'audit' }, ctx => {
    const Q = ctx.query, where = ['1=1'], params = [];
    if (Q.user) { where.push('user_login=? COLLATE NOCASE'); params.push(String(Q.user).slice(0, 40)); }
    if (Q.q) { const l = '%' + likeEscape(String(Q.q).slice(0, 80)) + '%'; where.push("(action LIKE ? ESCAPE '\\' OR target LIKE ? ESCAPE '\\' OR details LIKE ? ESCAPE '\\')"); params.push(l, l, l); }
    if (Q.before) { where.push('id<?'); params.push(Number(Q.before) || 0); }
    const limit = intIn(Q.limit, 100, 1, 300);
    const rows = q.all(`SELECT * FROM audit WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT ?`, ...params, limit + 1);
    const has_more = rows.length > limit;
    if (has_more) rows.pop();
    return { items: rows, has_more, users: q.all('SELECT login FROM users ORDER BY login').map(u => u.login) };
  });

  // ═══════════ Уведомления ═══════════
  route('GET', '/api/notifications', {}, ctx => {
    const u = ctx.user;
    const rows = q.all('SELECT n.*, s.name AS server FROM notifications n LEFT JOIN servers s ON s.id=n.server_id ORDER BY n.id DESC LIMIT 80')
      .filter(n => !n.server_id || A.canServer(u, n.server_id)).slice(0, 30);
    return { items: rows.map(n => ({ ...n, unread: n.id > u.notif_read })), unread: rows.filter(n => n.id > u.notif_read).length };
  });
  route('POST', '/api/notifications/read', {}, ctx => {
    const m = q.get('SELECT COALESCE(MAX(id),0) m FROM notifications').m;
    q.run('UPDATE users SET notif_read=? WHERE id=?', m, ctx.user.id);
  });

  // ═══════════ Информация ═══════════
  route('GET', '/api/info', {}, ctx => {
    let size = 0; try { size = fs.statSync(DB_FILE).size; } catch {}
    const c = t => q.get(`SELECT COUNT(*) c FROM ${t}`).c;
    return {
      version: VERSION, node: process.version, uptime: Math.floor((now() - START) / 1000), db_size: size, time: now(),
      counts: { users: c('users'), servers: c('servers'), players: c('players'), events: c('events'), punishments: c('punishments'), reports: c('reports') },
      retention_days: parseInt(process.env.EVENT_RETENTION_DAYS || '90', 10),
    };
  });
  route('GET', '/api/agent-files/:name', {}, ctx => {
    const name = ctx.params.name;
    if (!['agent.js', 'mc.js'].includes(name)) throw new HttpErr(404, 'Нет файла');
    ctx.raw = { type: 'application/javascript; charset=utf-8', body: fs.readFileSync(path.join(__dirname, '..', 'agent', name)), headers: { 'Content-Disposition': `attachment; filename="${name}"` } };
  });

  // ═══════════ API для агента / плагина ═══════════
  route('POST', '/api/agent/events', { auth: 'agent', maxBody: 4 * 1024 * 1024 }, ctx => {
    const list = Array.isArray(ctx.body.events) ? ctx.body.events.slice(0, 1000) : [];
    C.heartbeat(ctx.server, ctx.body.agent);
    const accepted = list.length ? C.ingest(ctx.server, list) : 0;
    return { ok: true, accepted, agent_latest: AGENT_VERSION };
  });
  route('GET', '/api/agent/commands', { auth: 'agent' }, async ctx => {
    C.heartbeat(ctx.server, { rcon: true, v: ctx.query.v || ctx.server.agent_version });
    const wait = intIn(ctx.query.wait, 0, 0, 30);
    const commands = await C.takeCommands(ctx.server, wait);
    return { commands, agent_latest: AGENT_VERSION };
  });
  route('POST', '/api/agent/commands/:cid/result', { auth: 'agent' }, ctx => {
    const ok = C.completeCommand(ctx.server.id, Number(ctx.params.cid), { ok: !!ctx.body.ok, response: ctx.body.response, error: ctx.body.error });
    return { ok };
  });
  route('GET', '/api/agent/ping', { auth: 'agent' }, ctx => ({ ok: true, server: ctx.server.name }));
};
