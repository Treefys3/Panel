'use strict';
// Роли, автомодерация, планировщик, интеграции, система, поиск, мастер первого запуска.
const fs = require('fs');
const crypto = require('crypto');
const { q, DB_FILE, getSetting } = require('./db');
const A = require('./auth');
const C = require('./core');
const X = require('./extra');
const { HttpErr, clean } = require('./util');

const now = () => Date.now();
const START = now();
function intIn(v, def, min, max) { const n = parseInt(v, 10); return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : def; }
function ruleOut(r) { let config = {}; try { config = JSON.parse(r.config); } catch {} return { ...r, config, enabled: !!r.enabled }; }

module.exports = function register(route) {
  /* ═════════ Роли и доступ ═════════ */
  function normPerms(list) {
    const set = new Set((Array.isArray(list) ? list : []).filter(p => A.ALL_PERMS.includes(p)));
    if (set.has('whitelist')) set.add('whitelist.view');
    if (set.has('quotas')) set.add('quotas.view');
    if (set.has('ban')) set.add('punish');
    return A.ALL_PERMS.filter(p => set.has(p));
  }
  function readRole(b, partial) {
    const o = {};
    if (!partial || b.label !== undefined) { o.label = clean(b.label, 30); if (!o.label) throw new HttpErr(400, 'Укажите название роли'); }
    if (b.color !== undefined) { if (!/^#[0-9a-fA-F]{6}$/.test(b.color)) throw new HttpErr(400, 'Цвет в формате #RRGGBB'); o.color = b.color; }
    if (b.perms !== undefined) o.perms = JSON.stringify(normPerms(b.perms));
    if (b.description !== undefined) o.description = clean(b.description, 120) || null;
    if (b.discord_role_id !== undefined) {
      const id = String(b.discord_role_id || '').trim();
      if (id && !/^\d{5,25}$/.test(id)) throw new HttpErr(400, 'ID роли Discord — только цифры');
      if (id && q.get('SELECT 1 x FROM roles WHERE discord_role_id=?' + (partial && b.__key ? ' AND key<>?' : ''), ...(partial && b.__key ? [id, b.__key] : [id]))) throw new HttpErr(409, 'Эта роль Discord уже привязана к другой роли панели');
      o.discord_role_id = id || null;
    }
    return o;
  }
  route('GET', '/api/roles', { perm: 'roles.manage' }, () => ({
    roles: Object.values(A.roles()).filter(r => r.key !== 'owner').map(r => ({ ...r, users: q.get('SELECT COUNT(*) c FROM users WHERE role=?', r.key).c })),
    catalog: A.PERM_CATALOG,
  }));
  route('POST', '/api/roles', { perm: 'roles.manage' }, ctx => {
    const b = ctx.body, o = readRole(b, false);
    let perms = o.perms || '[]';
    if (b.copy_from && A.roles()[b.copy_from] && b.copy_from !== 'owner' && b.perms === undefined) perms = JSON.stringify(A.roles()[b.copy_from].perms);
    const key = 'r_' + crypto.randomBytes(4).toString('hex');
    q.run('INSERT INTO roles(key,label,color,perms,builtin,position,description,discord_role_id) VALUES(?,?,?,?,0,?,?,?)', key, o.label, o.color || '#4f7cff', perms, (q.get('SELECT COALESCE(MAX(position),0)+1 p FROM roles').p), o.description || null, o.discord_role_id || null);
    A.reloadRoles();
    A.audit(ctx.user, 'role.create', o.label, null, ctx.ip);
    return { key };
  });
  route('PATCH', '/api/roles/:key', { perm: 'roles.manage' }, ctx => {
    const r = A.roles()[ctx.params.key];
    if (!r || r.key === 'owner') throw new HttpErr(404, 'Роль не найдена');
    const o = readRole({ ...ctx.body, __key: r.key }, true), keys = Object.keys(o);
    if (keys.length) q.run(`UPDATE roles SET ${keys.map(k => k + '=?').join(',')} WHERE key=?`, ...keys.map(k => o[k]), r.key);
    A.reloadRoles();
    A.audit(ctx.user, 'role.update', r.label, o.perms ? { perms: JSON.parse(o.perms) } : o, ctx.ip);
    C.broadcast('roles', {});
  });
  route('POST', '/api/roles/reorder', { perm: 'roles.manage' }, ctx => {
    const keys = (Array.isArray(ctx.body.keys) ? ctx.body.keys : []).filter(k => A.roles()[k] && k !== 'owner');
    keys.forEach((k, i) => q.run('UPDATE roles SET position=? WHERE key=?', i + 1, k));
    A.reloadRoles();
    A.audit(ctx.user, 'role.reorder', null, null, ctx.ip);
    C.broadcast('roles', {});
  });
  route('DELETE', '/api/roles/:key', { perm: 'roles.manage' }, ctx => {
    const r = A.roles()[ctx.params.key];
    if (!r || r.key === 'owner') throw new HttpErr(404, 'Роль не найдена');
    if (r.builtin) throw new HttpErr(400, 'Встроенные роли удалить нельзя — их можно только настроить');
    const n = q.get('SELECT COUNT(*) c FROM users WHERE role=?', r.key).c;
    if (n) throw new HttpErr(409, `Роль назначена ${n} сотрудникам — сначала смените им роль`);
    q.run('DELETE FROM roles WHERE key=?', r.key);
    q.run('DELETE FROM quotas WHERE role=?', r.key);
    A.reloadRoles();
    A.audit(ctx.user, 'role.delete', r.label, null, ctx.ip);
  });

  /* ═════════ Автомодерация ═════════ */
  function loadRule(ctx) {
    const r = q.get('SELECT * FROM automod_rules WHERE id=? AND server_id=?', ctx.params.rid, ctx.server.id);
    if (!r) throw new HttpErr(404, 'Правило не найдено');
    return r;
  }
  route('GET', '/api/servers/:id/automod', { perm: 'automod', server: true }, ctx => ({
    rules: q.all('SELECT * FROM automod_rules WHERE server_id=? ORDER BY id', ctx.server.id).map(ruleOut),
    types: X.RULE_TYPES, can_command: C.canCommand(ctx.server),
    recent: q.all("SELECT id,ts,player,message FROM events WHERE server_id=? AND type='automod' ORDER BY id DESC LIMIT 15", ctx.server.id),
  }));
  route('POST', '/api/servers/:id/automod', { perm: 'automod', server: true }, ctx => {
    const o = X.readRule({ ...ctx.body, config: ctx.body.config || {} }, false);
    const r = q.run('INSERT INTO automod_rules(server_id,name,type,enabled,config,action,duration,reason) VALUES(?,?,?,?,?,?,?,?)',
      ctx.server.id, o.name, o.type, o.enabled === undefined ? 1 : o.enabled, o.config, o.action || 'notify', o.duration || null, o.reason || null);
    A.audit(ctx.user, 'automod.create', `${ctx.server.name}: ${o.name}`, { type: o.type, action: o.action }, ctx.ip);
    return { id: Number(r.lastInsertRowid) };
  });
  route('PATCH', '/api/servers/:id/automod/:rid', { perm: 'automod', server: true }, ctx => {
    const r = loadRule(ctx);
    const o = X.readRule({ ...ctx.body, type: ctx.body.type || r.type }, true);
    delete o.type;
    const keys = Object.keys(o);
    if (keys.length) q.run(`UPDATE automod_rules SET ${keys.map(k => k + '=?').join(',')} WHERE id=?`, ...keys.map(k => o[k]), r.id);
    A.audit(ctx.user, 'automod.update', `${ctx.server.name}: ${r.name}`, o, ctx.ip);
  });
  route('DELETE', '/api/servers/:id/automod/:rid', { perm: 'automod', server: true }, ctx => {
    const r = loadRule(ctx);
    q.run('DELETE FROM automod_rules WHERE id=?', r.id);
    A.audit(ctx.user, 'automod.delete', `${ctx.server.name}: ${r.name}`, null, ctx.ip);
  });
  route('POST', '/api/servers/:id/automod/test', { perm: 'automod', server: true }, ctx => ({ matches: X.dryRun(ctx.server.id, clean(ctx.body.text, 500)) }));

  /* ═════════ Планировщик ═════════ */
  function loadSchedule(ctx) {
    const s = q.get('SELECT * FROM schedules WHERE id=? AND server_id=?', ctx.params.sid, ctx.server.id);
    if (!s) throw new HttpErr(404, 'Задача не найдена');
    return s;
  }
  route('GET', '/api/servers/:id/schedules', { perm: 'scheduler', server: true }, ctx => ({
    items: q.all('SELECT * FROM schedules WHERE server_id=? ORDER BY id', ctx.server.id).map(s => ({ ...s, enabled: !!s.enabled })),
    can_command: C.canCommand(ctx.server),
  }));
  route('POST', '/api/servers/:id/schedules', { perm: 'scheduler', server: true }, ctx => {
    const o = X.readSchedule(ctx.body, false);
    const r = q.run('INSERT INTO schedules(server_id,name,enabled,kind,every_min,at_time,days,commands,next_run,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)',
      ctx.server.id, o.name, o.enabled === undefined ? 1 : o.enabled, o.kind, o.every_min || null, o.at_time || null, o.days || '1,2,3,4,5,6,7', o.commands, X.nextRunFor(o), ctx.user.login);
    A.audit(ctx.user, 'schedule.create', `${ctx.server.name}: ${o.name}`, { commands: o.commands }, ctx.ip);
    return { id: Number(r.lastInsertRowid) };
  });
  route('PATCH', '/api/servers/:id/schedules/:sid', { perm: 'scheduler', server: true }, ctx => {
    const s = loadSchedule(ctx);
    const o = X.readSchedule({ ...ctx.body, kind: ctx.body.kind || s.kind }, true);
    const merged = { ...s, ...o };
    if (o.every_min || o.kind || o.enabled) o.next_run = X.nextRunFor(merged);
    const keys = Object.keys(o);
    if (keys.length) q.run(`UPDATE schedules SET ${keys.map(k => k + '=?').join(',')} WHERE id=?`, ...keys.map(k => o[k]), s.id);
    A.audit(ctx.user, 'schedule.update', `${ctx.server.name}: ${s.name}`, null, ctx.ip);
  });
  route('DELETE', '/api/servers/:id/schedules/:sid', { perm: 'scheduler', server: true }, ctx => {
    const s = loadSchedule(ctx);
    q.run('DELETE FROM schedules WHERE id=?', s.id);
    A.audit(ctx.user, 'schedule.delete', `${ctx.server.name}: ${s.name}`, null, ctx.ip);
  });
  route('POST', '/api/servers/:id/schedules/:sid/run', { perm: 'scheduler', server: true }, async ctx => {
    const s = loadSchedule(ctx);
    const result = await X.runSchedule(s);
    A.audit(ctx.user, 'schedule.run', `${ctx.server.name}: ${s.name}`, { result }, ctx.ip);
    return { result };
  });

  /* ═════════ Интеграции ═════════ */
  const hookOut = w => {
    let events = []; try { events = JSON.parse(w.events); } catch {}
    return { id: w.id, name: w.name, type: w.type, url: w.url, chat_id: w.chat_id, token: w.token ? '••••' + w.token.slice(-4) : null, events, enabled: !!w.enabled, last_status: w.last_status, last_at: w.last_at };
  };
  async function readHook(b, partial, cur) {
    const o = {};
    if (!partial || b.name !== undefined) { o.name = clean(b.name, 40); if (!o.name) throw new HttpErr(400, 'Укажите название'); }
    const type = b.type || (cur && cur.type);
    if (!partial || b.type !== undefined) { if (!['discord', 'telegram', 'generic'].includes(b.type)) throw new HttpErr(400, 'Неверный тип интеграции'); o.type = b.type; }
    if (b.events !== undefined) o.events = JSON.stringify((Array.isArray(b.events) ? b.events : []).filter(e => X.WEBHOOK_EVENTS[e]));
    if (b.enabled !== undefined) o.enabled = b.enabled ? 1 : 0;
    if (type === 'telegram') {
      if (b.token) { if (!/^\d{5,}:[\w-]{20,}$/.test(String(b.token))) throw new HttpErr(400, 'Неверный токен бота (формат 123456:ABC…)'); o.token = String(b.token); }
      if (b.chat_id !== undefined) { o.chat_id = clean(b.chat_id, 40); if (!o.chat_id) throw new HttpErr(400, 'Укажите ID чата'); }
      if (!partial && !o.token) throw new HttpErr(400, 'Укажите токен бота');
    } else if (b.url !== undefined || !partial) {
      const url = clean(b.url, 500);
      await X.checkUrl(url);
      o.url = url;
    }
    return o;
  }
  route('GET', '/api/webhooks', { perm: 'integrations' }, () => ({ items: q.all('SELECT * FROM webhooks ORDER BY id').map(hookOut), events: X.WEBHOOK_EVENTS, public_url: X.publicUrl() }));
  route('POST', '/api/webhooks', { perm: 'integrations' }, async ctx => {
    const o = await readHook(ctx.body, false);
    const r = q.run('INSERT INTO webhooks(name,type,url,token,chat_id,events,enabled) VALUES(?,?,?,?,?,?,1)', o.name, o.type, o.url || null, o.token || null, o.chat_id || null, o.events || '[]');
    A.audit(ctx.user, 'webhook.create', o.name, { type: o.type }, ctx.ip);
    return { id: Number(r.lastInsertRowid) };
  });
  route('PATCH', '/api/webhooks/:id', { perm: 'integrations' }, async ctx => {
    const w = q.get('SELECT * FROM webhooks WHERE id=?', ctx.params.id);
    if (!w) throw new HttpErr(404, 'Не найдено');
    const o = await readHook({ ...ctx.body, type: ctx.body.type || w.type }, true, w);
    delete o.type;
    const keys = Object.keys(o);
    if (keys.length) q.run(`UPDATE webhooks SET ${keys.map(k => k + '=?').join(',')} WHERE id=?`, ...keys.map(k => o[k]), w.id);
    A.audit(ctx.user, 'webhook.update', w.name, null, ctx.ip);
  });
  route('DELETE', '/api/webhooks/:id', { perm: 'integrations' }, ctx => {
    const w = q.get('SELECT * FROM webhooks WHERE id=?', ctx.params.id);
    if (!w) throw new HttpErr(404, 'Не найдено');
    q.run('DELETE FROM webhooks WHERE id=?', w.id);
    A.audit(ctx.user, 'webhook.delete', w.name, null, ctx.ip);
  });
  route('POST', '/api/webhooks/:id/test', { perm: 'integrations' }, async ctx => {
    const w = q.get('SELECT * FROM webhooks WHERE id=?', ctx.params.id);
    if (!w) throw new HttpErr(404, 'Не найдено');
    const status = await X.deliver(w, { kind: 'test', title: 'MC Panel: проверка связи', body: 'Если вы видите это сообщение — интеграция работает.', link: '#/', ts: now() });
    return { status };
  });

  /* ═════════ Система (только владелец) ═════════ */
  const sysSettings = () => ({
    retention_days: parseInt(getSetting('retention_days', process.env.EVENT_RETENTION_DAYS || '90'), 10) || 90,
    backup_keep: parseInt(getSetting('backup_keep', '7'), 10) || 7,
    public_url: X.publicUrl(),
  });
  route('GET', '/api/system', { perm: 'system' }, () => {
    let size = 0; try { size = fs.statSync(DB_FILE).size; } catch {}
    return { version: '1.3.0', node: process.version, uptime: Math.floor((now() - START) / 1000), db_size: size, settings: sysSettings(), backups: X.listBackups() };
  });
  route('PUT', '/api/system', { perm: 'system' }, ctx => {
    const b = ctx.body;
    if (b.retention_days !== undefined) X.setSetting('retention_days', intIn(b.retention_days, 90, 1, 3650));
    if (b.backup_keep !== undefined) X.setSetting('backup_keep', intIn(b.backup_keep, 7, 1, 60));
    if (b.public_url !== undefined) {
      const u = clean(b.public_url, 200).replace(/\/+$/, '');
      if (u && !/^https?:\/\/[^\s/]+$/.test(u)) throw new HttpErr(400, 'Адрес вида https://panel.example.com');
      X.setSetting('public_url', u);
    }
    A.audit(ctx.user, 'system.update', null, b, ctx.ip);
  });
  route('POST', '/api/backups', { perm: 'system' }, ctx => {
    const name = X.createBackup();
    A.audit(ctx.user, 'backup.create', name, null, ctx.ip);
    return { name };
  });
  route('GET', '/api/backups/:name', { perm: 'system' }, ctx => {
    const f = X.backupFile(ctx.params.name);
    A.audit(ctx.user, 'backup.download', ctx.params.name, null, ctx.ip);
    ctx.raw = { type: 'application/octet-stream', body: fs.readFileSync(f), headers: { 'Content-Disposition': `attachment; filename="${ctx.params.name}"` } };
  });
  route('DELETE', '/api/backups/:name', { perm: 'system' }, ctx => {
    fs.unlinkSync(X.backupFile(ctx.params.name));
    A.audit(ctx.user, 'backup.delete', ctx.params.name, null, ctx.ip);
  });

  /* ═════════ Поиск игрока ═════════ */
  route('GET', '/api/search', { perm: 'players' }, ctx => {
    const text = clean(ctx.query.q, 40).replace(/[\\%_]/g, c => '\\' + c);
    if (text.length < 2) return { items: [] };
    const ids = C.visibleServers(ctx.user).map(s => s.id);
    if (!ids.length) return { items: [] };
    const items = q.all(`SELECT p.name, p.server_id, s.name AS server, p.online, p.last_seen,
      (SELECT COUNT(*) FROM punishments x WHERE x.server_id=p.server_id AND x.player=p.name AND x.active=1 AND x.type='ban') AS banned
      FROM players p JOIN servers s ON s.id=p.server_id WHERE p.server_id IN (${ids.join(',')}) AND p.name LIKE ? ESCAPE '\\' ORDER BY p.online DESC, p.last_seen DESC LIMIT 20`, '%' + text + '%');
    return { items };
  });

  /* ═════════ Мастер первого запуска ═════════ */
  route('GET', '/api/onboarding', { perm: 'system' }, ctx => {
    const dismissed = getSetting('onboarding_dismissed') === '1';
    const servers = q.get('SELECT COUNT(*) c FROM servers').c;
    const agent = q.get('SELECT COUNT(*) c FROM servers WHERE last_agent IS NOT NULL').c;
    const staff = q.get('SELECT COUNT(*) c FROM users WHERE role<>?', 'owner').c;
    const hooks = q.get('SELECT COUNT(*) c FROM webhooks').c;
    const steps = [
      { key: 'password', title: 'Смените пароль владельца', desc: 'Пароль мог быть сгенерирован при первом запуске — задайте свой.', done: !!ctx.user.pw_changed, link: '#pw', action: 'Сменить' },
      { key: 'server', title: 'Добавьте сервер Minecraft', desc: 'Название и адрес — остальное панель сделает сама.', done: servers > 0, link: '#/new-server', action: 'Добавить' },
      { key: 'agent', title: 'Подключите агента', desc: 'Одна команда на машине с сервером — панель покажет её после добавления сервера.', done: agent > 0, link: '#/info', action: 'Инструкция' },
      { key: 'staff', title: 'Создайте аккаунты сотрудникам', desc: 'Логин и пароль выдаёте только вы. Роли настраиваются в «Роли и доступ».', done: staff > 0, link: '#/users', action: 'Создать' },
      { key: 'hooks', title: 'Подключите уведомления (по желанию)', desc: 'Репорты, баны и падения сервера — в Discord или Telegram.', done: hooks > 0, link: '#/integrations', action: 'Настроить', optional: true },
    ];
    return { dismissed, steps };
  });
  route('POST', '/api/onboarding/dismiss', { perm: 'system' }, () => { X.setSetting('onboarding_dismissed', '1'); });
};
