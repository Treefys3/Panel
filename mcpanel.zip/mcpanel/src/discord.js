'use strict';
// Вход через Discord (OAuth2), привязка аккаунтов, роли панели из ролей Discord-сервера.
const crypto = require('crypto');
const { q } = require('./db');
const A = require('./auth');
const X = require('./extra');
const { HttpErr } = require('./util');

const now = () => Date.now();
const API = () => (process.env.DISCORD_API || 'https://discord.com/api/v10').replace(/\/+$/, '');
const AUTH_URL = () => process.env.DISCORD_AUTH_URL || 'https://discord.com/oauth2/authorize';

function cfg() {
  const g = k => X.getSetting(k) || '';
  return { client_id: g('discord_client_id'), client_secret: g('discord_client_secret'), guild_id: g('discord_guild_id'), bot_token: g('discord_bot_token') };
}
const enabled = () => { const c = cfg(); return !!(c.client_id && c.client_secret); };

async function dfetch(path, { token, bot, method = 'GET', form } = {}) {
  const headers = {};
  if (token) headers.Authorization = 'Bearer ' + token;
  if (bot) headers.Authorization = 'Bot ' + bot;
  let body;
  if (form) { body = new URLSearchParams(form); headers['Content-Type'] = 'application/x-www-form-urlencoded'; }
  let res;
  try { res = await fetch(API() + path, { method, headers, body, signal: AbortSignal.timeout(10000) }); }
  catch (e) { throw new HttpErr(502, 'Discord недоступен: ' + e.message); }
  if (!res.ok) { const e = new HttpErr(res.status === 404 ? 404 : 502, `Discord вернул ошибку ${res.status}`); e.status = res.status; throw e; }
  return res.status === 204 ? null : res.json();
}

// ── state для OAuth (в памяти, живёт 10 минут) ──
const states = new Map();
function newState(data) {
  for (const [k, v] of states) if (v.exp < now()) states.delete(k);
  const s = crypto.randomBytes(18).toString('base64url');
  states.set(s, { ...data, exp: now() + 10 * 60000 });
  return s;
}
const takeState = s => { const v = states.get(s); states.delete(s); return v && v.exp > now() ? v : null; };

function redirectUri(origin) { return (X.publicUrl() || origin) + '/api/discord/callback'; }
function authorizeUrl(purpose, origin, userId) {
  const c = cfg();
  if (!enabled()) throw new HttpErr(400, 'Вход через Discord не настроен владельцем');
  const redirect = redirectUri(origin);
  const state = newState({ purpose, userId, redirect });
  const scope = c.guild_id ? 'identify guilds guilds.members.read' : 'identify';
  return `${AUTH_URL()}?` + new URLSearchParams({ client_id: c.client_id, redirect_uri: redirect, response_type: 'code', scope, state, prompt: 'none' }).toString();
}

async function exchange(code, redirect) {
  const c = cfg();
  const t = await dfetch('/oauth2/token', { method: 'POST', form: { client_id: c.client_id, client_secret: c.client_secret, grant_type: 'authorization_code', code, redirect_uri: redirect } });
  if (!t || !t.access_token) throw new HttpErr(502, 'Discord не выдал токен');
  return t.access_token;
}

// Роль панели по ролям участника Discord-сервера (самая «высокая» по порядку)
function mapRole(discordRoleIds) {
  const set = new Set(discordRoleIds || []);
  const rows = q.all("SELECT key,position FROM roles WHERE discord_role_id IS NOT NULL AND discord_role_id<>'' ORDER BY position, key");
  const hit = rows.find(r => set.has(q.get('SELECT discord_role_id d FROM roles WHERE key=?', r.key).d));
  return hit ? hit.key : null;
}

function uniqueLogin(base) {
  base = ('dc_' + String(base || 'user').toLowerCase().replace(/[^a-z0-9_.-]/g, '')).slice(0, 28);
  let l = base, i = 1;
  while (q.get('SELECT 1 x FROM users WHERE login=?', l)) l = base + '_' + (++i);
  return l;
}

function disableByDiscord(u, why, ip) {
  if (u.disabled && u.discord_off) return;
  q.run('UPDATE users SET disabled=1, discord_off=1 WHERE id=?', u.id);
  A.destroyUserSessions(u.id);
  A.audit(null, 'discord.removed', u.login, { why }, ip);
}

// ── Роли Discord → роли панели ──
const hasAdmin = p => { try { return (BigInt(p || 0) & 8n) === 8n; } catch { return false; } };
const autoAdmin = () => X.getSetting('discord_auto_admin') !== '0';
let lastImport = 0;
// Роли Discord с правом «Администратор» автоматически появляются в панели (с полным набором прав, кроме владельческих).
// Уже привязанные роли, созданные из Discord, следуют за названием и цветом роли в Discord.
async function importRoles({ force } = {}) {
  const c = cfg();
  const res = { created: 0, updated: 0, removed: 0 };
  if (!c.guild_id || !c.bot_token) return res;
  if (!force && now() - lastImport < 60000) return res;
  lastImport = now();
  const list = await guildRoles();
  const ids = new Set(list.map(r => r.id));
  for (const r of list) {
    const color = r.color || '#8791b5', label = String(r.name).slice(0, 30);
    const linked = q.get('SELECT * FROM roles WHERE discord_role_id=?', r.id);
    if (linked) {
      if (linked.from_discord && (linked.label !== label || linked.color !== color)) { q.run('UPDATE roles SET label=?, color=? WHERE key=?', label, color, linked.key); res.updated++; }
      continue;
    }
    if (!autoAdmin() || !r.admin || r.managed) continue;
    const key = 'r_' + crypto.randomBytes(4).toString('hex');
    q.run('INSERT INTO roles(key,label,color,perms,builtin,position,description,discord_role_id,from_discord) VALUES(?,?,?,?,0,?,?,?,1)',
      key, label, color, JSON.stringify(A.ALL_PERMS), q.get('SELECT COALESCE(MAX(position),0)+1 p FROM roles').p, 'Из Discord: право «Администратор»', r.id);
    A.audit(null, 'role.create', label, { via: 'discord' });
    res.created++;
  }
  // роль исчезла в Discord: пустую роль удаляем, занятую — отвязываем (её участники потеряют доступ при проверке)
  for (const r of q.all("SELECT * FROM roles WHERE from_discord=1 AND discord_role_id IS NOT NULL")) {
    if (ids.has(r.discord_role_id)) continue;
    if (q.get('SELECT 1 x FROM users WHERE role=?', r.key)) { q.run('UPDATE roles SET discord_role_id=NULL WHERE key=?', r.key); res.updated++; }
    else { q.run('DELETE FROM roles WHERE key=?', r.key); res.removed++; }
  }
  if (res.created || res.updated || res.removed) { A.reloadRoles(); require('./core').broadcast('roles', {}); }
  return res;
}
async function isGuildAdmin(token, gid) {
  try { const g = (await dfetch('/users/@me/guilds', { token })).find(x => x.id === gid); return !!g && (g.owner === true || hasAdmin(g.permissions)); } catch { return false; }
}

// Решение о входе: возвращает пользователя панели или бросает HttpErr
async function resolveLogin(duser, token, ip) {
  const c = cfg();
  let u = q.get('SELECT * FROM users WHERE discord_id=?', duser.id);
  if (u && u.role === 'owner') {
    if (u.disabled) throw new HttpErr(403, 'Аккаунт отключён');
    return u;
  }
  if (!c.guild_id) {
    if (!u) throw new HttpErr(403, 'Этот Discord-аккаунт не привязан ни к одному аккаунту панели. Войдите по паролю и привяжите его в профиле.');
    if (u.disabled) throw new HttpErr(403, 'Аккаунт отключён');
    return u;
  }
  let member = null;
  try { member = await dfetch(`/users/@me/guilds/${c.guild_id}/member`, { token }); }
  catch (e) { if (e.status !== 404 && e.status !== 403) throw e; }
  if (member && c.bot_token) await importRoles().catch(() => {});
  let mapped = member ? mapRole(member.roles) : null;
  // без токена бота названия ролей неизвестны: администратор Discord-сервера получает встроенную роль «Администратор»
  if (member && !mapped && autoAdmin() && await isGuildAdmin(token, c.guild_id)) mapped = 'admin';
  if (!member || !mapped) {
    if (u) disableByDiscord(u, member ? 'нет роли персонала' : 'нет на сервере Discord', ip);
    throw new HttpErr(403, member ? 'У вас нет роли персонала на Discord-сервере' : 'Вас нет на Discord-сервере');
  }
  if (u) {
    if (u.disabled && !u.discord_off) throw new HttpErr(403, 'Аккаунт отключён владельцем');
    q.run('UPDATE users SET role=?, disabled=0, discord_off=0, discord_name=? WHERE id=?', mapped, duser.username, u.id);
    return q.get('SELECT * FROM users WHERE id=?', u.id);
  }
  const login = uniqueLogin(duser.username);
  const r = q.run('INSERT INTO users(login,pass_hash,role,display_name,servers,created_at,discord_id,discord_name,pw_changed) VALUES(?,?,?,?,?,?,?,?,1)',
    login, A.hashPassword(crypto.randomBytes(24).toString('base64url')), mapped, duser.global_name || duser.username, '*', now(), duser.id, duser.username);
  A.audit(null, 'user.create', login, { via: 'discord', role: mapped }, ip);
  return q.get('SELECT * FROM users WHERE id=?', Number(r.lastInsertRowid));
}

async function linkAccount(userId, duser) {
  const other = q.get('SELECT id FROM users WHERE discord_id=? AND id<>?', duser.id, userId);
  if (other) throw new HttpErr(409, 'Этот Discord уже привязан к другому аккаунту');
  q.run('UPDATE users SET discord_id=?, discord_name=? WHERE id=?', duser.id, duser.username, userId);
}

// Фоновая проверка: вышел с сервера / потерял роль → доступ закрывается (нужен токен бота)
async function syncAll(ip) {
  const c = cfg();
  const res = { checked: 0, removed: 0, updated: 0, restored: 0 };
  if (!c.guild_id || !c.bot_token) return res;
  await importRoles({ force: true }).catch(e => console.error('discord roles:', e.message));
  for (const u of q.all("SELECT * FROM users WHERE discord_id IS NOT NULL AND role<>'owner'")) {
    res.checked++;
    let member;
    try { member = await dfetch(`/guilds/${c.guild_id}/members/${u.discord_id}`, { bot: c.bot_token }); }
    catch (e) { if (e.status === 404) member = null; else continue; }
    const mapped = member ? mapRole(member.roles) : null;
    if (!member || !mapped) { if (!u.disabled) { disableByDiscord(u, member ? 'нет роли персонала' : 'вышел/удалён с Discord-сервера', ip); res.removed++; } continue; }
    if (u.disabled && u.discord_off) { q.run('UPDATE users SET disabled=0, discord_off=0, role=? WHERE id=?', mapped, u.id); res.restored++; }
    else if (u.role !== mapped && !u.disabled) { q.run('UPDATE users SET role=? WHERE id=?', mapped, u.id); A.destroyUserSessions(u.id); res.updated++; }
  }
  if (res.removed || res.updated || res.restored) require('./core').broadcast('roles', {});
  return res;
}
let timer;
function startDiscordJobs() {
  timer = setInterval(() => { syncAll().catch(e => console.error('discord sync:', e.message)); }, 5 * 60000);
  timer.unref();
}

async function guildRoles() {
  const c = cfg();
  if (!c.guild_id || !c.bot_token) throw new HttpErr(400, 'Укажите ID сервера и токен бота в «Система → Вход через Discord»');
  const list = await dfetch(`/guilds/${c.guild_id}/roles`, { bot: c.bot_token });
  return list.filter(r => r.name !== '@everyone').sort((a, b) => b.position - a.position).map(r => ({ id: r.id, name: r.name, color: r.color ? '#' + r.color.toString(16).padStart(6, '0') : null, admin: hasAdmin(r.permissions), managed: !!r.managed }));
}

module.exports = { cfg, enabled, authorizeUrl, redirectUri, exchange, dfetch, resolveLogin, linkAccount, takeState, syncAll, startDiscordJobs, guildRoles, mapRole, importRoles };
