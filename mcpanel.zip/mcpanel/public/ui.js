'use strict';
/* ───────── Базовые утилиты интерфейса ───────── */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

// Безопасные шаблоны: все значения экранируются, кроме обёрнутых в raw()
class Raw { constructor(s) { this.s = s; } }
const raw = s => new Raw(String(s));
const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const esc = s => String(s).replace(/[&<>"']/g, c => ESC[c]);
function rend(v) {
  if (v == null || v === false || v === true) return '';
  if (v instanceof Raw) return v.s;
  if (Array.isArray(v)) return v.map(rend).join('');
  return esc(v);
}
function html(strs, ...vals) {
  let o = '';
  strs.forEach((s, i) => { o += s; if (i < vals.length) o += rend(vals[i]); });
  return new Raw(o);
}
const setHTML = (el, r) => { el.innerHTML = rend(r); };

const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};

/* ───────── Иконки ───────── */
const ICONS = {
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  back: '<path d="M19 12H5M12 19l-7-7 7-7"/>',
  db: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="17" cy="9" r="2.5"/><path d="M17.5 14c2.7.2 4.5 2 4.5 5"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/>',
  list: '<path d="M9 6h12M9 12h12M9 18h12M4 6h.01M4 12h.01M4 18h.01"/>',
  server: '<rect x="3" y="4" width="18" height="6" rx="2"/><rect x="3" y="14" width="18" height="6" rx="2"/><path d="M7 7h.01M7 17h.01"/>',
  terminal: '<path d="M5 8l5 4-5 4M12 17h7"/>',
  signal: '<path d="M5 20v-4M10 20v-8M15 20V8M20 20V4"/>',
  bug: '<path d="M9 9a3 3 0 016 0v6a3 3 0 01-6 0z"/><path d="M12 6V3M9 5L7 3M15 5l2-2M6 12H3M18 12h3M6 17l-3 2M18 17l3 2M12 12v8"/>',
  cash: '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.6"/><path d="M6 12h.01M18 12h.01"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
  sliders: '<path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>',
  star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  book: '<path d="M5 4h11a3 3 0 013 3v13H8a3 3 0 01-3-3z"/><path d="M5 17a3 3 0 013-3h11"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5h.01"/>',
  moon: '<path d="M21 13a9 9 0 11-10-10 7 7 0 0010 10z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/>',
  bell: '<path d="M6 9a6 6 0 0112 0c0 6 2 7.5 2 7.5H4S6 15 6 9zM10 20a2 2 0 004 0"/>',
  grid: '<path d="M5 5h.01M12 5h.01M19 5h.01M5 12h.01M12 12h.01M19 12h.01M5 19h.01M12 19h.01M19 19h.01" stroke-width="3.6"/>',
  chev: '<path d="M9 6l6 6-6 6"/>',
  chevd: '<path d="M6 9l6 6 6-6"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16zM13.5 6.5l4 4"/>',
  refresh: '<path d="M20 11a8 8 0 00-14-4L4 9M4 4v5h5M4 13a8 8 0 0014 4l2-2M20 20v-5h-5"/>',
  lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
  logout: '<path d="M9 4H5v16h4M16 8l4 4-4 4M20 12H9"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
  ban: '<circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/>',
  key: '<circle cx="8" cy="12" r="4"/><path d="M12 12h9M18 12v3M15 12v2"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 00-2-2H6a2 2 0 00-2 2v8a2 2 0 002 2h2"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  alert: '<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/>',
  download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
  home: '<path d="M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10"/>',
  msg: '<path d="M4 5h16v11H9l-5 4z"/>',
  send: '<path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/>',
  diamond: '<path d="M6 3h12l4 6-10 12L2 9z"/><path d="M2 9h20M9 3l3 6 3-6M12 21L9 9M12 21l3-12"/>',
  mute: '<path d="M4 9v6h4l5 4V5L8 9zM17 9l4 6M21 9l-4 6"/>',
  kick: '<path d="M9 4H5v16h4M13 8l4 4-4 4M17 12H8"/>',
  warnc: '<circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 16.5h.01"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  pulse: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1 .9-1 1.7M12 17h.01"/>',
  zap: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  plug: '<path d="M9 2v6M15 2v6M6 8h12v3a6 6 0 0 1-12 0zM12 17v5"/>',
  hdd: '<rect x="3" y="13" width="18" height="7" rx="2"/><path d="M3 13l3-8h12l3 8M7 16.5h.01M11 16.5h.01"/>',
  upload: '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
  play: '<path d="M7 4l13 8-13 8z"/>',
  shieldc: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
};
function ic(name, size = 20, cls = '') {
  return raw(`<svg class="${cls}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ''}</svg>`);
}

/* ───────── Форматирование ───────── */
const pad = n => String(n).padStart(2, '0');
function fmtTime(ts, sec = true) {
  const d = new Date(ts);
  return `${pad(d.getDate())}.${pad(d.getMonth() + 1)} ${pad(d.getHours())}:${pad(d.getMinutes())}${sec ? ':' + pad(d.getSeconds()) : ''}`;
}
function fmtFull(ts) { if (!ts) return '—'; const d = new Date(ts); return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`; }
function fmtDate(ts) { const d = new Date(ts); return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`; }
function ago(ts) {
  if (!ts) return '—';
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 5) return 'только что';
  if (s < 60) return s + ' с назад';
  const m = Math.floor(s / 60);
  if (m < 60) return m + ' мин назад';
  const h = Math.floor(m / 60);
  if (h < 24) return h + ' ч назад';
  const d = Math.floor(h / 24);
  return d + ' дн назад';
}
function fmtDur(sec) {
  sec = Math.max(0, Math.round(sec));
  if (sec < 60) return sec + ' с';
  const m = Math.floor(sec / 60);
  if (m < 60) return m + ' мин';
  const h = Math.floor(m / 60);
  if (h < 48) return h + ' ч ' + (m % 60) + ' мин';
  return Math.floor(h / 24) + ' д ' + (h % 24) + ' ч';
}
function plural(n, [a, b, c]) { const m = n % 100, k = n % 10; if (m > 10 && m < 20) return c; if (k === 1) return a; if (k >= 2 && k <= 4) return b; return c; }
const hours = h => (Math.round(h * 10) / 10).toString().replace('.', ',');
function fmtBytes(b) { if (b < 1024) return b + ' Б'; if (b < 1048576) return (b / 1024).toFixed(1) + ' КБ'; return (b / 1048576).toFixed(1) + ' МБ'; }

function colorOf(s) {
  let h = 0;
  for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return `hsl(${h % 360} 55% 45%)`;
}
// Локальный аватар: пиксельное лицо, строится из ника без внешних запросов
function pixelFace(name) {
  let h = 2166136261;
  for (const c of String(name).toLowerCase()) h = Math.imul(h ^ c.charCodeAt(0), 16777619) >>> 0;
  const r = n => { h = Math.imul(h ^ (h >>> 13), 1274126177) >>> 0; return h % n; };
  const skin = ['#f2c9a0', '#e0ac7e', '#c68b5e', '#a8714a', '#f7d9bd', '#8d5a3b'][r(6)];
  const hair = ['#3b2a1a', '#1f1f24', '#7a4a21', '#c9a227', '#9b3d2e', '#5b5b66', '#2a5d9f'][r(7)];
  const eye = ['#2f5fd0', '#2b2b2b', '#2e8b57', '#6b4a2b'][r(4)];
  const sh = ['#4f7cff', '#2fcf8a', '#f5a623', '#a78bfa', '#38bdf8', '#f0524f'][r(6)];
  const fringe = 1 + r(3), side = r(2);
  let g = `<rect width="8" height="8" fill="${sh}"/><rect y="1" width="8" height="7" fill="${skin}"/><rect width="8" height="${fringe}" fill="${hair}"/>`;
  if (side) g += `<rect y="${fringe}" width="1" height="2" fill="${hair}"/><rect x="7" y="${fringe}" width="1" height="2" fill="${hair}"/>`;
  g += `<rect x="1" y="3" width="2" height="1" fill="#fff"/><rect x="5" y="3" width="2" height="1" fill="#fff"/><rect x="2" y="3" width="1" height="1" fill="${eye}"/><rect x="5" y="3" width="1" height="1" fill="${eye}"/>`;
  g += `<rect x="3" y="5" width="2" height="1" fill="rgba(0,0,0,.18)"/><rect x="2" y="6" width="4" height="1" fill="rgba(0,0,0,.28)"/>`;
  return 'data:image/svg+xml,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 8" shape-rendering="crispEdges">${g}</svg>`);
}
function head(name, size = 28) {
  const n = String(name || '?'), clean = n.replace(/^\./, '');
  const ext = store.get('skins', false);
  const local = pixelFace(clean);
  return raw(`<img class="head" width="${size}" height="${size}" style="width:${size}px;height:${size}px" src="${ext ? `https://mc-heads.net/avatar/${encodeURIComponent(clean)}/${size * 2}` : local}" alt="" loading="lazy" data-n="${esc(n)}" data-fb="${local}">`);
}
document.addEventListener('error', e => {
  const t = e.target;
  if (t && t.tagName === 'IMG' && t.classList.contains('head') && t.dataset.fb && t.src !== t.dataset.fb) { t.src = t.dataset.fb; return; }
  if (t && t.tagName === 'IMG' && t.classList.contains('head')) {
    const s = document.createElement('span');
    s.className = 'ph';
    s.textContent = (t.dataset.n || '?').replace(/^\./, '').charAt(0).toUpperCase();
    s.style.background = colorOf(t.dataset.n || '');
    if (t.style.width) { s.style.width = t.style.width; s.style.height = t.style.height; }
    t.replaceWith(s);
  }
}, true);

/* ───────── API ───────── */
let onUnauthorized = () => {};
async function api(path, { method = 'GET', body } = {}) {
  let r;
  try {
    r = await fetch('/api' + path, {
      method, credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-Panel': '1' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch { throw new Error('Нет связи с панелью'); }
  let j = {};
  try { j = await r.json(); } catch {}
  if (r.status === 401 && path !== '/login') { onUnauthorized(); throw new Error(j.error || 'Требуется вход'); }
  if (!r.ok) throw new Error(j.error || 'Ошибка ' + r.status);
  return j;
}
const qs = o => { const p = new URLSearchParams(); for (const [k, v] of Object.entries(o)) if (v !== undefined && v !== null && v !== '') p.set(k, v); const s = p.toString(); return s ? '?' + s : ''; };
const debounce = (fn, ms = 300) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

/* ───────── Тосты, модальные окна ───────── */
function toast(msg, type = 'ok', ms = 4500) {
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), ms);
}
const errToast = e => { if (e && e.stale) return; toast((e && e.message) || String(e), 'err', 6000); };

function modal({ title, body, footer, wide = false }) {
  const back = document.createElement('div');
  back.className = 'modal-back';
  back.innerHTML = `<div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true"><div class="modal-h"><h3>${esc(title)}</h3><button class="icon-btn" data-close aria-label="Закрыть">${ic('x').s}</button></div><div class="modal-b"></div>${footer === false ? '' : '<div class="modal-f"></div>'}</div>`;
  document.body.appendChild(back);
  const m = { el: back, body: $('.modal-b', back), foot: $('.modal-f', back), close() { back.remove(); document.removeEventListener('keydown', onKey); } };
  const onKey = e => { if (e.key === 'Escape') m.close(); };
  document.addEventListener('keydown', onKey);
  back.addEventListener('mousedown', e => { if (e.target === back) m.close(); });
  back.addEventListener('click', e => { if (e.target.closest('[data-close]')) m.close(); });
  if (body !== undefined) setHTML(m.body, body);
  if (footer && m.foot) setHTML(m.foot, footer);
  return m;
}

// Модальная форма: onSubmit(data, form, modal) -> бросает ошибку, чтобы показать её в форме
function formModal({ title, body, submit = 'Сохранить', danger = false, wide = false, onSubmit, onMount }) {
  const id = 'f' + Math.random().toString(36).slice(2, 8);
  const m = modal({
    title, wide,
    body: html`<form id="${id}" autocomplete="off" novalidate>${body}<div class="form-err" role="alert"></div></form>`,
    footer: html`<button class="btn ghost" type="button" data-close>Отмена</button><button class="btn ${danger ? 'danger' : 'primary'}" type="submit" form="${id}">${submit}</button>`,
  });
  const form = $('form', m.el), err = $('.form-err', m.el), btn = $('button[type=submit]', m.el);
  form.addEventListener('submit', async e => {
    e.preventDefault();
    err.textContent = '';
    btn.disabled = true;
    try { await onSubmit(Object.fromEntries(new FormData(form)), form, m); }
    catch (ex) { err.textContent = ex.message || String(ex); btn.disabled = false; }
  });
  const f = $('input:not([type=hidden]), select, textarea', form);
  if (f) setTimeout(() => f.focus(), 30);
  if (onMount) onMount(form, m);
  return m;
}

function confirmBox(title, text, { ok = 'Подтвердить', danger = false } = {}) {
  return new Promise(res => {
    const m = modal({
      title, body: html`<p style="margin:0">${text}</p>`,
      footer: html`<button class="btn ghost" data-close>Отмена</button><button class="btn ${danger ? 'danger' : 'primary'}" id="cb-ok">${ok}</button>`,
    });
    let done = false;
    $('#cb-ok', m.el).addEventListener('click', () => { done = true; m.close(); res(true); });
    new MutationObserver(() => { if (!document.body.contains(m.el) && !done) { done = true; res(false); } }).observe(document.body, { childList: true });
  });
}

async function copyText(text) {
  try { await navigator.clipboard.writeText(text); }
  catch {
    const t = document.createElement('textarea');
    t.value = text; t.style.position = 'fixed'; t.style.opacity = '0';
    document.body.appendChild(t); t.select();
    try { document.execCommand('copy'); } catch {}
    t.remove();
  }
  toast('Скопировано');
}
function genPass(len = 14) {
  const abc = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const a = new Uint32Array(len); crypto.getRandomValues(a);
  return [...a].map(n => abc[n % abc.length]).join('');
}
function downloadFile(name, text, type = 'text/csv') {
  if (window.MCPanelApp && window.MCPanelApp.saveFile) { // внутри Android-приложения blob-ссылки не скачиваются — отдаём файл приложению
    const bytes = new TextEncoder().encode('\ufeff' + text); let bin = '';
    for (let i = 0; i < bytes.length; i += 8192) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
    return window.MCPanelApp.saveFile(name, type, btoa(bin));
  }
  const url = URL.createObjectURL(new Blob(['﻿' + text], { type: type + ';charset=utf-8' }));
  const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/* ───────── Графики и полосы ───────── */
function niceMax(v) {
  if (v <= 5) return 5;
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  for (const k of [1, 2, 2.5, 5, 10]) if (v <= k * p) return k * p;
  return 10 * p;
}
function lineChart(points, { key = 'online', h = 190, color = 'var(--acc)', unit = '', min = 0, xfmt } = {}) {
  if (!points.length) return html`<div class="empty small">Данных пока нет — они появятся через минуту после подключения сервера</div>`;
  const W = 680, pl = 36, pr = 10, pt = 12, pb = 24;
  const x0 = points[0].ts, x1 = Math.max(points[points.length - 1].ts, x0 + 3600e3);
  const ymax = niceMax(Math.max(1, ...points.map(p => p[key] || 0)));
  const X = t => pl + ((t - x0) / (x1 - x0)) * (W - pl - pr);
  const Y = v => pt + (1 - ((v || 0) - min) / (ymax - min)) * (h - pt - pb);
  const line = points.map((p, i) => `${i ? 'L' : 'M'}${X(p.ts).toFixed(1)} ${Y(p[key]).toFixed(1)}`).join('');
  const area = `${line}L${X(points[points.length - 1].ts).toFixed(1)} ${h - pb}L${X(points[0].ts).toFixed(1)} ${h - pb}Z`;
  let grid = '';
  for (let i = 0; i <= 4; i++) {
    const v = min + ((ymax - min) * i) / 4, y = Y(v);
    grid += `<line class="grid-l" x1="${pl}" x2="${W - pr}" y1="${y}" y2="${y}"/><text x="${pl - 6}" y="${y + 4}" text-anchor="end">${Math.round(v * 10) / 10}</text>`;
  }
  let xl = '';
  for (let i = 0; i <= 4; i++) {
    const t = x0 + ((x1 - x0) * i) / 4, d = new Date(t);
    xl += `<text x="${X(t)}" y="${h - 6}" text-anchor="${i === 0 ? 'start' : i === 4 ? 'end' : 'middle'}">${xfmt ? xfmt(t) : `${pad(d.getHours())}:${pad(d.getMinutes())}`}</text>`;
  }
  const step = Math.max(1, Math.floor(points.length / 120));
  const hits = points.filter((_, i) => i % step === 0).map(p => `<circle cx="${X(p.ts).toFixed(1)}" cy="${Y(p[key]).toFixed(1)}" r="7" fill="transparent"><title>${esc(fmtTime(p.ts, false))} — ${p[key]}${unit}</title></circle>`).join('');
  const dots = points.length <= 2 ? points.map(p => `<circle cx="${X(p.ts).toFixed(1)}" cy="${Y(p[key]).toFixed(1)}" r="3.5" fill="${color}"/>`).join('') : '';
  return raw(`<svg class="chart" viewBox="0 0 ${W} ${h}" role="img" aria-label="График">${grid}${xl}<path d="${area}" fill="${color}" opacity=".14"/><path d="${line}" fill="none" stroke="${color}" stroke-width="2.2" stroke-linejoin="round"/>${dots}${hits}</svg>`);
}
function barList(items) {
  const max = Math.max(1, ...items.map(i => i.c));
  return html`<div class="blist">${items.map(i => html`<div class="bl"><span title="${i.name}">${i.name}</span><div class="bar"><i style="width:${(i.c / max) * 100}%"></i></div><b>${i.c}</b></div>`)}</div>`;
}
function progress(val, norm, unitFmt = v => v) {
  if (!norm) return html`<span class="mut">${unitFmt(val)}</span>`;
  const pct = Math.min(100, (val / norm) * 100);
  const cls = val >= norm ? 'ok' : pct >= 50 ? 'warn' : 'bad';
  return html`<div style="min-width:120px"><div class="row" style="justify-content:space-between;font-size:13px;margin-bottom:4px"><b>${unitFmt(val)}</b><span class="mut">из ${unitFmt(norm)}</span></div><div class="bar ${cls}"><i style="width:${pct}%"></i></div></div>`;
}

/* ───────── Типы событий ───────── */
const EV = {
  join: ['Вход', 'ok'], leave: ['Выход', 'mut'], chat: ['Чат', ''], command: ['Команда', 'warn'], death: ['Смерть', 'bad'],
  advancement: ['Достижение', 'purple'], punishment: ['Наказание', 'bad'], report: ['Репорт', 'warn'], server_start: ['Запуск', 'ok'],
  server_stop: ['Остановка', 'bad'], status: ['Статус', 'cyan'], agent: ['Агент', 'cyan'], error: ['Ошибка', 'bad'],
  block_break: ['Блок сломан', 'warn'], block_place: ['Блок поставлен', 'cyan'], container: ['Контейнер', 'purple'], teleport: ['Телепорт', 'cyan'],
  kill: ['Убийство', 'bad'], item_drop: ['Выброс', 'mut'], item_pickup: ['Подбор', 'mut'], gamemode: ['Режим игры', 'purple'],
};
const evLabel = t => (EV[t] ? EV[t][0] : t);
const evBadge = t => html`<span class="badge ${EV[t] ? EV[t][1] : 'mut'}">${evLabel(t)}</span>`;
const DET_KEYS = { ip: 'IP', world: 'мир', pos: 'коорд.', killer: 'убийца', by: 'кто', kind: 'тип', reason: 'причина', target: 'цель', duration: 'срок', version: 'версия', uuid: 'UUID', name: 'имя', item: 'предмет', block: 'блок', x: 'x', y: 'y', z: 'z' };
function evDetails(e) {
  const d = e.data;
  if (!d) return '';
  const parts = [];
  for (const [k, v] of Object.entries(d)) {
    if (v == null || v === '' || k === 'entity' || k === 'id' || k === 'source') continue;
    if (e.type === 'join' && k === 'uuid') continue;
    if (k === 'duration') { parts.push(`срок: ${fmtDur(v)}`); continue; }
    parts.push(`${DET_KEYS[k] || k}: ${typeof v === 'object' ? JSON.stringify(v) : v}`);
  }
  return parts.join(' · ');
}
const PUN = { ban: ['Бан', 'bad'], unban: ['Разбан', 'ok'], kick: ['Кик', 'warn'], mute: ['Мут', 'warn'], unmute: ['Размут', 'ok'], warn: ['Предупреждение', 'purple'] };
const punBadge = t => html`<span class="badge ${PUN[t] ? PUN[t][1] : 'mut'}">${PUN[t] ? PUN[t][0] : t}</span>`;
