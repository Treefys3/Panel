'use strict';
// Service worker: панель открывается как приложение и быстро стартует. API никогда не кэшируется.
const CACHE = 'mcpanel-shell-v1';
const SHELL = ['/', '/style.css', '/ui.js', '/server-views.js', '/app.js', '/admin-views.js', '/admin-views2.js', '/boot.js', '/manifest.webmanifest', '/icons/icon-192.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin) return;
  if (/^\/(api|install|agent-dl|healthz|app\.apk)/.test(u.pathname)) return;
  // сначала сеть (всегда свежая версия), при отсутствии связи — копия из кэша
  e.respondWith(fetch(r).then(res => {
    if (res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(r, copy)); }
    return res;
  }).catch(() => caches.match(r).then(m => m || (r.mode === 'navigate' ? caches.match('/') : Response.error()))));
});
