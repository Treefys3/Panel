'use strict';
/* ───────── Роли, автомодерация, планировщик, интеграции, система, справка, поиск ───────── */

const roleBadge = key => {
  const r = (S.roleList || []).find(x => x.key === key);
  const c = r ? r.color : '#8791b5';
  return html`<span class="badge" style="background:${c}26;color:${c}">${r ? r.label : key}</span>`;
};
const permLabel = p => { for (const g of S.catalog || []) for (const i of g.items) if (i[0] === p) return i[1]; return p; };
const rolesWith = perm => (S.roleList || []).filter(r => (S.rolePerms[r.key] || []).some(x => x === '*' || x === perm));

/* ═════════ Роли и доступ ═════════ */
async function rolesView() {
  const a = vapi();
  const d = await a('/roles');
  let dcRoles = null;
  if (can('system')) dcRoles = await a('/discord/roles').then(r => r.roles).catch(() => null);
  const total = d.catalog.reduce((n, g) => n + g.items.length, 0);
  setHTML(V(), html`${pageHead('Роли и доступ', 'Решайте, какие разделы и действия доступны каждой роли. Роль выдаётся сотруднику на странице «Пользователи».', html`${can('system') && dcRoles ? html`<button class="btn" data-r="dcsync">${ic('refresh', 16)} Роли из Discord</button> ` : ''}<button class="btn primary" data-r="new">${ic('plus', 18)} Новая роль</button>`)}
    <div class="note" style="margin-bottom:16px">Владелец всегда имеет полный доступ. Доступ к <b>конкретным серверам</b> задаётся отдельно для каждого сотрудника на странице «Пользователи» — так можно, например, пустить модератора только на один сервер.</div>
    <div class="grid g2">
      <div class="card"><div class="row"><span class="badge purple">Владелец</span><span class="mut">полный доступ, нельзя изменить</span></div></div>
      ${d.roles.map(r => html`<div class="card">
        <div class="row wrap"><span class="badge" style="background:${r.color}26;color:${r.color}">${r.label}</span>${r.builtin ? html`<span class="badge mut">встроенная</span>` : ''}${r.from_discord ? html`<span class="badge" style="background:#5865f226;color:#8b95ff">из Discord</span>` : ''}<span class="mut grow" style="font-size:13px">${r.users} ${plural(r.users, ['сотрудник', 'сотрудника', 'сотрудников'])} · ${r.perms.length} из ${total} прав</span><button class="btn sm ghost" data-r="up" data-k="${r.key}" title="Выше">↑</button><button class="btn sm ghost" data-r="down" data-k="${r.key}" title="Ниже">↓</button></div>
        ${r.description ? html`<div class="mut" style="font-size:13.5px;margin-top:8px">${r.description}</div>` : ''}
        ${r.discord_role_id ? html`<div style="margin-top:8px"><span class="badge" style="background:#5865f226;color:#8b95ff">Discord: ${(dcRoles && (dcRoles.find(x => x.id === r.discord_role_id) || {}).name) || r.discord_role_id}</span></div>` : ''}
        <div class="chips" style="margin:12px 0">${r.perms.length ? r.perms.map(p => html`<span class="chip on" style="cursor:default">${permLabel(p)}</span>`) : html`<span class="mut">Нет прав — роль видит только «Информацию»</span>`}</div>
        <div class="row wrap"><button class="btn sm" data-r="edit" data-k="${r.key}">${ic('edit', 15)} Настроить</button><button class="btn sm" data-r="copy" data-k="${r.key}">${ic('copy', 15)} Копия</button>${r.builtin ? '' : html`<button class="btn sm danger" data-r="del" data-k="${r.key}">${ic('trash', 15)}</button>`}</div>
      </div>`)}
    </div>`);

  const IMPLIED = { 'whitelist': ['whitelist.view'], 'quotas': ['quotas.view'], 'ban': ['punish'] };
  const permBoxes = cur => html`${d.catalog.map(g => html`<div class="field"><label>${g.group}</label><div style="display:grid;gap:8px">
    ${g.items.map(([p, l, desc]) => html`<label class="check" style="align-items:flex-start"><input type="checkbox" name="perm" value="${p}" ${cur.includes(p) ? 'checked' : ''} style="margin-top:2px"><span><b>${l}</b><div class="mut" style="font-size:12.5px;font-weight:400">${desc}</div></span></label>`)}</div></div>`)}`;
  const mountPerms = f => {
    f.addEventListener('change', e => {
      if (e.target.name !== 'perm') return;
      const on = e.target.checked;
      if (on) for (const imp of IMPLIED[e.target.value] || []) { const b = $(`input[value="${imp}"]`, f); if (b) b.checked = true; }
      else for (const [big, list] of Object.entries(IMPLIED)) if (list.includes(e.target.value)) { const b = $(`input[value="${big}"]`, f); if (b) b.checked = false; }
    });
    $('[data-all]', f).onclick = () => $$('input[name=perm]', f).forEach(i => { i.checked = true; });
    $('[data-none]', f).onclick = () => $$('input[name=perm]', f).forEach(i => { i.checked = false; });
  };
  const roleForm = (title, r, submit, onOk) => formModal({
    title, wide: true, submit,
    body: html`<div class="fgrid"><div class="field"><label>Название роли</label><input class="input" name="label" value="${r.label}" maxlength="30" required></div>
      <div class="field"><label>Цвет</label><input type="color" name="color" value="${r.color}" style="height:42px;width:100%;padding:3px;background:var(--input);border:1px solid var(--line);border-radius:10px"></div></div>
      <div class="field"><label>Описание</label><input class="input" name="description" value="${r.description || ''}" maxlength="120" placeholder="Кому выдавать эту роль"></div>
      ${dcRoles ? html`<div class="field"><label>Роль на Discord-сервере</label><select class="select" name="discord_role_id"><option value="">— не привязана —</option>${dcRoles.map(x => html`<option value="${x.id}" ${r.discord_role_id === x.id ? 'selected' : ''}>${x.name}${x.admin ? ' (Администратор)' : ''}</option>`)}</select><div class="hint">Кто получит эту роль в Discord — сможет войти в панель с этой ролью.</div></div>`
        : (can('system') ? html`<div class="field"><label>ID роли Discord (необязательно)</label><input class="input mono" name="discord_role_id" value="${r.discord_role_id || ''}" inputmode="numeric" placeholder="только цифры"><div class="hint">Добавьте токен бота в «Система → Вход через Discord», и роли можно будет выбирать списком.</div></div>` : '')}
      <div class="row" style="margin-bottom:12px"><b class="grow">Что разрешено</b><button class="btn sm" type="button" data-all>Выбрать всё</button><button class="btn sm" type="button" data-none>Снять всё</button></div>
      ${permBoxes(r.perms)}<div class="hint">Права связаны: «Бан» включает кик/мут, «Управление вайтлистом» включает просмотр. Раздел «Информация» и справка доступны всем.</div>`,
    onMount: mountPerms,
    onSubmit: async (dd, f, m) => onOk({ label: dd.label, color: dd.color, description: dd.description, ...(dd.discord_role_id !== undefined ? { discord_role_id: dd.discord_role_id } : {}), perms: $$('input[name=perm]:checked', f).map(i => i.value) }, m),
  });
  const reload = async () => { await loadMe(); renderSidebar(); rolesView().catch(errToast); };
  V().onclick = async e => {
    const b = e.target.closest('[data-r]'); if (!b) return;
    const r = d.roles.find(x => x.key === b.dataset.k);
    if (b.dataset.r === 'dcsync') { b.disabled = true; return api('/discord/import-roles', { method: 'POST', body: {} }).then(r => { toast(`Из Discord: добавлено ${r.created}, обновлено ${r.updated}, удалено ${r.removed}`); reload(); }).catch(ex => { errToast(ex); b.disabled = false; }); }
    if (b.dataset.r === 'up' || b.dataset.r === 'down') {
      const keys = d.roles.map(x => x.key), i = keys.indexOf(b.dataset.k), j = b.dataset.r === 'up' ? i - 1 : i + 1;
      if (j < 0 || j >= keys.length) return;
      [keys[i], keys[j]] = [keys[j], keys[i]];
      return api('/roles/reorder', { method: 'POST', body: { keys } }).then(reload).catch(errToast);
    }
    if (b.dataset.r === 'new') {
      roleForm('Новая роль', { label: '', color: '#4f7cff', perms: ['status', 'online', 'logs', 'players'] }, 'Создать', async (body, m) => { await api('/roles', { method: 'POST', body }); m.close(); toast('Роль создана'); reload(); });
    } else if (b.dataset.r === 'copy') {
      roleForm('Копия роли «' + r.label + '»', { ...r, label: r.label + ' (копия)' }, 'Создать', async (body, m) => { await api('/roles', { method: 'POST', body }); m.close(); toast('Роль создана'); reload(); });
    } else if (b.dataset.r === 'edit') {
      roleForm('Роль «' + r.label + '»', r, 'Сохранить', async (body, m) => { await api('/roles/' + r.key, { method: 'PATCH', body }); m.close(); toast('Сохранено — права применены сразу'); reload(); });
    } else if (b.dataset.r === 'del') {
      if (await confirmBox('Удалить роль', `Роль «${r.label}» будет удалена. Сотрудников с этой ролью быть не должно.`, { ok: 'Удалить', danger: true })) api('/roles/' + r.key, { method: 'DELETE', body: {} }).then(() => { toast('Удалено'); reload(); }).catch(errToast);
    }
  };
}

/* ═════════ Автомодерация ═════════ */
const AM_HINT = {
  words: 'Срабатывает, если в сообщении чата есть слово из списка.',
  caps: 'Сообщение, где заглавных букв больше заданного процента.',
  ads: 'Ссылки, IP-адреса и домены в чате. В исключения можно вписать свой адрес.',
  spam: 'Слишком много сообщений за короткое время.',
  ban_evasion: 'Игрок зашёл с IP-адреса забаненного аккаунта (обход бана).',
  commands: 'Игрок использует одну из перечисленных команд (например /op).',
};
const AM_ACT = { notify: 'Только уведомить персонал', warn: 'Предупреждение', mute: 'Мут', kick: 'Кик', ban: 'Бан' };
const AM_PRESETS = [
  ['Запрещённые слова', { name: 'Запрещённые слова', type: 'words', action: 'mute', minutes: 10, reason: 'Нецензурная лексика', config: { words: [], mode: 'word' } }],
  ['Реклама — мут', { name: 'Реклама в чате', type: 'ads', action: 'mute', minutes: 60, reason: 'Реклама', config: { allow: [] } }],
  ['Капс', { name: 'Капс', type: 'caps', action: 'warn', minutes: 0, reason: 'Не злоупотребляйте капсом', config: { min_len: 8, percent: 70 } }],
  ['Флуд — мут', { name: 'Флуд', type: 'spam', action: 'mute', minutes: 5, reason: 'Флуд', config: { messages: 5, seconds: 6 } }],
  ['Опасные команды', { name: 'Опасные команды', type: 'commands', action: 'notify', minutes: 0, reason: '', config: { commands: ['op', 'gamemode', 'give', 'execute'] } }],
  ['Обход бана', { name: 'Обход бана', type: 'ban_evasion', action: 'notify', minutes: 0, reason: '', config: {} }],
];
const amFields = (type, c = {}) => {
  const list = x => (Array.isArray(x) ? x : []).join(', ');
  if (type === 'words') return html`<div class="field"><label>Слова</label><textarea class="input" name="words" rows="3" placeholder="через запятую или с новой строки">${list(c.words)}</textarea></div>
    <div class="field"><label>Совпадение</label><select class="select" name="mode"><option value="word" ${c.mode === 'word' ? 'selected' : ''}>Слово целиком</option><option value="contains" ${c.mode !== 'word' ? 'selected' : ''}>Часть слова</option></select></div>`;
  if (type === 'caps') return html`<div class="fgrid"><div class="field"><label>Мин. длина сообщения</label><input class="input" type="number" name="min_len" min="3" max="100" value="${c.min_len || 8}"></div><div class="field"><label>% заглавных</label><input class="input" type="number" name="percent" min="30" max="100" value="${c.percent || 70}"></div></div>`;
  if (type === 'ads') return html`<div class="field"><label>Разрешённые адреса (исключения)</label><textarea class="input" name="allow" rows="2" placeholder="например, play.myserver.ru">${list(c.allow)}</textarea></div>`;
  if (type === 'spam') return html`<div class="fgrid"><div class="field"><label>Сообщений</label><input class="input" type="number" name="messages" min="3" max="30" value="${c.messages || 5}"></div><div class="field"><label>За секунд</label><input class="input" type="number" name="seconds" min="2" max="60" value="${c.seconds || 6}"></div></div>`;
  if (type === 'commands') return html`<div class="field"><label>Команды (без /)</label><textarea class="input" name="commands" rows="2">${list(c.commands)}</textarea></div>`;
  return html`<div class="mut" style="font-size:13.5px">Дополнительных настроек нет.</div>`;
};
const amReadCfg = (type, f) => {
  const v = n => (f[n] ? f[n].value : '');
  return ({ words: { words: v('words'), mode: v('mode') }, caps: { min_len: v('min_len'), percent: v('percent') }, ads: { allow: v('allow') }, spam: { messages: v('messages'), seconds: v('seconds') }, commands: { commands: v('commands') } })[type] || {};
};

async function automodView(s) {
  const a = vapi();
  const d = await a(`/servers/${s.id}/automod`);
  const act = r => r.action === 'notify' ? html`<span class="badge mut">Уведомить</span>` : html`<span class="badge warn">${AM_ACT[r.action]}${r.duration && (r.action === 'mute' || r.action === 'ban') ? ' · ' + fmtDur(r.duration) : ''}</span>`;
  setHTML(V(), html`${sPage(s, 'Автомодерация', 'правила, которые реагируют на чат и команды сами', html`<button class="btn primary" data-am="new">${ic('plus', 18)} Добавить правило</button>`)}
    ${d.can_command ? '' : html`<div class="note warn" style="margin-bottom:14px">Нет связи с сервером для команд: правила будут только уведомлять персонал, а мут/кик/бан не выполнятся. Подключите агента или RCON.</div>`}
    <div class="card flush"><div class="table-wrap"><table class="t"><thead><tr><th>Вкл</th><th>Правило</th><th>Что ловит</th><th>Действие</th><th>Срабатываний</th><th></th></tr></thead><tbody>
      ${d.rules.length ? d.rules.map(r => html`<tr><td><input type="checkbox" class="chk" data-am="toggle" data-id="${r.id}" ${r.enabled ? 'checked' : ''} aria-label="Включено"></td>
        <td><b>${r.name}</b></td><td><span class="badge">${d.types[r.type] || r.type}</span></td><td>${act(r)}</td>
        <td>${r.hits || 0}${r.last_hit ? html`<div class="mut" style="font-size:12px">${ago(r.last_hit)}</div>` : ''}</td>
        <td class="nowrap" style="text-align:right"><button class="btn sm" data-am="edit" data-id="${r.id}">${ic('edit', 15)}</button> <button class="btn sm danger" data-am="del" data-id="${r.id}">${ic('trash', 15)}</button></td></tr>`) : html`<tr><td colspan="6" class="empty">Правил нет — добавьте первое из шаблонов</td></tr>`}
    </tbody></table></div></div>
    <div class="grid g2 mt">
      <div class="card"><h3>Проверить текст</h3><p class="mut" style="margin:0 0 10px;font-size:13.5px">Сообщение ничего не выполняет — только показывает, какие правила сработали бы.</p>
        <form class="row" id="am-test"><input class="input grow" name="text" placeholder="Введите сообщение из чата" maxlength="300"><button class="btn" type="submit">Проверить</button></form><div id="am-res" style="margin-top:10px"></div></div>
      <div class="card flush"><div class="card-h"><h3>Последние срабатывания</h3></div>${d.recent.length ? d.recent.map(e => html`<div class="ev"><div class="ev-t">${fmtTime(e.ts)}</div><div class="ev-b">${e.player ? html`<a class="pl" href="#/s/${s.id}/players/${encodeURIComponent(e.player)}">${e.player}</a>` : ''}<span class="ev-m">${e.message}</span></div></div>`) : html`<div class="empty small">Срабатываний пока не было</div>`}</div>
    </div>`);
  const reload = () => automodView(s).catch(errToast);
  const ruleModal = rule => {
    const r = rule || { name: '', type: 'words', action: 'notify', duration: 0, reason: '', config: {}, enabled: true };
    formModal({
      title: rule ? 'Правило: ' + rule.name : 'Новое правило', wide: true,
      body: html`${rule ? '' : html`<div class="field"><label>Шаблон</label><div class="chips">${AM_PRESETS.map(([l], i) => html`<button type="button" class="chip" data-pre="${i}">${l}</button>`)}</div></div>`}
        <div class="fgrid"><div class="field"><label>Название</label><input class="input" name="name" value="${r.name}" required maxlength="60"></div>
        <div class="field"><label>Тип</label><select class="select" name="type" ${rule ? 'disabled' : ''}>${Object.entries(d.types).map(([k, v]) => html`<option value="${k}" ${r.type === k ? 'selected' : ''}>${v}</option>`)}</select></div></div>
        <div class="hint" id="am-hint" style="margin:-6px 0 12px">${AM_HINT[r.type]}</div><div id="am-cfg">${amFields(r.type, r.config)}</div>
        <div class="fgrid"><div class="field"><label>Что делать</label><select class="select" name="action">${Object.entries(AM_ACT).map(([k, v]) => html`<option value="${k}" ${r.action === k ? 'selected' : ''}>${v}</option>`)}</select></div>
        <div class="field"><label>Срок, минут</label><input class="input" type="number" name="minutes" min="0" value="${r.duration ? Math.round(r.duration / 60) : 0}"><div class="hint">Для мута и бана. 0 — навсегда.</div></div></div>
        <div class="field"><label>Причина (покажется игроку и в логах)</label><input class="input" name="reason" value="${r.reason || ''}" maxlength="200"></div>
        <div class="hint">Сотрудники с ником в панели правилами не наказываются. Любое срабатывание попадает в «Логи» сервера.</div>`,
      onMount: f => {
        const setType = (t, c) => { $('#am-cfg', f).innerHTML = rend(amFields(t, c)); $('#am-hint', f).textContent = AM_HINT[t]; };
        f.type.onchange = () => setType(f.type.value, {});
        $$('[data-pre]', f).forEach(b => b.onclick = () => {
          const p = AM_PRESETS[b.dataset.pre][1];
          f.name.value = p.name; f.type.value = p.type; f.action.value = p.action; f.minutes.value = p.minutes; f.reason.value = p.reason; setType(p.type, p.config);
        });
      },
      onSubmit: async (dd, f, m) => {
        const type = rule ? rule.type : f.type.value;
        const body = { name: dd.name, action: dd.action, duration: (dd.action === 'mute' || dd.action === 'ban') ? (Number(dd.minutes) || 0) * 60 : 0, reason: dd.reason, config: amReadCfg(type, f) };
        if (rule) await api(`/servers/${s.id}/automod/${rule.id}`, { method: 'PATCH', body });
        else await api(`/servers/${s.id}/automod`, { method: 'POST', body: { ...body, type } });
        m.close(); toast('Сохранено'); reload();
      },
    });
  };
  const v = V();
  v.onclick = async e => {
    const b = e.target.closest('[data-am]'); if (!b) return;
    const r = d.rules.find(x => x.id == b.dataset.id);
    if (b.dataset.am === 'new') ruleModal(null);
    else if (b.dataset.am === 'edit') ruleModal(r);
    else if (b.dataset.am === 'del') { if (await confirmBox('Удалить правило', `Правило «${r.name}» будет удалено.`, { ok: 'Удалить', danger: true })) api(`/servers/${s.id}/automod/${r.id}`, { method: 'DELETE', body: {} }).then(() => { toast('Удалено'); reload(); }).catch(errToast); }
  };
  v.onchange = e => {
    const b = e.target.closest('[data-am=toggle]'); if (!b) return;
    api(`/servers/${s.id}/automod/${b.dataset.id}`, { method: 'PATCH', body: { enabled: b.checked } }).then(() => toast(b.checked ? 'Правило включено' : 'Правило выключено')).catch(ex => { b.checked = !b.checked; errToast(ex); });
  };
  v.onsubmit = async e => {
    e.preventDefault();
    if (e.target.id !== 'am-test') return;
    try {
      const r = await a(`/servers/${s.id}/automod/test`, { method: 'POST', body: { text: e.target.text.value } });
      setHTML($('#am-res'), r.matches.length ? html`${r.matches.map(m => html`<div class="note warn" style="margin-bottom:6px">Сработает «${m.name}»${m.enabled ? '' : ' (выключено)'}: ${m.match}</div>`)}` : html`<div class="note">Ни одно правило не сработало.</div>`);
    } catch (ex) { errToast(ex); }
  };
}

/* ═════════ Планировщик ═════════ */
const DAYS = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
const SCH_PRESETS = [
  ['Автосохранение', { name: 'Автосохранение мира', kind: 'interval', every_min: 30, commands: 'save-all' }],
  ['Объявление', { name: 'Объявление в чат', kind: 'interval', every_min: 20, commands: 'say Заходите в наш Discord и читайте правила сервера!' }],
  ['Предупреждение о рестарте', { name: 'Предупреждение о рестарте', kind: 'daily', at_time: '03:55', commands: 'say Через 5 минут перезагрузка сервера!' }],
];
const schWhen = t => t.kind === 'interval' ? `каждые ${t.every_min} мин` : `в ${t.at_time}, ${(t.days || '').split(',').map(n => DAYS[n - 1]).join(' ')}`;

async function schedulerView(s) {
  const a = vapi();
  const d = await a(`/servers/${s.id}/schedules`);
  setHTML(V(), html`${sPage(s, 'Планировщик', 'команды и объявления по расписанию', html`<button class="btn primary" data-sc="new">${ic('plus', 18)} Новая задача</button>`)}
    ${d.can_command ? '' : html`<div class="note warn" style="margin-bottom:14px">Нет связи с сервером для команд (агент не подключён или RCON не настроен) — задачи не смогут выполниться.</div>`}
    <div class="card flush"><div class="table-wrap"><table class="t"><thead><tr><th>Вкл</th><th>Задача</th><th>Когда</th><th>Команды</th><th>Последний запуск</th><th></th></tr></thead><tbody>
    ${d.items.length ? d.items.map(t => html`<tr><td><input type="checkbox" class="chk" data-sc="toggle" data-id="${t.id}" ${t.enabled ? 'checked' : ''} aria-label="Включено"></td><td><b>${t.name}</b></td><td class="nowrap">${schWhen(t)}</td>
      <td class="mono" style="max-width:280px;font-size:12.5px;white-space:pre-wrap;word-break:break-word">${t.commands}</td>
      <td>${t.last_run ? html`${ago(t.last_run)}<div class="mut" style="font-size:12px;max-width:220px">${t.last_result || ''}</div>` : html`<span class="mut">ещё не запускалась</span>`}</td>
      <td class="nowrap" style="text-align:right"><button class="btn sm" data-sc="run" data-id="${t.id}" title="Выполнить сейчас">${ic('play', 15)}</button> <button class="btn sm" data-sc="edit" data-id="${t.id}">${ic('edit', 15)}</button> <button class="btn sm danger" data-sc="del" data-id="${t.id}">${ic('trash', 15)}</button></td></tr>`) : html`<tr><td colspan="6" class="empty">Задач нет — создайте первую из шаблонов</td></tr>`}
    </tbody></table></div></div>`);
  const reload = () => schedulerView(s).catch(errToast);
  const whenFields = (t) => t.kind === 'daily'
    ? html`<div class="fgrid"><div class="field"><label>Время (по серверу панели)</label><input class="input" type="time" name="at_time" value="${t.at_time || '04:00'}" required></div>
        <div class="field"><label>Дни</label><div class="chips">${DAYS.map((n, i) => html`<label class="chip ${(t.days || '1,2,3,4,5,6,7').split(',').includes(String(i + 1)) ? 'on' : ''}"><input type="checkbox" name="day" value="${i + 1}" ${(t.days || '1,2,3,4,5,6,7').split(',').includes(String(i + 1)) ? 'checked' : ''} hidden>${n}</label>`)}</div></div></div>`
    : html`<div class="field"><label>Повторять каждые, минут</label><input class="input" type="number" name="every_min" min="1" max="10080" value="${t.every_min || 30}" required></div>`;
  const taskModal = task => {
    const t = task || { name: '', kind: 'interval', every_min: 30, commands: '' };
    formModal({
      title: task ? 'Задача: ' + task.name : 'Новая задача', wide: true,
      body: html`${task ? '' : html`<div class="field"><label>Шаблон</label><div class="chips">${SCH_PRESETS.map(([l], i) => html`<button type="button" class="chip" data-pre="${i}">${l}</button>`)}</div></div>`}
        <div class="fgrid"><div class="field"><label>Название</label><input class="input" name="name" value="${t.name}" required maxlength="60"></div>
        <div class="field"><label>Расписание</label><select class="select" name="kind"><option value="interval" ${t.kind === 'interval' ? 'selected' : ''}>Через равные промежутки</option><option value="daily" ${t.kind === 'daily' ? 'selected' : ''}>Каждый день в заданное время</option></select></div></div>
        <div id="sc-when">${whenFields(t)}</div>
        <div class="field"><label>Команды (каждая с новой строки, без /)</label><textarea class="input mono" name="commands" rows="4" required>${t.commands}</textarea><div class="hint">До 20 команд. Выполняются по очереди через агента или RCON.</div></div>`,
      onMount: f => {
        const draw = t2 => { $('#sc-when', f).innerHTML = rend(whenFields(t2)); };
        f.kind.onchange = () => draw({ kind: f.kind.value, ...(task && task.kind === f.kind.value ? task : {}) });
        f.addEventListener('change', e => { if (e.target.name === 'day') e.target.closest('.chip').classList.toggle('on', e.target.checked); });
        $$('[data-pre]', f).forEach(b => b.onclick = () => { const p = SCH_PRESETS[b.dataset.pre][1]; f.name.value = p.name; f.kind.value = p.kind; draw(p); f.commands.value = p.commands; });
      },
      onSubmit: async (dd, f, m) => {
        const body = { name: dd.name, kind: dd.kind, commands: dd.commands };
        if (dd.kind === 'interval') body.every_min = dd.every_min; else { body.at_time = dd.at_time; body.days = $$('input[name=day]:checked', f).map(i => i.value); }
        if (task) await api(`/servers/${s.id}/schedules/${task.id}`, { method: 'PATCH', body }); else await api(`/servers/${s.id}/schedules`, { method: 'POST', body });
        m.close(); toast('Сохранено'); reload();
      },
    });
  };
  const v = V();
  v.onclick = async e => {
    const b = e.target.closest('[data-sc]'); if (!b || b.dataset.sc === 'toggle') return;
    const t = d.items.find(x => x.id == b.dataset.id);
    if (b.dataset.sc === 'new') taskModal(null);
    else if (b.dataset.sc === 'edit') taskModal(t);
    else if (b.dataset.sc === 'run') { b.disabled = true; try { const r = await api(`/servers/${s.id}/schedules/${t.id}/run`, { method: 'POST', body: {} }); toast('Выполнено: ' + r.result); reload(); } catch (ex) { errToast(ex); b.disabled = false; } }
    else if (b.dataset.sc === 'del') { if (await confirmBox('Удалить задачу', `Задача «${t.name}» будет удалена.`, { ok: 'Удалить', danger: true })) api(`/servers/${s.id}/schedules/${t.id}`, { method: 'DELETE', body: {} }).then(() => { toast('Удалено'); reload(); }).catch(errToast); }
  };
  v.onchange = e => {
    const b = e.target.closest('[data-sc=toggle]'); if (!b) return;
    api(`/servers/${s.id}/schedules/${b.dataset.id}`, { method: 'PATCH', body: { enabled: b.checked } }).then(() => toast(b.checked ? 'Задача включена' : 'Задача выключена')).catch(ex => { b.checked = !b.checked; errToast(ex); });
  };
}

/* ═════════ Интеграции ═════════ */
const HOOK_T = { discord: 'Discord', telegram: 'Telegram', generic: 'Вебхук (JSON)' };
async function integrationsView() {
  const a = vapi();
  const d = await a('/webhooks');
  setHTML(V(), html`${pageHead('Интеграции', 'Уведомления о репортах, банах и падениях сервера — в Discord, Telegram или на ваш адрес', html`<button class="btn primary" data-h="new">${ic('plus', 18)} Добавить</button>`)}
    ${d.items.length ? '' : html`<div class="note" style="margin-bottom:14px">Пока ничего не подключено. Добавьте Discord-вебхук или Telegram-бота — и репорты будут приходить вам сразу.</div>`}
    <div class="grid g2">${d.items.map(h => html`<div class="card">
      <div class="row wrap"><b class="grow">${h.name}</b><span class="badge ${h.enabled ? 'ok' : 'mut'}">${h.enabled ? 'включено' : 'выключено'}</span><span class="badge">${HOOK_T[h.type]}</span></div>
      <div class="chips" style="margin:10px 0">${h.events.length ? h.events.map(e => html`<span class="chip on" style="cursor:default">${d.events[e]}</span>`) : html`<span class="mut">События не выбраны</span>`}</div>
      <div class="mut" style="font-size:13px;margin-bottom:10px">${h.last_at ? html`Последняя отправка ${ago(h.last_at)}: ${h.last_status || ''}` : 'Ещё ничего не отправлялось'}</div>
      <div class="row wrap"><button class="btn sm" data-h="test" data-id="${h.id}">${ic('send', 15)} Тест</button><button class="btn sm" data-h="edit" data-id="${h.id}">${ic('edit', 15)}</button><button class="btn sm" data-h="toggle" data-id="${h.id}">${h.enabled ? 'Выключить' : 'Включить'}</button><button class="btn sm danger" data-h="del" data-id="${h.id}">${ic('trash', 15)}</button></div></div>`)}</div>`);
  const reload = () => integrationsView().catch(errToast);
  const typeFields = (type, h = {}) => type === 'telegram'
    ? html`<div class="field"><label>Токен бота</label><input class="input mono" name="token" placeholder="${h.token ? 'сохранён (' + h.token + ') — оставьте пустым, чтобы не менять' : '123456:ABC…'}" autocomplete="off"><div class="hint">Создайте бота у @BotFather и скопируйте токен.</div></div>
      <div class="field"><label>ID чата</label><input class="input mono" name="chat_id" value="${h.chat_id || ''}" placeholder="например -1001234567890"><div class="hint">Добавьте бота в чат/канал и узнайте ID, например через @userinfobot или @getidsbot.</div></div>`
    : html`<div class="field"><label>${type === 'discord' ? 'URL вебхука Discord' : 'URL, куда отправлять JSON (POST)'}</label><input class="input mono" name="url" value="${h.url || ''}" placeholder="https://…" required>${type === 'discord' ? html`<div class="hint">Настройки канала → Интеграции → Вебхуки → Копировать URL.</div>` : ''}</div>`;
  const hookModal = h => {
    const x = h || { name: '', type: 'discord', events: ['report', 'ban', 'server'] };
    formModal({
      title: h ? 'Интеграция: ' + h.name : 'Новая интеграция', wide: true,
      body: html`<div class="fgrid"><div class="field"><label>Название</label><input class="input" name="name" value="${x.name}" required maxlength="40"></div>
        <div class="field"><label>Тип</label><select class="select" name="type" ${h ? 'disabled' : ''}>${Object.entries(HOOK_T).map(([k, v]) => html`<option value="${k}" ${x.type === k ? 'selected' : ''}>${v}</option>`)}</select></div></div>
        <div id="h-f">${typeFields(x.type, x)}</div>
        <div class="field"><label>О чём сообщать</label><div style="display:grid;gap:8px">${Object.entries(d.events).map(([k, l]) => html`<label class="check"><input type="checkbox" name="ev" value="${k}" ${x.events.includes(k) ? 'checked' : ''}> ${l}</label>`)}</div></div>`,
      onMount: f => { f.type.onchange = () => { $('#h-f', f).innerHTML = rend(typeFields(f.type.value)); }; },
      onSubmit: async (dd, f, m) => {
        const type = h ? h.type : f.type.value;
        const body = { name: dd.name, type, events: $$('input[name=ev]:checked', f).map(i => i.value) };
        if (type === 'telegram') { if (dd.token) body.token = dd.token; body.chat_id = dd.chat_id; } else body.url = dd.url;
        if (h) await api('/webhooks/' + h.id, { method: 'PATCH', body }); else await api('/webhooks', { method: 'POST', body });
        m.close(); toast('Сохранено'); reload();
      },
    });
  };
  V().onclick = async e => {
    const b = e.target.closest('[data-h]'); if (!b) return;
    const h = d.items.find(x => x.id == b.dataset.id);
    if (b.dataset.h === 'new') hookModal(null);
    else if (b.dataset.h === 'edit') hookModal(h);
    else if (b.dataset.h === 'toggle') api('/webhooks/' + h.id, { method: 'PATCH', body: { enabled: !h.enabled } }).then(reload).catch(errToast);
    else if (b.dataset.h === 'test') { b.disabled = true; try { const r = await api(`/webhooks/${h.id}/test`, { method: 'POST', body: {} }); toast('Отправлено: ' + r.status); reload(); } catch (ex) { errToast(ex); b.disabled = false; } }
    else if (b.dataset.h === 'del') { if (await confirmBox('Удалить интеграцию', `«${h.name}» будет удалена.`, { ok: 'Удалить', danger: true })) api('/webhooks/' + h.id, { method: 'DELETE', body: {} }).then(() => { toast('Удалено'); reload(); }).catch(errToast); }
  };
}

/* ═════════ Система (владелец) ═════════ */
async function systemView() {
  const a = vapi();
  const d = await a('/system');
  const st = d.settings;
  setHTML(V(), html`${pageHead('Система', 'Хранение данных, резервные копии и адрес панели — настраивается один раз', html`<button class="btn primary" data-sy="backup">${ic('download', 18)} Создать копию сейчас</button>`)}
    <div class="grid g2">
      <div class="card"><h3>Состояние</h3><dl class="kv"><dt>Версия</dt><dd>${d.version}</dd><dt>Node.js</dt><dd>${d.node}</dd><dt>Работает</dt><dd>${fmtDur(d.uptime)}</dd><dt>База данных</dt><dd>${fmtBytes(d.db_size)}</dd></dl>
        <div class="mut" style="font-size:13px;margin-top:10px">Проверка живости для мониторинга: <span class="mono">${location.origin}/healthz</span></div></div>
      <form class="card" id="sy-form"><h3>Настройки</h3>
        <div class="field"><label>Хранить события, дней</label><input class="input" type="number" name="retention_days" min="1" max="3650" value="${st.retention_days}"><div class="hint">Старые записи логов удаляются сами — база не разрастается.</div></div>
        <div class="field"><label>Хранить резервных копий</label><input class="input" type="number" name="backup_keep" min="1" max="60" value="${st.backup_keep}"><div class="hint">Копия создаётся автоматически раз в сутки, лишние удаляются.</div></div>
        <div class="field"><label>Адрес панели</label><input class="input" name="public_url" value="${st.public_url}" placeholder="https://panel.example.com"><div class="hint">Нужен для готовой команды установки агента и ссылок в уведомлениях. Подставляется сам при вашем входе.</div></div>
        <button class="btn primary" type="submit">Сохранить</button></form>
    </div>
    <div class="mt" id="local-card"></div>
    <div class="mt" id="dc-card"></div>
    <div class="card flush mt"><div class="card-h"><h3>Резервные копии</h3></div>
      ${d.backups.length ? html`<div class="table-wrap"><table class="t"><thead><tr><th>Файл</th><th>Создана</th><th>Размер</th><th></th></tr></thead><tbody>${d.backups.map(b => html`<tr><td class="mono">${b.name}</td><td>${fmtFull(b.ts)}</td><td>${fmtBytes(b.size)}</td>
        <td class="nowrap" style="text-align:right"><a class="btn sm" href="/api/backups/${encodeURIComponent(b.name)}" download>${ic('download', 15)}</a> <button class="btn sm danger" data-sy="del" data-n="${b.name}">${ic('trash', 15)}</button></td></tr>`)}</tbody></table></div>` : html`<div class="empty small">Копий ещё нет — первая создастся автоматически в течение суток</div>`}
    </div>
    <div class="note mt">Восстановление: остановите панель, замените файл <span class="mono">data/panel.db</span> нужной копией и запустите панель снова.</div>`);
  discordSettingsCard($('#dc-card'), a).catch(e => { if (!e.stale) errToast(e); });
  localServerCard($('#local-card'), a).catch(e => { if (!e.stale) errToast(e); });
  const v = V();
  v.onsubmit = async e => {
    e.preventDefault();
    try { const f = e.target; await a('/system', { method: 'PUT', body: { retention_days: f.retention_days.value, backup_keep: f.backup_keep.value, public_url: f.public_url.value.trim() } }); toast('Сохранено'); } catch (ex) { errToast(ex); }
  };
  v.onclick = async e => {
    const b = e.target.closest('[data-sy]'); if (!b) return;
    try {
      if (b.dataset.sy === 'backup') { b.disabled = true; await a('/backups', { method: 'POST', body: {} }); toast('Копия создана'); systemView().catch(errToast); }
      else if (b.dataset.sy === 'del' && await confirmBox('Удалить копию', b.dataset.n, { ok: 'Удалить', danger: true })) { await a('/backups/' + encodeURIComponent(b.dataset.n), { method: 'DELETE', body: {} }); toast('Удалено'); systemView().catch(errToast); }
    } catch (ex) { errToast(ex); }
  };
}

/* ═════════ Мастер первого запуска ═════════ */
function onboardCard(ob) {
  if (!ob || ob.dismissed) return '';
  const done = ob.steps.filter(x => x.done).length;
  return html`<div class="card mb"><div class="row wrap"><h3 style="margin:0" class="grow">Быстрый старт · ${done} из ${ob.steps.length}</h3><button class="btn sm ghost" data-act="ob-dismiss">${done === ob.steps.length ? 'Готово, скрыть' : 'Скрыть'}</button></div>
    <div class="bar" style="margin:12px 0"><i style="width:${Math.round(done / ob.steps.length * 100)}%"></i></div>
    <div style="display:grid;gap:10px">${ob.steps.map(x => html`<div class="row" style="align-items:flex-start"><span class="${x.done ? 'ok' : 'mut'}" style="margin-top:1px">${ic(x.done ? 'check' : 'clock', 20)}</span>
      <div class="grow"><b style="${x.done ? 'text-decoration:line-through;opacity:.65' : ''}">${x.title}</b><div class="mut" style="font-size:13px">${x.desc}</div></div>
      ${x.done ? '' : (x.link === '#pw' ? html`<button class="btn sm" data-act="pw">${x.action}</button>` : html`<a class="btn sm" href="${x.link}">${x.action}</a>`)}</div>`)}</div></div>`;
}
Object.assign(ACT, {
  'ob-dismiss'() { api('/onboarding/dismiss', { method: 'POST', body: {} }).then(() => route()).catch(errToast); },
});

/* ═════════ Поиск игрока ═════════ */
function openSearch() {
  const m = modal({ title: 'Поиск игрока по всем серверам', body: html`<div class="search">${ic('search', 16)}<input class="input" id="gs-q" placeholder="Ник игрока (от 2 символов)" autocomplete="off"></div><div id="gs-res" style="margin-top:12px"><div class="empty small">Введите хотя бы 2 символа</div></div>`, footer: false });
  const inp = $('#gs-q', m.el); inp.focus();
  let seq = 0;
  const run = debounce(async () => {
    const t = inp.value.trim(), my = ++seq;
    if (t.length < 2) return setHTML($('#gs-res', m.el), html`<div class="empty small">Введите хотя бы 2 символа</div>`);
    try {
      const r = await api('/search' + qs({ q: t }));
      if (my !== seq) return;
      setHTML($('#gs-res', m.el), r.items.length ? r.items.map(p => html`<a class="pop-item" href="#/s/${p.server_id}/players/${encodeURIComponent(p.name)}" data-close>${head(p.name, 32)}<span class="grow"><div class="t">${p.name}</div><div class="s">${p.server} · ${p.online ? 'онлайн' : 'был ' + ago(p.last_seen)}</div></span>${p.banned ? html`<span class="badge bad">бан</span>` : ''}${p.online ? html`<span class="badge ok">онлайн</span>` : ''}</a>`) : html`<div class="empty small">Никого не найдено</div>`);
    } catch (e) { errToast(e); }
  }, 250);
  inp.oninput = run;
}
document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k' && S.me && can('players')) { e.preventDefault(); openSearch(); }
});
Object.assign(ACT, { search() { closePop(); openSearch(); }, help() { closePop(); openHelp(); } });

/* ═════════ Справка по каждому разделу ═════════ */
// perm — право, нужное для раздела; ref — показывать в списке разделов на странице «Информация»
const HELP = {
  dash: { title: 'Информация (сводка)', icon: 'db', ref: 1, link: '#/', short: 'Общая картина по всем доступным серверам.',
    what: 'Главная страница: сколько игроков онлайн, какие серверы в сети, открытые репорты, график онлайна за сутки и последние важные события.',
    how: ['Карточки сверху обновляются сами — перезагружать страницу не нужно.', 'Нажмите на сервер или репорт, чтобы перейти к подробностям.', 'Владельцу вверху показывается «Быстрый старт» — короткий чек-лист первичной настройки.'] },
  users: { title: 'Пользователи', icon: 'users', ref: 1, link: '#/users', perm: 'users.manage', short: 'Создание аккаунтов сотрудников, роли и доступ к серверам.',
    what: 'Только владелец создаёт аккаунты. У каждого сотрудника есть логин, пароль, роль и список серверов, к которым у него есть доступ.',
    how: ['«Создать аккаунт» — задайте логин, пароль (можно сгенерировать), роль и серверы. Пароль передайте сотруднику сразу: потом он не показывается.', 'Ник в Minecraft нужен для учёта минималок (часы, наказания, репорты).', 'Кнопка с ключом — новый пароль, со стрелкой — завершить сессии, корзина — удалить.', 'Отключённый аккаунт не может войти, но история его действий сохраняется.'] },
  roles: { title: 'Роли и доступ', icon: 'shieldc', ref: 1, link: '#/roles', perm: 'roles.manage', short: 'Какие разделы и действия доступны каждой роли.',
    what: 'Роль — набор прав. Если у роли нет права на раздел, он пропадает из меню и закрыт по прямой ссылке. Изменения действуют сразу, без перезахода.',
    how: ['«Настроить» — отметьте, что разрешено роли.', '«Копия» — создать похожую роль за пару кликов.', 'Роль нельзя удалить, пока она назначена сотрудникам.', 'Доступ к конкретным серверам задаётся отдельно — на странице «Пользователи».'] },
  audit: { title: 'Журнал действий панели', icon: 'book', ref: 1, link: '#/audit', perm: 'audit', short: 'Кто и что делал в самой панели.',
    what: 'Все входы, смены паролей, наказания, команды в консоли и изменения настроек с именем сотрудника, временем и IP. Записи нельзя изменить или удалить из интерфейса.',
    how: ['Фильтр по сотруднику и поиск по тексту помогают найти нужное действие.', 'Красным отмечены неудачные входы, баны, удаления.', '«Показать ещё» подгружает более старые записи.'] },
  info: { title: 'О панели', icon: 'info', link: '#/info', short: 'Версия, возможности и справка по разделам.',
    what: 'Состояние панели, подключение серверов, список всех разделов с описанием и таблица прав ролей.',
    how: ['Кнопка «?» в верхней панели открывает справку по текущему разделу.', 'Здесь же — готовая команда подключения агента.'] },
  integrations: { title: 'Интеграции', icon: 'plug', ref: 1, link: '#/integrations', perm: 'integrations', short: 'Уведомления в Discord, Telegram или на ваш URL.',
    what: 'Панель сама отправляет сообщения о новых репортах, банах, падении сервера и срабатываниях автомодерации — вам не нужно сидеть в панели.',
    how: ['Discord: создайте вебхук в настройках канала и вставьте URL.', 'Telegram: создайте бота у @BotFather, укажите токен и ID чата.', 'Вебхук (JSON): панель отправит POST с данными события на ваш адрес.', 'Кнопка «Тест» отправляет проверочное сообщение.'] },
  system: { title: 'Система', icon: 'hdd', ref: 1, link: '#/system', perm: 'system', short: 'Хранение логов, резервные копии, адрес панели.',
    what: 'Панель обслуживает себя сама: раз в сутки делает резервную копию базы и удаляет старые события. Здесь можно изменить сроки и скачать копию.',
    how: ['«Хранить события» — через сколько дней удалять старые логи.', '«Создать копию сейчас» — ручная резервная копия; скачайте её на всякий случай.', 'Адрес панели нужен для ссылок в уведомлениях и команды установки агента.'] },
  'new-server': { title: 'Новый сервер', icon: 'server', perm: 'servers.manage', short: 'Добавление сервера Minecraft.',
    what: 'Укажите название и адрес — панель создаст сервер, подготовит правила автомодерации и выдаст ключ для агента.',
    how: ['После создания появится команда в одну строку — выполните её на машине с сервером (Linux).', 'Ключ показывается один раз; потерянный можно перевыпустить в настройках сервера.', 'Для команд из панели нужен RCON (enable-rcon=true в server.properties) — агент передаёт их сам, порт открывать не нужно.'] },
  logs: { title: 'Логи сервера', icon: 'list', ref: 1, perm: 'logs', per: 'logs', short: 'Лента всех событий на сервере.',
    what: 'Входы и выходы, чат, команды, смерти, наказания, срабатывания автомодерации — в реальном времени.',
    how: ['Фильтры по типу события, игроку и тексту.', 'Ник игрока — ссылка на его профиль.', '«CSV» выгружает текущую выборку в файл.'] },
  status: { title: 'Статус серверов', icon: 'server', ref: 1, perm: 'status', per: 'status', short: 'Доступность, пинг, версия, онлайн.',
    what: 'Панель опрашивает сервер каждую минуту и рисует график онлайна и пинга. При падении сервера отправляется уведомление.',
    how: ['«Проверить сейчас» — внеочередной опрос.', '«Проверить RCON» — убедиться, что команды из панели дойдут до сервера.'] },
  console: { title: 'Консоль', icon: 'terminal', ref: 1, perm: 'console', per: 'console', short: 'Команды на сервер и вывод консоли.',
    what: 'Отправка команд так, как будто вы в консоли сервера. Каждая команда записывается в журнал действий.',
    how: ['Стрелки вверх/вниз листают историю команд.', 'Кнопки быстрых команд настраиваются в настройках сервера.', 'Выдавайте это право только доверенным ролям.'] },
  online: { title: 'Онлайн', icon: 'signal', ref: 1, perm: 'online', per: 'online', short: 'Кто сейчас в игре и статистика онлайна.',
    what: 'Список игроков онлайн с временем сессии, пик за период и число уникальных игроков.', how: ['Нажмите на игрока, чтобы открыть профиль и выдать наказание.'] },
  reports: { title: 'Репорты', icon: 'bug', ref: 1, perm: 'reports', per: 'reports', short: 'Жалобы игроков на нарушителей.',
    what: 'Игроки пишут в игре /report ник причина. Репорт появляется здесь и в уведомлениях.',
    how: ['Берите репорт в работу, оставляйте комментарии, закрывайте с итогом.', 'В репорте видны последние сообщения и история игрока.'] },
  quotas: { title: 'Минималки', icon: 'cash', ref: 1, feature: 'quotas', perm: 'quotas.view', per: 'quotas.view', short: 'Нормы активности персонала за неделю.',
    what: 'Панель считает часы в игре, наказания и обработанные репорты сотрудников по их нику и сравнивает с нормой роли.',
    how: ['Сотруднику нужно указать ник в Minecraft (страница «Пользователи»).', 'Нормы по ролям задаются внизу страницы.', 'Стрелками можно смотреть прошлые недели.', 'Ниже — минималки на предметы: сколько предметов сотрудник должен сдать за неделю. Сдачу записывает ответственный или считает плагин.'] },
  clients: { title: 'Клиент дата', icon: 'gear', ref: 1, perm: 'clients', per: 'clients', short: 'Клиенты и версии игроков.',
    what: 'Какие версии игры и клиенты использует игроки — полезно для выявления читерских клиентов.', how: ['Данные приходят от плагина/агента вместе с событием входа.'] },
  whitelist: { title: 'Вайтлист', icon: 'star', ref: 1, perm: 'whitelist.view', per: 'whitelist.view', short: 'Список допущенных игроков.',
    what: 'Панель хранит вайтлист и синхронизирует его с сервером.', how: ['Добавляйте ники списком через пробел или запятую.', '«С сервера»/«На сервер» — импорт и отправка списка.'] },
  players: { title: 'Список игроков', icon: 'users', ref: 1, perm: 'players', per: 'players', short: 'Все игроки сервера и их профили.',
    what: 'Поиск по нику, фильтры по статусу. Профиль игрока: история, наказания, заметки, IP и связанные аккаунты (если есть право).',
    how: ['Значок поиска вверху (или Ctrl+K) ищет игрока сразу по всем серверам.', 'Заметки видят только сотрудники.'] },
  profile: { title: 'Профиль игрока', icon: 'user', perm: 'players', per: 'players', short: 'История и наказания игрока.',
    what: 'Вся информация об игроке на сервере и кнопки наказаний.', how: ['Выбор вкладки: события, наказания, заметки, связанные аккаунты.', 'Каждое наказание записывается в журнал с именем сотрудника.'] },
  chat: { title: 'Чат', icon: 'msg', ref: 1, perm: 'chat', short: 'Чат сервера в реальном времени, как в игре.',
    what: 'Все сообщения игроков, входы, выходы и смерти с цветами и никами, как на сервере. Можно писать в общий чат от имени панели или личным сообщением игроку.',
    how: ['Ник игрока — ссылка на его профиль.', 'Сообщения панели видны игрокам как «[Панель] Ваше имя: текст».', 'Фильтры сверху скрывают входы/выходы и время.', 'Писать могут только роли с правом «Чат: писать».'] },
  control: { title: 'Управление сервером', icon: 'sliders', ref: 1, perm: 'control', short: 'Запуск, объявления, время, погода, игроки.',
    what: 'Кнопки вместо консольных команд: сохранить мир, объявить всем, сменить время и погоду, режим игры, телепорт, выдать предмет, запустить/остановить/перезапустить сервер.',
    how: ['Опасные действия просят подтверждение и доступны только ролям с правом «Управление: опасное».', 'Запуск и перезапуск выполняет агент по команде startCommand из своего конфига.', 'Каждое действие записывается в журнал панели.'] },
  automod: { title: 'Автомодерация', icon: 'zap', ref: 1, perm: 'automod', per: 'automod', short: 'Правила, реагирующие на чат и команды сами.',
    what: 'Панель читает события сервера и применяет правила: запрещённые слова, реклама, капс, флуд, обход бана, опасные команды. Реакция — от простого уведомления до мута/бана.',
    how: ['По умолчанию включены правила, которые только уведомляют — ничего не наказывается без вашего решения.', '«Проверить текст» показывает, что бы сработало, без последствий.', 'Сотрудники с ником в панели правилами не наказываются.'] },
  scheduler: { title: 'Планировщик', icon: 'calendar', ref: 1, perm: 'scheduler', per: 'scheduler', short: 'Команды и объявления по расписанию.',
    what: 'Автосохранение, объявления в чат, предупреждения о рестарте — панель выполняет команды сама через агента или RCON.',
    how: ['Выберите шаблон или задайте своё расписание.', '«Выполнить сейчас» — проверка без ожидания.', 'В таблице видно результат последнего запуска.'] },
  settings: { title: 'Настройки сервера', icon: 'sliders', perm: 'servers.manage', short: 'Адрес, RCON, шаблоны команд, ключ агента.',
    what: 'Параметры подключения и шаблоны команд наказаний под ваш плагин (EssentialsX, LiteBans и т. д.).',
    how: ['«Перевыпустить ключ» — выдаст новую команду установки агента; старый ключ перестанет работать.', 'Шаблоны используют переменные {player}, {reason}, {duration}.'] },
};
function helpKey(path) {
  const p = path || '';
  if (p === '') return 'dash';
  let m;
  if ((m = /^s\/\d+\/players\/[^/]+$/.exec(p))) return 'profile';
  if ((m = /^s\/\d+\/(\w+)$/.exec(p))) return HELP[m[1]] ? m[1] : 'dash';
  return HELP[p] ? p : 'dash';
}
function accessLine(h) {
  if (!h.perm) return html`<span class="mut">Доступно всем сотрудникам.</span>`;
  if (['users.manage', 'roles.manage', 'system'].includes(h.perm)) return html`<span class="badge purple">Только владелец</span>`;
  const rs = rolesWith(h.perm).filter(r => r.key !== 'owner');
  return html`<span class="badge purple">Владелец</span> ${rs.map(r => html`${roleBadge(r.key)} `)}<div class="mut" style="font-size:12.5px;margin-top:4px">Право «${permLabel(h.perm)}». Роли настраиваются на странице «Роли и доступ».</div>`;
}
function openHelp() {
  const h = HELP[helpKey(S.path)];
  modal({ title: 'Справка · ' + h.title, wide: true, footer: html`<a class="btn" href="#/info" data-close>Все разделы</a><button class="btn primary" data-close>Понятно</button>`,
    body: html`<div class="field"><label>Что это</label><div>${h.what}</div></div>
      <div class="field"><label>Как пользоваться</label><ul style="margin:0;padding-left:20px;line-height:1.7">${h.how.map(x => html`<li>${x}</li>`)}</ul></div>
      <div class="field"><label>Кому доступно</label><div>${accessLine(h)}</div></div>` });
}
