'use strict';
/* ───────── Чат, управление сервером, предметы, Discord ───────── */

/* ═════════ Чат ═════════ */
const mcLine = (e, showTime) => {
  const t = showTime ? html`<span class="c-dim">${fmtTime(e.ts).slice(-8)} </span>` : '';
  const nm = e.player ? html`<a class="c-name" href="#/s/${S.curServer}/players/${encodeURIComponent(e.player)}">${e.player}</a>` : '';
  if (e.type === 'chat') {
    if (e.panel) {
      if ((e.message || '').startsWith('→')) return html`<div class="mc-l">${t}<span class="c-lp">[ЛС от </span><span class="c-gold">${e.player}</span><span class="c-lp">] </span>${e.message}</div>`;
      return html`<div class="mc-l">${t}<span class="c-aqua">[Панель] </span><span class="c-gold">${e.player}</span><span class="c-gray">: </span><span class="c-w">${e.message}</span></div>`;
    }
    return html`<div class="mc-l">${t}<span class="c-w">&lt;</span>${nm}<span class="c-w">&gt; ${e.message}</span></div>`;
  }
  if (e.type === 'join') return html`<div class="mc-l">${t}<span class="c-yel">${nm} joined the game</span></div>`;
  if (e.type === 'leave') return html`<div class="mc-l">${t}<span class="c-yel">${nm} left the game</span></div>`;
  if (e.type === 'death') return html`<div class="mc-l">${t}<span class="c-gray">${e.message || e.player + ' died'}</span></div>`;
  if (e.type === 'advancement') return html`<div class="mc-l">${t}<span class="c-grn">${nm} ${e.message || 'has made an advancement'}</span></div>`;
  return html`<div class="mc-l">${t}<span class="c-gray">${e.player || ''} ${e.message || ''}</span></div>`;
};

async function chatView(s) {
  const a = vapi();
  S.curServer = s.id;
  const d = await a(`/servers/${s.id}/chat`);
  let last = d.items.length ? d.items[d.items.length - 1].id : 0, online = d.online;
  let showSys = store.get('chat_sys', true), showTime = store.get('chat_time', true), all = d.items.slice(-300);
  const canSend = can('chat.send');
  const targets = () => html`<option value="">Всем игрокам</option>${online.map(n => html`<option value="${n}">ЛС → ${n}</option>`)}`;
  const lines = () => rend(html`${all.filter(e => showSys || e.type === 'chat').map(e => mcLine(e, showTime))}`) || rend(html`<div class="mc-l c-dim">Сообщений пока нет</div>`);
  setHTML(V(), html`${sPage(s, 'Чат', 'как на сервере, в реальном времени', html`<span class="live"><i class="dot on"></i>Прямой эфир</span>`)}
    <div class="card flush"><div class="chat-opts row wrap"><label class="check"><input type="checkbox" id="c-sys" ${showSys ? 'checked' : ''}> Входы, выходы, смерти</label><label class="check"><input type="checkbox" id="c-time" ${showTime ? 'checked' : ''}> Время</label><span class="grow"></span><span class="mut" id="c-cnt" style="font-size:13px"></span></div>
      <div class="mcchat" id="feed" tabindex="0"></div>
      ${canSend ? html`<form class="chat-send" id="c-form"><select class="select" id="c-to">${targets()}</select><input class="input grow" id="c-text" maxlength="240" placeholder="Сообщение в чат сервера…" autocomplete="off" ${d.can_command ? '' : 'disabled'}><button class="btn primary" type="submit" ${d.can_command ? '' : 'disabled'}>${ic('send', 16)} Отправить</button></form>
        ${d.can_command ? '' : html`<div class="note warn" style="margin:0 12px 12px">Нет связи с сервером для команд — отправка недоступна.</div>`}` : ''}</div>
    <div class="card mt"><h3>Сейчас в игре (${online.length})</h3><div class="chips" id="c-online">${online.length ? online.map(n => html`<a class="chip" href="#/s/${s.id}/players/${encodeURIComponent(n)}">${head(n, 18)} ${n}</a>`) : html`<span class="mut">Никого нет</span>`}</div></div>`);
  const feed = $('#feed'), cnt = $('#c-cnt');
  const paint = (stick = true) => { const near = feed.scrollHeight - feed.scrollTop - feed.clientHeight < 80; feed.innerHTML = lines(); cnt.textContent = all.length + ' сообщ.'; if (stick || near) feed.scrollTop = feed.scrollHeight; };
  paint();
  let pulling = false, again = false;
  const pull = async () => {
    if (pulling) { again = true; return; }
    pulling = true;
    try { await pull1(); } finally { pulling = false; if (again) { again = false; pull().catch(() => {}); } }
  };
  const pull1 = async () => {
    const r = await a(`/servers/${s.id}/chat` + qs({ after: last }));
    r.items = r.items.filter(x => x.id > last);
    if (r.items.length) { last = r.items[r.items.length - 1].id; all = all.concat(r.items).slice(-400); const near = feed.scrollHeight - feed.scrollTop - feed.clientHeight < 80; paint(near); }
    if (r.online.join() !== online.join()) {
      online = r.online;
      const sel = $('#c-to'); if (sel) { const v = sel.value; sel.innerHTML = rend(targets()); sel.value = online.includes(v) ? v : ''; }
      setHTML($('#c-online'), online.length ? online.map(n => html`<a class="chip" href="#/s/${s.id}/players/${encodeURIComponent(n)}">${head(n, 18)} ${n}</a>`) : html`<span class="mut">Никого нет</span>`);
    }
  };
  live(m => { if ((m.t === 'events' || m.t === 'online') && m.server === s.id) pull().catch(() => {}); });
  every(() => { if (a.alive()) pull().catch(() => {}); }, 15000);
  V().onchange = e => {
    if (e.target.id === 'c-sys') { showSys = e.target.checked; store.set('chat_sys', showSys); paint(); }
    if (e.target.id === 'c-time') { showTime = e.target.checked; store.set('chat_time', showTime); paint(false); }
  };
  V().onsubmit = async e => {
    e.preventDefault();
    if (e.target.id !== 'c-form') return;
    const inp = $('#c-text'), text = inp.value.trim(); if (!text) return;
    const btn = $('button', e.target); btn.disabled = true;
    try { await api(`/servers/${s.id}/chat`, { method: 'POST', body: { text, to: $('#c-to').value || undefined } }); inp.value = ''; await pull(); }
    catch (ex) { errToast(ex); }
    btn.disabled = false; inp.focus();
  };
}

/* ═════════ Управление сервером ═════════ */
async function controlView(s) {
  const a = vapi();
  const d = await a(`/servers/${s.id}/control`);
  const sv = d.server, adm = d.admin;
  const btn = (act, label, extra = '', cls = '') => html`<button class="btn sm ${cls}" data-ctl="${act}" ${raw(extra)}>${label}</button>`;
  const players = html`<datalist id="pl-list">${d.online.map(n => html`<option value="${n}">`)}</datalist>`;
  setHTML(V(), html`${sPage(s, 'Управление', 'сервер, мир и игроки без входа в консоль')}
    ${sv.can_command ? '' : html`<div class="note warn mb">Нет связи с сервером для команд: подключите агента с RCON или настройте RCON в настройках сервера. Запуск и перезапуск работают только через агента.</div>`}
    <div class="grid g2">
      <div class="card"><h3>Состояние сервера</h3>
        <div class="row wrap" style="margin-bottom:12px"><span class="badge ${sv.online ? 'ok' : 'bad'}">${sv.online ? 'В сети' : 'Не отвечает'}</span><span class="mut">${sv.online ? `${sv.players_online}/${sv.players_max} игроков · ${sv.version || ''}` : 'сервер выключен или недоступен'}</span></div>
        ${adm ? html`<div class="row wrap">${btn('start', html`${ic('play', 15)} Запустить`)}${btn('restart', html`${ic('refresh', 15)} Перезапустить`, '', 'warn')}${btn('stop', html`${ic('x', 15)} Остановить`, '', 'danger')}</div>
          <div class="hint" style="margin-top:10px">Запуск и перезапуск выполняет агент по команде <span class="mono">startCommand</span> из его конфига (установщик подбирает её сам: start.sh или единственный .jar).</div>` : html`<div class="mut">Запуск и остановка доступны администраторам.</div>`}
        <div class="row wrap" style="margin-top:12px">${btn('save', html`${ic('download', 15)} Сохранить мир`)}${btn('whitelist_reload', 'Перечитать вайтлист')}${btn('list', 'Кто онлайн')}<a class="btn sm" href="#/s/${s.id}/console">${ic('terminal', 15)} Консоль</a></div></div>
      <form class="card" data-ctl="say"><h3>Объявление</h3>
        <div class="field"><textarea class="input" name="text" rows="2" maxlength="200" placeholder="Текст для всех игроков" required></textarea></div>
        <div class="row wrap"><button class="btn primary sm" type="submit" data-as="say">В чат</button><button class="btn sm" type="submit" data-as="title">На экран (титр)</button></div></form>
      <div class="card"><h3>Мир</h3>
        <div class="field"><label>Время</label><div class="row wrap">${[['day', 'День'], ['noon', 'Полдень'], ['night', 'Ночь'], ['midnight', 'Полночь']].map(([v, l]) => btn('time', l, `data-value="${v}"`))}</div></div>
        <div class="field"><label>Погода</label><div class="row wrap">${[['clear', 'Ясно'], ['rain', 'Дождь'], ['thunder', 'Гроза']].map(([v, l]) => btn('weather', l, `data-value="${v}"`))}</div></div>
        ${adm ? html`<div class="field"><label>Сложность</label><div class="row wrap">${[['peaceful', 'Мирная'], ['easy', 'Лёгкая'], ['normal', 'Нормальная'], ['hard', 'Сложная']].map(([v, l]) => btn('difficulty', l, `data-value="${v}"`))}</div></div>` : ''}</div>
      <div class="card"><h3>Игрок</h3>${players}
        <div class="field"><label>Ник</label><input class="input" id="ctl-player" list="pl-list" placeholder="Ник игрока" maxlength="16" autocomplete="off"><div class="hint">Онлайн: ${d.online.length ? d.online.join(', ') : 'никого'}. Наказания — в профиле игрока.</div></div>
        <div class="field"><label>Режим игры</label><div class="row wrap">${[['survival', 'Выживание'], ['creative', 'Творческий'], ['adventure', 'Приключение'], ['spectator', 'Наблюдатель']].map(([v, l]) => btn('gamemode', l, `data-value="${v}" data-needs="player"`))}</div></div>
        <div class="row wrap" style="margin-bottom:12px">${btn('heal', 'Вылечить', 'data-needs="player"')}${adm ? html`${btn('op', 'Выдать OP', 'data-needs="player"')}${btn('deop', 'Снять OP', 'data-needs="player"')}` : ''}<button class="btn sm" data-prof>Профиль</button></div>
        <form class="row wrap" data-ctl="tp"><input class="input grow" name="target" placeholder="Телепортировать к игроку…" maxlength="16" list="pl-list" required><button class="btn sm" type="submit">${ic('send', 15)} Телепорт</button></form>
        ${adm ? html`<form class="row wrap" data-ctl="give" style="margin-top:10px"><input class="input grow" name="item" placeholder="предмет, например diamond" maxlength="60" required><input class="input" style="width:90px" type="number" name="amount" min="1" max="2304" value="1"><button class="btn sm" type="submit">Выдать</button></form>` : ''}</div>
    </div>`);
  const DANGER = { stop: 'Сервер будет остановлен. Все игроки отключатся.', restart: 'Сервер будет остановлен и запущен снова. Игроки отключатся.', op: 'Игрок получит права оператора.', difficulty: 'Изменить сложность мира?' };
  const run = async (action, body, el) => {
    if (DANGER[action] && !(await confirmBox('Подтвердите действие', DANGER[action], { ok: 'Выполнить', danger: action !== 'difficulty' }))) return;
    if (el) el.disabled = true;
    try { const r = await api(`/servers/${s.id}/control`, { method: 'POST', body: { action, ...body } }); toast(`${r.label}: ${r.response && ['list', 'save', 'start', 'restart', 'stop', 'whitelist_reload'].includes(action) ? String(r.response).slice(0, 160) : 'выполнено'}`); }
    catch (ex) { errToast(ex); }
    if (el) el.disabled = false;
  };
  const pl = () => $('#ctl-player').value.trim();
  const v = V();
  v.onclick = e => {
    if (e.target.closest('[data-prof]')) { const n = pl(); return n ? (location.hash = `#/s/${s.id}/players/${encodeURIComponent(n)}`) : toast('Введите ник'); }
    const b = e.target.closest('button[data-ctl]'); if (!b) return;
    const body = { value: b.dataset.value };
    if (b.dataset.needs === 'player') { body.player = pl(); if (!body.player) return toast('Введите ник игрока'); }
    run(b.dataset.ctl, body, b);
  };
  v.onsubmit = e => {
    e.preventDefault();
    const f = e.target; if (!f.dataset.ctl) return;
    const fd = Object.fromEntries(new FormData(f));
    let action = f.dataset.ctl;
    if (action === 'say') action = (e.submitter && e.submitter.dataset.as) || 'say';
    if (action === 'tp' || action === 'give') { fd.player = pl(); if (!fd.player) return toast('Введите ник игрока'); }
    run(action, fd, e.submitter).then(() => { if (action === 'say' || action === 'title') f.reset(); });
  };
}

/* ═════════ Минималки на предметы (блок на странице «Минималки») ═════════ */
const itemName = id => id.replace(/_/g, ' ');
async function itemsSection(s, weekStart, box, a) {
  const d = await a(`/servers/${s.id}/items` + qs({ week: weekStart + 36e5 * 12 }));
  const roles = S.roleList.filter(r => r.key !== 'owner');
  let norms = d.norms.map(n => ({ ...n }));
  const canEdit = can('quotas'), canLog = can('items');
  const withNick = d.staff.filter(u => u.mc_nick);
  const draw = () => setHTML(box, html`<div class="card flush mt"><div class="card-h"><h3>Минималки на предметы</h3><span class="mut" style="font-size:13px">сколько предметов сотрудник должен сдать за неделю</span></div>
    ${norms.length ? html`<div class="table-wrap"><table class="t"><thead><tr><th>Сотрудник</th><th>Роль</th><th>Предметы за неделю</th><th>Итог</th></tr></thead><tbody>
      ${d.staff.filter(u => u.items.length).map(u => html`<tr><td><div class="row">${head(u.mc_nick, 28)}<div><b>${u.name}</b><div class="mut" style="font-size:12.5px">${u.mc_nick}</div></div></div></td><td>${roleBadge(u.role)}</td>
        <td style="min-width:260px">${u.items.map(i => html`<div style="margin-bottom:6px"><div class="mut" style="font-size:12.5px">${itemName(i.item)}</div>${progress(i.have, i.need)}</div>`)}</td>
        <td>${u.done ? html`<span class="badge ok">Выполнено</span>` : html`<span class="badge bad">Не выполнено</span>`}</td></tr>`)}
      ${d.staff.some(u => u.items.length) ? '' : html`<tr><td colspan="4" class="empty">Нет сотрудников с ником в Minecraft и нормой по предметам</td></tr>`}
    </tbody></table></div>` : html`<div class="empty small">Норм по предметам пока нет${canEdit ? ' — добавьте ниже' : ''}</div>`}</div>
    ${canLog ? html`<div class="card mt"><h3>Записать сдачу предмета</h3><p class="mut" style="margin:0 0 10px;font-size:13.5px">Предметы также считаются автоматически, если плагин присылает события <span class="mono">item</span> (см. «Информация»).</p>
      <form class="row wrap" id="it-add"><select class="select" name="user_id" required><option value="">Сотрудник…</option>${withNick.map(u => html`<option value="${u.id}">${u.name} (${u.mc_nick})</option>`)}</select>
      <input class="input" name="item" placeholder="предмет, например diamond" maxlength="60" required style="min-width:200px"><input class="input" type="number" name="amount" min="1" placeholder="Кол-во" required style="width:110px"><button class="btn primary" type="submit">${ic('plus', 16)} Записать</button></form></div>` : ''}
    ${canEdit ? html`<div class="card mt"><h3>Нормы по предметам на неделю</h3><div class="table-wrap"><table class="t"><thead><tr><th>Роль</th><th>Предмет</th><th>Количество</th><th></th></tr></thead><tbody>
      ${norms.map((n, i) => html`<tr><td>${roleBadge(n.role)}</td><td class="mono">${n.item}</td><td>${n.amount}</td><td style="text-align:right"><button class="btn sm danger" data-it-del="${i}">${ic('trash', 14)}</button></td></tr>`)}
      <tr><td><select class="select" id="nn-role">${roles.map(r => html`<option value="${r.key}">${r.label}</option>`)}</select></td><td><input class="input" id="nn-item" placeholder="diamond" maxlength="60"></td><td><input class="input" id="nn-amount" type="number" min="1" placeholder="64" style="max-width:120px"></td><td style="text-align:right"><button class="btn sm" data-it-add>${ic('plus', 14)} Добавить</button></td></tr>
      </tbody></table></div><div class="row mt-s"><button class="btn primary" data-it-save>Сохранить нормы</button><span class="mut" style="font-size:13px">Нормы действуют на все недели. Название — как в игре (diamond, oak_log, iron_ingot).</span></div></div>` : ''}
    ${canLog && d.log.length ? html`<div class="card flush mt"><div class="card-h"><h3>Записи за неделю</h3></div><div class="table-wrap"><table class="t"><thead><tr><th>Когда</th><th>Игрок</th><th>Предмет</th><th>Кол-во</th><th>Источник</th><th></th></tr></thead><tbody>
      ${d.log.map(l => html`<tr><td>${fmtTime(l.ts)}</td><td>${l.player}</td><td class="mono">${l.item}</td><td>${l.amount}</td><td>${l.source === 'plugin' ? html`<span class="badge cyan">плагин</span>` : html`<span class="badge">вручную${l.by_user ? ': ' + l.by_user : ''}</span>`}</td><td style="text-align:right"><button class="btn sm danger" data-it-rm="${l.id}">${ic('trash', 14)}</button></td></tr>`)}</tbody></table></div></div>` : ''}`);
  draw();
  const reload = () => itemsSection(s, weekStart, box, a).catch(errToast);
  box.onclick = async e => {
    const t = e.target.closest('button'); if (!t) return;
    e.stopPropagation();
    if ('itAdd' in t.dataset) {
      const item = $('#nn-item').value.trim(), amount = Number($('#nn-amount').value);
      if (!item || !(amount >= 1)) return toast('Укажите предмет и количество');
      const role = $('#nn-role').value, it = item.toLowerCase().replace(/^minecraft:/, '').replace(/\s+/g, '_');
      norms = norms.filter(n => !(n.role === role && n.item === it)); norms.push({ role, item: it, amount }); draw();
    } else if (t.dataset.itDel !== undefined) { norms.splice(Number(t.dataset.itDel), 1); draw(); }
    else if ('itSave' in t.dataset) { try { await api(`/servers/${s.id}/items/norms`, { method: 'PUT', body: { norms } }); toast('Нормы сохранены'); reload(); } catch (ex) { errToast(ex); } }
    else if (t.dataset.itRm) { if (await confirmBox('Удалить запись', 'Запись о сдаче предмета будет удалена.', { ok: 'Удалить', danger: true })) api(`/servers/${s.id}/items/log/${t.dataset.itRm}`, { method: 'DELETE', body: {} }).then(() => { toast('Удалено'); reload(); }).catch(errToast); }
  };
  box.onsubmit = async e => {
    e.stopPropagation(); e.preventDefault();
    if (e.target.id !== 'it-add') return;
    const f = e.target;
    try { await api(`/servers/${s.id}/items/log`, { method: 'POST', body: { user_id: f.user_id.value, item: f.item.value, amount: f.amount.value } }); toast('Записано'); reload(); } catch (ex) { errToast(ex); }
  };
}

/* ═════════ Discord: настройки (Система), привязка, вход ═════════ */
async function discordSettingsCard(box, a) {
  const d = await a('/discord/settings');
  setHTML(box, html`<form class="card" id="dc-form"><div class="row wrap"><h3 style="margin:0" class="grow">Вход через Discord</h3><span class="badge ${d.enabled ? 'ok' : 'mut'}">${d.enabled ? 'включён' : 'выключен'}</span></div>
    <p class="mut" style="font-size:13.5px;margin:8px 0 14px">Сотрудники входят одной кнопкой. Доступ выдаётся и отбирается <b>ролями на вашем Discord-сервере</b>: дали роль — человек может войти (аккаунт создастся сам), убрали роль или удалили с сервера — доступ закрывается.</p>
    <details ${d.enabled ? '' : 'open'} style="margin-bottom:12px"><summary class="mut" style="cursor:pointer">Как настроить (5 минут)</summary><ol style="line-height:1.7;margin:10px 0 0;padding-left:20px;font-size:13.5px">
      <li>Откройте <span class="mono">discord.com/developers/applications</span> → New Application.</li>
      <li>OAuth2 → Redirects → добавьте адрес ниже. Скопируйте Client ID и Client Secret сюда.</li>
      <li>Включите в Discord режим разработчика (Настройки → Расширенные), ПКМ по вашему серверу → «Копировать ID сервера».</li>
      <li><b>Чтобы доступ закрывался сразу</b> после удаления человека (а не при следующем входе): в приложении Bot → Reset Token → вставьте токен бота и добавьте бота на ваш сервер (права не нужны).</li>
      <li>На странице «Роли и доступ» привяжите роли панели к ролям Discord.</li></ol></details>
    <div class="field"><label>Адрес для Redirects</label><div class="row"><input class="input mono" readonly value="${d.redirect_uri}"><button class="btn" type="button" data-copy="${d.redirect_uri}">${ic('copy', 16)}</button></div>${d.redirect_uri.startsWith('http://') && !/localhost|127\.0\.0\.1/.test(d.redirect_uri) ? html`<div class="hint warn">Адрес без HTTPS — Discord такой не примет. Настройте HTTPS и «Адрес панели».</div>` : ''}</div>
    <div class="fgrid"><div class="field"><label>Application (Client) ID</label><input class="input mono" name="client_id" value="${d.client_id}" inputmode="numeric"></div>
    <div class="field"><label>Client Secret</label><input class="input mono" name="client_secret" type="password" autocomplete="new-password" placeholder="${d.has_secret ? 'сохранён (' + d.secret_hint + ')' : ''}"></div></div>
    <div class="fgrid"><div class="field"><label>ID Discord-сервера</label><input class="input mono" name="guild_id" value="${d.guild_id}" inputmode="numeric"><div class="hint">Пусто — вход только для аккаунтов, уже привязанных вручную.</div></div>
    <div class="field"><label>Токен бота (необязательно)</label><input class="input mono" name="bot_token" type="password" autocomplete="new-password" placeholder="${d.has_bot ? 'сохранён (' + d.bot_hint + ')' : ''}"><div class="hint">Нужен для мгновенного отзыва доступа и выбора ролей списком.</div></div></div>
    <label class="check" style="margin-bottom:14px;align-items:flex-start"><input type="checkbox" name="auto_admin" ${d.auto_admin ? 'checked' : ''} style="margin-top:2px"><span><b>Роли Discord с правом «Администратор» появляются в панели сами</b><div class="mut" style="font-size:12.5px;font-weight:400">Для каждой такой роли создаётся роль панели с полным доступом (кроме управления ролями, пользователями и системой), её участники могут входить. С токеном бота роли подтягиваются по названию и цвету; без токена администратор Discord-сервера получает встроенную роль «Администратор».</div></span></label>
    <div class="row wrap"><button class="btn primary" type="submit">Сохранить</button>${d.has_bot ? html`<button class="btn" type="button" data-dc="roles">${ic('shieldc', 16)} Синхронизировать роли</button><button class="btn" type="button" data-dc="sync">${ic('refresh', 16)} Проверить всех сейчас</button><button class="btn ghost" type="button" data-dc="nobot">Убрать токен бота</button>` : ''}${d.has_secret ? html`<button class="btn ghost" type="button" data-dc="off">Выключить вход</button>` : ''}</div></form>`);
  box.onsubmit = async e => {
    e.preventDefault(); e.stopPropagation();
    const f = e.target;
    try { await a('/discord/settings', { method: 'PUT', body: { client_id: f.client_id.value.trim(), guild_id: f.guild_id.value.trim(), client_secret: f.client_secret.value, bot_token: f.bot_token.value, auto_admin: f.auto_admin.checked } }); toast('Сохранено'); discordSettingsCard(box, a).catch(errToast); } catch (ex) { errToast(ex); }
  };
  box.onclick = async e => {
    const b = e.target.closest('[data-dc]'); if (!b) return;
    e.stopPropagation();
    try {
      if (b.dataset.dc === 'sync') { b.disabled = true; const r = await a('/discord/sync', { method: 'POST', body: {} }); toast(`Проверено ${r.checked}: закрыт доступ ${r.removed}, роль изменена ${r.updated}, восстановлен ${r.restored}`); b.disabled = false; }
      else if (b.dataset.dc === 'roles') { b.disabled = true; const r = await a('/discord/import-roles', { method: 'POST', body: {} }); await loadMe(); renderSidebar(); toast(`Роли синхронизированы: добавлено ${r.created}, обновлено ${r.updated}, удалено ${r.removed}`); b.disabled = false; }
      else if (b.dataset.dc === 'nobot') { await a('/discord/settings', { method: 'PUT', body: { clear_bot: true } }); discordSettingsCard(box, a).catch(errToast); }
      else if (b.dataset.dc === 'off' && await confirmBox('Выключить вход через Discord', 'Кнопка входа исчезнет. Привязки сохранятся.', { ok: 'Выключить', danger: true })) { await a('/discord/settings', { method: 'PUT', body: { clear_secret: true } }); discordSettingsCard(box, a).catch(errToast); }
    } catch (ex) { errToast(ex); b.disabled = false; }
  };
}
// Сервер Minecraft на этом же ПК: панель сама подключается к нему (встроенный агент)
async function localServerCard(box, a) {
  const d = await a('/local');
  const owner = S.me && S.me.role === 'owner';
  setHTML(box, html`<form class="card" id="lc-form"><div class="row wrap"><h3 style="margin:0" class="grow">Сервер Minecraft на этом ПК</h3><span class="badge ${d.on && d.agent_running ? 'ok' : d.on ? 'warn' : 'mut'}">${d.on ? (d.agent_running ? 'подключён' : 'запускается') : 'не найден'}</span></div>
    <p class="mut" style="font-size:13.5px;margin:8px 0 14px">Если панель запущена на том же компьютере, что и сервер Minecraft, она подключается к нему сама: логи, чат, консоль, команды, запуск и перезапуск — без отдельной установки агента.</p>
    ${d.rcon_changed ? html`<div class="note warn" style="margin-bottom:12px">RCON включён в <span class="mono">server.properties</span>. <b>Перезапустите сервер Minecraft один раз</b>, чтобы команды из панели заработали.</div>` : ''}
    ${d.error && !d.on ? html`<div class="note" style="margin-bottom:12px">${d.error}. Укажите папку, где лежит <span class="mono">server.properties</span> (сервер должен быть запущен хотя бы один раз).</div>` : ''}
    <div class="field"><label>Папка сервера Minecraft</label><input class="input mono" name="dir" value="${d.dir || ''}" placeholder="${navigator.platform.startsWith('Win') ? 'C:\\Minecraft\\server' : '/home/user/minecraft'}" ${owner ? '' : 'readonly'}><div class="hint">Находится сама, если панель лежит в папке сервера или рядом с ней.</div></div>
    <div class="field"><label>Команда запуска сервера</label><input class="input mono" name="start_cmd" value="${d.start_cmd || ''}" placeholder="java -Xmx2G -jar server.jar nogui" ${owner ? '' : 'readonly'}><div class="hint">Для кнопок «Запустить» и «Перезапустить». Определяется сама по start.bat / start.sh или .jar в папке.</div></div>
    ${d.lan && d.lan.length ? html`<div class="field"><label>Адрес в локальной сети</label>${d.lan.map(u => html`<div class="row" style="margin-bottom:6px"><input class="input mono" readonly value="${u}"><button class="btn" type="button" data-copy="${u}">${ic('copy', 16)}</button></div>`)}<div class="hint">Приложение для Android находит панель в той же Wi-Fi сети само. Адрес нужен только для браузера на другом устройстве.</div></div>` : ''}
    ${owner ? html`<div class="row wrap"><button class="btn primary" type="submit">Сохранить</button>${d.on ? html`<button class="btn ghost" type="button" data-lc="off">Отключить</button>` : ''}</div>` : html`<div class="hint">Изменять может только владелец.</div>`}</form>`);
  box.onsubmit = async e => {
    e.preventDefault(); e.stopPropagation();
    const f = e.target;
    const body = { start_cmd: f.start_cmd.value.trim() };
    if (f.dir.value.trim() !== (d.dir || '')) body.dir = f.dir.value.trim();
    try { await a('/local', { method: 'PUT', body }); toast('Сохранено'); setTimeout(() => localServerCard(box, a).catch(errToast), 1500); } catch (ex) { errToast(ex); }
  };
  box.onclick = async e => {
    const b = e.target.closest('[data-lc]'); if (!b) return;
    e.stopPropagation();
    if (await confirmBox('Отключить сервер на этом ПК', 'Встроенный агент остановится. Сервер Minecraft продолжит работать. Включить обратно — указать папку и сохранить.', { ok: 'Отключить', danger: true })) {
      try { await a('/local/off', { method: 'POST', body: {} }); localServerCard(box, a).catch(errToast); } catch (ex) { errToast(ex); }
    }
  };
}
async function discordGo(path) {
  try { const r = await api(path, { method: 'POST', body: {} }); location.href = r.url; } catch (e) { errToast(e); }
}
Object.assign(ACT, {
  'dc-login'() { discordGo('/discord/start'); },
  'dc-link'() { closePop(); discordGo('/discord/link'); },
  async 'dc-unlink'() { closePop(); if (await confirmBox('Отвязать Discord', 'Вход через Discord для вашего аккаунта перестанет работать.', { ok: 'Отвязать', danger: true })) api('/discord/unlink', { method: 'POST', body: {} }).then(() => { toast('Discord отвязан'); return loadMe().then(() => route()); }).catch(errToast); },
});

// Лояльное копирование (data-copy) работает глобально; если нет — добавим
if (!ACT.__copy) document.addEventListener('click', e => {
  const b = e.target.closest('[data-copy]'); if (!b) return;
  navigator.clipboard.writeText(b.dataset.copy).then(() => toast('Скопировано'), () => toast('Не удалось скопировать'));
});
