'use strict';
/* ───────── Состояние и оболочка приложения ───────── */
const S = {
  features: {},
  me: null, perms: new Set(), roles: {}, roleList: [], catalog: [], rolePerms: {}, servers: [], online: 0, unread: 0,
  open: new Set(store.get('open', [])), onLive: null, cleanups: [], rt: 0, path: '', es: null,
};
const can = p => S.perms.has('*') || S.perms.has(p);
const srv = id => S.servers.find(s => s.id == id);
const V = () => $('#view');
const every = (fn, ms) => { const t = setInterval(fn, ms); S.cleanups.push(() => clearInterval(t)); };
const live = fn => { S.onLive = fn; };
class Stale extends Error { constructor() { super('stale'); this.stale = true; } }
// api, который молча отбрасывает результат, если пользователь уже ушёл на другую страницу
function vapi() {
  const T = S.rt;
  const f = async (path, opts) => { const r = await api(path, opts); if (T !== S.rt) throw new Stale(); return r; };
  f.alive = () => T === S.rt;
  return f;
}
function pageHead(title, sub, actions) {
  return html`<div class="page-head"><div class="grow"><h1>${title}</h1>${sub ? html`<div class="sub">${sub}</div>` : ''}</div>${actions ? html`<div class="row wrap">${actions}</div>` : ''}</div>`;
}
const denied = () => html`<div class="card empty">${ic('lock', 28)}<p>Недостаточно прав для этой страницы</p></div>`;

function applyTheme(t) {
  document.documentElement.dataset.theme = t;
  store.set('theme', t);
  const m = $('meta[name=theme-color]'); if (m) m.content = t === 'light' ? '#f1f4fb' : '#0e1228';
}
applyTheme(store.get('theme', 'dark'));

/* ───────── Вход ───────── */
function showLogin(msg) {
  cleanupView(); closeSSE();
  setHTML($('#root'), html`<div class="login-wrap"><form class="login-card" id="login-form" autocomplete="on">
    <div class="brand-logo">${ic('diamond', 28)}</div><h1>MC Panel</h1><p class="s">Управление персоналом и игроками серверов</p>
    <div class="field"><label for="l-login">Логин</label><input class="input" id="l-login" name="login" autocomplete="username" autocapitalize="off" required></div>
    <div class="field"><label for="l-pass">Пароль</label><input class="input" id="l-pass" name="password" type="password" autocomplete="current-password" required></div>
    <div class="form-err" id="l-err" role="alert">${msg || ''}</div>
    <button class="btn primary" style="width:100%;margin-top:10px" type="submit">Войти</button>
    <div id="dc-box"></div>
    <p class="mut" style="font-size:12.5px;text-align:center;margin:16px 0 0">Аккаунты выдаёт только владелец панели</p>
  </form></div>`);
  const f = $('#login-form'); $('#l-login').focus();
  fetch('/api/discord/status').then(r => r.json()).then(d => {
    if (d.enabled && $('#dc-box')) setHTML($('#dc-box'), html`<div class="or-line"><span>или</span></div><button class="btn dc-btn" type="button" data-act="dc-login">${ic('users', 18)} Войти через Discord</button>`);
  }).catch(() => {});
  f.addEventListener('submit', async e => {
    e.preventDefault();
    const btn = $('button', f); btn.disabled = true; $('#l-err').textContent = '';
    try { await api('/login', { method: 'POST', body: { login: f.login.value.trim(), password: f.password.value } }); await boot(); }
    catch (ex) { $('#l-err').textContent = ex.message; btn.disabled = false; f.password.select(); }
  });
}
onUnauthorized = () => showLogin('Сессия завершена — войдите снова');

/* ───────── Загрузка профиля ───────── */
async function loadMe() {
  const d = await api('/me');
  S.features = d.features || {}; S.hasApk = !!d.has_apk; S.me = d.user; S.perms = new Set(d.perms); S.roles = d.roles; S.roleList = d.role_list; S.catalog = d.perm_catalog; S.rolePerms = d.role_perms;
  S.servers = d.servers; S.online = d.online_total; S.unread = d.unread;
}
let meBusy = false;
const refreshMe = debounce(async () => {
  if (meBusy || !S.me) return;
  meBusy = true;
  try { await loadMe(); updateTop(); updateSidebarDots(); } catch {} finally { meBusy = false; }
}, 800);

/* ───────── Оболочка ───────── */
function renderShell() {
  const collapsed = store.get('collapsed', false);
  setHTML($('#root'), html`<div class="app ${collapsed ? 'collapsed' : ''}" id="app">
    <aside class="sidebar" id="sidebar"></aside><div class="overlay" data-act="close-nav"></div>
    <div class="main"><header class="topbar" id="topbar"></header><main class="content" id="view"></main></div></div>
    <div class="pop hidden" id="pop"></div>`);
  renderSidebar(); renderTop();
}

function sicon(s, size = 36) {
  return html`<span class="sicon" style="width:${size}px;height:${size}px;background:${s.color}">${s.icon ? raw(`<img src="${esc(s.icon)}" alt="" style="width:${size}px;height:${size}px">`) : (s.name || '?').charAt(0).toUpperCase()}<i class="sdot ${s.online ? 'on' : ''}" data-sd="${s.id}"></i></span>`;
}
const SUBS = [
  ['logs', 'list', 'Логи', 'logs'], ['status', 'server', 'Статус серверов', 'status'], ['console', 'terminal', 'Консоль', 'console'],
  ['online', 'signal', 'Онлайн', 'online'], ['reports', 'bug', 'Репорты', 'reports'], ['quotas', 'cash', 'Минималки', 'quotas.view'],
  ['clients', 'gear', 'Клиент дата', 'clients'], ['whitelist', 'star', 'Вайтлист', 'whitelist.view'],
  ['players', 'users', 'Список игроков', 'players'], ['chat', 'msg', 'Чат', 'chat'], ['control', 'sliders', 'Управление', 'control'], ['automod', 'zap', 'Автомодерация', 'automod'], ['scheduler', 'calendar', 'Планировщик', 'scheduler'],
  ['settings', 'sliders', 'Настройки', 'servers.manage'],
];
const navItem = (href, icon, label, active, tip) => html`<a class="nav-item ${active ? 'active' : ''}" href="${href}" ${tip ? raw(`title="${esc(tip)}"`) : ''}>${ic(icon, 22)}<span>${label}</span></a>`;

function renderSidebar() {
  const p = S.path || '';
  const curSrv = (/^s\/(\d+)/.exec(p) || [])[1];
  if (curSrv) S.open.add(Number(curSrv));
  setHTML($('#sidebar'), html`
    <button class="back-btn" data-act="back">${ic('back', 20)} Вернуться назад</button>
    <div class="nav-label">Разное</div>
    ${navItem('#/', 'db', 'Информация', p === '')}
    ${can('users.manage') ? navItem('#/users', 'users', 'Пользователи', p === 'users', HELP.users.short) : ''}
    ${can('roles.manage') ? navItem('#/roles', 'shieldc', 'Роли и доступ', p === 'roles', HELP.roles.short) : ''}
    <div class="nav-label"><span>Сервера</span>${can('servers.manage') ? html`<a class="icon-btn" href="#/new-server" title="Добавить сервер" aria-label="Добавить сервер">${ic('plus', 16)}</a>` : ''}</div>
    ${S.servers.length ? S.servers.map(s => html`<div class="srv-group ${S.open.has(s.id) ? 'open' : ''}">
      <button class="nav-item srv-head" data-act="toggle-srv" data-id="${s.id}">${sicon(s)}<span>${s.name}</span>${ic('chev', 16, 'chev')}</button>
      <div class="srv-sub">${SUBS.filter(x => (x[0] !== 'quotas' || S.features.quotas) && (!x[3] || can(x[3]))).map(([k, i, l]) => navItem(`#/s/${s.id}/${k}`, i, l, p === `s/${s.id}/${k}` || (k === 'players' && p.startsWith(`s/${s.id}/players/`)), (HELP[k] || {}).short))}</div>
    </div>`) : html`<div class="mut" style="padding:8px 12px;font-size:14px">Серверов пока нет${can('servers.manage') ? html` — <a href="#/new-server">добавить</a>` : ''}</div>`}
    <div class="nav-label">Разное</div>
    ${can('audit') ? navItem('#/audit', 'book', 'Логи', p === 'audit', HELP.audit.short) : ''}
    ${can('integrations') ? navItem('#/integrations', 'plug', 'Интеграции', p === 'integrations', HELP.integrations.short) : ''}
    ${can('system') ? navItem('#/system', 'hdd', 'Система', p === 'system', HELP.system.short) : ''}
    ${navItem('#/info', 'info', 'Информация', p === 'info', HELP.info.short)}`);
}
function updateSidebarDots() {
  for (const s of S.servers) { const d = $(`[data-sd="${s.id}"]`); if (d) d.classList.toggle('on', !!s.online); }
}

function avatarHTML(size = 46) {
  const u = S.me;
  if (u.mc_nick) return head(u.mc_nick, size);
  return html`<span class="ph" style="width:${size}px;height:${size}px;border-radius:50%;background:${colorOf(u.login)};font-size:${size * 0.4}px">${(u.display_name || u.login).charAt(0).toUpperCase()}</span>`;
}
function onlineText() { return `${S.online} ${plural(S.online, ['человек', 'человека', 'человек'])} онлайн`; }
function renderTop() {
  setHTML($('#topbar'), html`
    <button class="icon-btn" data-act="toggle-nav" aria-label="Меню">${ic('menu', 26)}</button>
    <div class="brand"><div class="brand-logo">${ic('diamond', 22)}</div><div class="brand-txt" id="online-txt">${onlineText()}</div></div>
    <div class="grow"></div>
    ${can('players') ? html`<button class="icon-btn" data-act="search" aria-label="Поиск игрока" title="Поиск игрока (Ctrl+K)">${ic('search', 22)}</button>` : ''}
    <button class="icon-btn" data-act="help" aria-label="Справка" title="Справка по этому разделу">${ic('help', 24)}</button>
    <button class="icon-btn round accent" data-act="toggle-theme" aria-label="Сменить тему" id="theme-btn">${ic(document.documentElement.dataset.theme === 'light' ? 'sun' : 'moon', 22)}</button>
    <button class="icon-btn" data-act="pop" data-pop="bell" aria-label="Уведомления">${ic('bell', 24)}${S.unread ? html`<span class="badge-dot">${S.unread > 99 ? '99+' : S.unread}</span>` : ''}</button>
    <button class="icon-btn" data-act="pop" data-pop="apps" aria-label="Быстрый переход">${ic('grid', 24)}</button>
    <button class="avatar-btn" data-act="pop" data-pop="user" aria-label="Профиль">${avatarHTML()}</button>`);
}
function updateTop() {
  const t = $('#online-txt'); if (t) t.textContent = onlineText();
  const bell = $('[data-pop=bell]');
  if (bell) { const b = $('.badge-dot', bell); if (b) b.remove(); if (S.unread) bell.insertAdjacentHTML('beforeend', `<span class="badge-dot">${S.unread > 99 ? '99+' : S.unread}</span>`); }
}

/* ───────── Всплывающие меню ───────── */
function closePop() { const p = $('#pop'); if (p) { p.classList.add('hidden'); p.dataset.kind = ''; } }
const NOTIF_IC = { report: 'bug', server: 'server', punish: 'ban', system: 'info' };
async function openPop(kind) {
  const pop = $('#pop');
  if (!pop.classList.contains('hidden') && pop.dataset.kind === kind) return closePop();
  pop.dataset.kind = kind; pop.classList.remove('hidden');
  if (kind === 'apps') {
    setHTML(pop, html`<h4>Быстрый переход</h4><div class="apps">
      <a class="app-tile" href="#/">${html`<span class="tile-ic">${ic('db')}</span>`}Информация</a>
      ${can('users.manage') ? html`<a class="app-tile" href="#/users"><span class="tile-ic">${ic('users')}</span>Пользователи</a>` : ''}
      ${can('roles.manage') ? html`<a class="app-tile" href="#/roles"><span class="tile-ic">${ic('shieldc')}</span>Роли</a>` : ''}
      ${can('audit') ? html`<a class="app-tile" href="#/audit"><span class="tile-ic">${ic('book')}</span>Журнал</a>` : ''}
      ${can('integrations') ? html`<a class="app-tile" href="#/integrations"><span class="tile-ic">${ic('plug')}</span>Интеграции</a>` : ''}
      ${can('system') ? html`<a class="app-tile" href="#/system"><span class="tile-ic">${ic('hdd')}</span>Система</a>` : ''}
      <a class="app-tile" href="#/info"><span class="tile-ic">${ic('info')}</span>О панели</a>
      ${S.servers.map(s => html`<a class="app-tile" href="#/s/${s.id}/logs">${sicon(s, 40)}${s.name}</a>`)}
    </div>`);
  } else if (kind === 'user') {
    const u = S.me;
    setHTML(pop, html`<div class="row" style="padding:10px">${avatarHTML(48)}<div><b>${u.display_name || u.login}</b><div class="mut" style="font-size:13px">${u.login} · ${u.role_label}</div></div></div>
      <button class="pop-item" data-act="skins"><span>${ic('user')}</span><span class="t">Скины игроков: ${store.get('skins', false) ? 'включены' : 'выключены'}</span></button>
      ${u.discord_name ? html`<button class="pop-item" data-act="dc-unlink"><span>${ic('users')}</span><span class="t">Discord: ${u.discord_name} · отвязать</span></button>` : html`<button class="pop-item" data-act="dc-link"><span>${ic('users')}</span><span class="t">Привязать Discord</span></button>`}
      ${window.__pwa && !window.MCPanelApp ? html`<button class="pop-item" data-act="pwa"><span>${ic('download')}</span><span class="t">Установить приложение</span></button>` : ''}
      ${S.hasApk && !window.MCPanelApp ? html`<a class="pop-item" href="/app.apk" download><span>${ic('download')}</span><span class="t">Скачать для Android (APK)</span></a>` : ''}
      ${window.MCPanelApp && (!window.MCPanelApp.canChangeServer || window.MCPanelApp.canChangeServer()) ? html`<button class="pop-item" data-act="app-server"><span>${ic('server')}</span><span class="t">Сменить адрес панели</span></button>` : ''}
      <button class="pop-item" data-act="pw"><span>${ic('key')}</span><span class="t">Сменить пароль</span></button>
      <button class="pop-item" data-act="logout"><span>${ic('logout')}</span><span class="t">Выйти</span></button>`);
  } else if (kind === 'bell') {
    setHTML(pop, html`<h4>Уведомления</h4><div class="empty small">Загрузка…</div>`);
    try {
      const d = await api('/notifications');
      if (pop.dataset.kind !== 'bell') return;
      setHTML(pop, html`<h4>Уведомления</h4>${d.items.length ? d.items.map(n => html`<a class="pop-item ${n.unread ? 'unread' : ''}" href="${n.link || '#/'}">
        <span class="${n.kind === 'server' || n.kind === 'punish' ? 'bad' : 'warn'}">${ic(NOTIF_IC[n.kind] || 'bell')}</span>
        <span><div class="t">${n.title}</div>${n.body ? html`<div class="s">${n.body}</div>` : ''}<div class="s">${ago(n.ts)}</div></span></a>`) : html`<div class="empty small">Уведомлений пока нет</div>`}`);
      if (d.unread) { api('/notifications/read', { method: 'POST', body: {} }).catch(() => {}); S.unread = 0; updateTop(); }
    } catch (e) { errToast(e); }
  }
}
function changePassword() {
  formModal({
    title: 'Смена пароля',
    body: html`<div class="field"><label>Текущий пароль</label><input class="input" type="password" name="old_password" autocomplete="current-password" required></div>
      <div class="field"><label>Новый пароль</label><input class="input" type="password" name="new_password" autocomplete="new-password" required><div class="hint">От 8 до 128 символов. Остальные ваши сессии будут завершены.</div></div>`,
    onSubmit: async (d, f, m) => { await api('/me/password', { method: 'POST', body: d }); m.close(); toast('Пароль изменён'); },
  });
}

/* ───────── Глобальные клики ───────── */
const ACT = {
  'toggle-nav'() {
    const app = $('#app');
    if (innerWidth <= 960) app.classList.toggle('nav-open');
    else { app.classList.toggle('collapsed'); store.set('collapsed', app.classList.contains('collapsed')); }
  },
  'close-nav'() { $('#app').classList.remove('nav-open'); },
  back() { history.length > 1 ? history.back() : (location.hash = '#/'); },
  'toggle-theme'() { applyTheme(document.documentElement.dataset.theme === 'light' ? 'dark' : 'light'); renderTop(); },
  'toggle-srv'(el) {
    const id = Number(el.dataset.id);
    S.open.has(id) ? S.open.delete(id) : S.open.add(id);
    store.set('open', [...S.open]);
    el.closest('.srv-group').classList.toggle('open', S.open.has(id));
  },
  pop(el) { openPop(el.dataset.pop); },
  pw() { closePop(); changePassword(); },
  async pwa() { closePop(); const p = window.__pwa; if (!p) return; p.prompt(); await p.userChoice.catch(() => {}); window.__pwa = null; },
  'app-server'() { closePop(); if (window.MCPanelApp) window.MCPanelApp.changeServer(); },
  skins() { store.set('skins', !store.get('skins', false)); closePop(); toast(store.get('skins', false) ? 'Показываем настоящие скины (загрузка с mc-heads.net)' : 'Используются встроенные аватары'); renderTop(); route(); },
  reload() { location.reload(); },
  async logout() { try { await api('/logout', { method: 'POST', body: {} }); } catch {} S.me = null; showLogin(); },
};
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (el && ACT[el.dataset.act]) { e.preventDefault(); ACT[el.dataset.act](el, e); return; }
  if (!e.target.closest('#pop') && !e.target.closest('[data-pop]')) closePop();
  if (e.target.closest('.sidebar a.nav-item') && innerWidth <= 960) $('#app').classList.remove('nav-open');
  if (e.target.closest('#pop a')) closePop();
  const hr = e.target.closest('[data-href]');
  if (hr && !e.target.closest('a,button')) location.hash = hr.dataset.href;
  const cp = e.target.closest('[data-copy]');
  if (cp) copyText(cp.dataset.copy);
});

/* ───────── Реалтайм ───────── */
function connectSSE() {
  closeSSE();
  const es = new EventSource('/api/stream');
  S.es = es;
  es.onmessage = ev => {
    let m; try { m = JSON.parse(ev.data); } catch { return; }
    if (m.t === 'roles') { loadMe().then(() => { renderSidebar(); renderTop(); route(); }).catch(() => {}); return; }
    if (m.t === 'online' || m.t === 'status' || m.t === 'notif' || m.t === 'punish') refreshMe();
    if (S.onLive) { try { S.onLive(m); } catch (e) { console.error(e); } }
  };
}
function closeSSE() { if (S.es) { S.es.close(); S.es = null; } }

/* ───────── Роутер ───────── */
function cleanupView() {
  S.cleanups.forEach(f => { try { f(); } catch {} });
  S.cleanups = []; S.onLive = null;
  const v = V();
  if (v) { v.onclick = v.onchange = v.oninput = v.onsubmit = v.onkeydown = null; }
}
const SERVER_PAGES = {
  logs: [logsView, 'logs'], status: [statusView, 'status'], console: [consoleView, 'console'], online: [onlineView, 'online'], reports: [reportsView, 'reports'],
  quotas: [s => S.features.quotas ? quotasView(s) : setHTML(V(), denied()), 'quotas.view'], clients: [clientsView, 'clients'], whitelist: [whitelistView, 'whitelist.view'], players: [playersView, 'players'],
  chat: [s => chatView(s), 'chat'], control: [s => controlView(s), 'control'], automod: [s => automodView(s), 'automod'], scheduler: [s => schedulerView(s), 'scheduler'], settings: [settingsView, 'servers.manage'],
};
const TITLES = { '': 'Информация', users: 'Пользователи', audit: 'Журнал действий', info: 'О панели', 'new-server': 'Новый сервер' };

async function route() {
  if (!S.me) return;
  cleanupView();
  const T = ++S.rt;
  const path = location.hash.replace(/^#\/?/, '');
  S.path = path;
  $('#app').classList.remove('nav-open');
  renderSidebar();
  scrollTo(0, 0);
  const v = V();
  setHTML(v, html`<div class="empty">Загрузка…</div>`);
  try {
    let m;
    if (path === '') { document.title = 'Информация · MC Panel'; await dashView(); }
    else if (path === 'users') { if (!can('users.manage')) return setHTML(v, denied()); document.title = 'Пользователи · MC Panel'; await usersView(); }
    else if (path === 'roles') { if (!can('roles.manage')) return setHTML(v, denied()); document.title = 'Роли · MC Panel'; await rolesView(); }
    else if (path === 'integrations') { if (!can('integrations')) return setHTML(v, denied()); document.title = 'Интеграции · MC Panel'; await integrationsView(); }
    else if (path === 'system') { if (!can('system')) return setHTML(v, denied()); document.title = 'Система · MC Panel'; await systemView(); }
    else if (path === 'audit') { if (!can('audit')) return setHTML(v, denied()); document.title = 'Журнал · MC Panel'; await auditView(); }
    else if (path === 'info') { document.title = 'О панели · MC Panel'; await infoView(); }
    else if (path === 'new-server') { if (!can('servers.manage')) return setHTML(v, denied()); document.title = 'Новый сервер · MC Panel'; await serverFormView(null); }
    else if ((m = /^s\/(\d+)$/.exec(path))) { location.replace(`#/s/${m[1]}/logs`); }
    else if ((m = /^s\/(\d+)\/players\/([^/]+)$/.exec(path))) {
      if (!can('players')) return setHTML(v, denied());
      const s = srv(m[1]); if (!s) return setHTML(v, html`<div class="card empty">Сервер не найден</div>`);
      document.title = `${decodeURIComponent(m[2])} · ${s.name}`;
      await profileView(s, decodeURIComponent(m[2]));
    } else if ((m = /^s\/(\d+)\/(\w+)$/.exec(path)) && SERVER_PAGES[m[2]]) {
      const s = srv(m[1]); if (!s) return setHTML(v, html`<div class="card empty">Сервер не найден или нет доступа</div>`);
      const [fn, perm] = SERVER_PAGES[m[2]];
      if (perm && !can(perm)) return setHTML(v, denied());
      document.title = `${(SUBS.find(x => x[0] === m[2]) || [])[2] || ''} · ${s.name}`;
      await fn(s);
    } else setHTML(v, html`<div class="card empty">Страница не найдена</div>`);
  } catch (e) {
    if (e.stale || T !== S.rt) return;
    setHTML(v, html`<div class="card empty">${ic('alert', 28)}<p>${e.message}</p><button class="btn" data-act="reload">Обновить</button></div>`);
  }
}
addEventListener('hashchange', route);

/* ───────── Информация (дашборд) ───────── */
const evSrvRow = e => html`<div class="ev"><div class="ev-t">${fmtTime(e.ts)}</div><div class="ev-b">${evBadge(e.type)}<span class="badge mut">${e.server}</span>${e.player ? html`<a class="pl" href="#/s/${e.server_id}/players/${encodeURIComponent(e.player)}">${e.player}</a>` : ''}<span class="ev-m">${e.message || ''}</span></div></div>`;

async function dashView() {
  const a = vapi();
  const d = await a('/overview');
  const ob = can('system') ? await a('/onboarding').catch(e => { if (e.stale) throw e; return null; }) : null;
  const t = d.totals;
  const stat = (icon, val, label, color) => html`<div class="card stat"><div class="si" ${color ? raw(`style="background:${color}22;color:${color}"`) : ''}>${ic(icon, 22)}</div><div><div class="sv">${val}</div><div class="sl">${label}</div></div></div>`;
  setHTML(V(), html`
    ${pageHead('Информация', `Сводка по ${d.servers.length} ${plural(d.servers.length, ['серверу', 'серверам', 'серверам'])}`)}
    ${onboardCard(ob)}
    <div class="grid g-stats">
      ${stat('signal', t.online, 'игроков онлайн', 'var(--ok)')}
      ${stat('server', `${t.servers_up}/${t.servers_total}`, 'серверов в сети')}
      ${stat('bug', t.open_reports, 'открытых репортов', 'var(--warn)')}
      ${stat('ban', t.punishments_24h, 'наказаний за 24 ч', 'var(--bad)')}
      ${stat('list', t.events_24h, 'событий за 24 ч', 'var(--cyan)')}
      ${stat('user', t.new_players_24h, 'новых игроков за 24 ч', 'var(--purple)')}
    </div>
    <div class="grid g-main mt">
      <div class="card"><h3>Онлайн за 24 часа</h3>${lineChart(d.chart, { key: 'online' })}</div>
      <div class="card flush"><div class="card-h"><h3>Открытые репорты</h3></div>
        ${d.reports.length ? d.reports.map(r => html`<a class="pop-item" href="#/s/${r.server_id}/reports" style="border-radius:0"><span class="warn">${ic('bug')}</span><span><div class="t">#${r.id} · ${r.reporter || 'Игрок'}${r.target ? ' → ' + r.target : ''}</div><div class="s">${r.reason}</div><div class="s">${r.server} · ${ago(r.created_at)}</div></span></a>`) : html`<div class="empty small">Открытых репортов нет</div>`}
      </div>
    </div>
    <div class="grid g2 mt">
      <div class="card flush"><div class="card-h"><h3>Серверы</h3></div>
        ${d.servers.length ? d.servers.map(s => html`<a class="pop-item" href="#/s/${s.id}/status" style="border-radius:0;align-items:center">${sicon(s, 40)}<span class="grow"><div class="t">${s.name}</div><div class="s">${s.online ? `${s.version || 'в сети'}${s.latency != null ? ' · ' + s.latency + ' мс' : ''}` : 'недоступен'}</div></span><span class="badge ${s.online ? 'ok' : 'bad'}">${s.online ? `${s.players_online}${s.players_max ? '/' + s.players_max : ''}` : 'офлайн'}</span></a>`) : html`<div class="empty small">Серверов нет${can('servers.manage') ? html` — <a href="#/new-server">добавить первый</a>` : ''}</div>`}
      </div>
      <div class="card flush"><div class="card-h"><h3>Последние важные события</h3></div>
        ${d.recent.length ? d.recent.map(evSrvRow) : html`<div class="empty small">Событий пока нет</div>`}
      </div>
    </div>`);
  live(m => { if (['online', 'status', 'reports', 'events'].includes(m.t)) dashRefresh(); });
  const dashRefresh = debounce(() => { if (a.alive() && S.path === '') dashView().catch(() => {}); }, 2500);
}

/* ───────── Пользователи (только владелец) ───────── */
async function usersView() {
  const a = vapi();
  const d = await a('/users');
  const users = d.items;
  const srvName = u => u.servers === '*' ? 'Все' : (u.servers ? u.servers.split(',').map(id => (srv(id) || {}).name || '#' + id).join(', ') : 'Нет');
  setHTML(V(), html`
    ${pageHead('Пользователи', 'Сотрудники, у которых есть доступ к панели. Аккаунты создаёт только владелец.', html`<button class="btn primary" data-u="new">${ic('plus', 18)} Создать аккаунт</button>`)}
    <div class="card flush"><div class="table-wrap"><table class="t"><thead><tr><th>Сотрудник</th><th>Роль</th><th>Ник в игре</th><th>Серверы</th><th>Последний вход</th><th></th></tr></thead><tbody>
    ${users.map(u => html`<tr><td><div class="row">${u.mc_nick ? head(u.mc_nick, 32) : html`<span class="ph" style="width:32px;height:32px;background:${colorOf(u.login)}">${u.login.charAt(0).toUpperCase()}</span>`}<div><b>${u.display_name || u.login}</b> ${u.online ? html`<span class="dot on" title="онлайн в панели"></span>` : ''}${u.disabled ? html` <span class="badge bad">${u.discord_off ? 'нет роли в Discord' : 'отключён'}</span>` : ''}${u.discord_name ? html` <span class="badge" style="background:#5865f226;color:#8b95ff" title="Привязанный Discord">${u.discord_name}</span>` : ''}<div class="mut" style="font-size:12.5px">${u.login}</div></div></div></td>
      <td>${roleBadge(u.role)}</td><td>${u.mc_nick || html`<span class="mut">—</span>`}</td>
      <td style="max-width:220px">${srvName(u)}</td><td class="nowrap">${u.last_login ? ago(u.last_login) : html`<span class="mut">не входил</span>`}</td>
      <td class="nowrap" style="text-align:right">
        <button class="btn sm" data-u="edit" data-id="${u.id}" title="Изменить">${ic('edit', 15)}</button>
        <button class="btn sm" data-u="pass" data-id="${u.id}" title="Новый пароль">${ic('key', 15)}</button>
        ${u.sessions ? html`<button class="btn sm" data-u="kill" data-id="${u.id}" title="Завершить сессии (${u.sessions})">${ic('logout', 15)}</button>` : ''}
        ${u.role !== 'owner' ? html`<button class="btn sm danger" data-u="del" data-id="${u.id}" title="Удалить">${ic('trash', 15)}</button>` : ''}</td></tr>`)}
    </tbody></table></div></div>`);
  const reload = () => usersView().catch(errToast);
  const srvBoxes = u => html`<div class="field"><label>Доступ к серверам</label>
    <label class="check"><input type="radio" name="scope" value="all" ${!u || u.servers === '*' ? 'checked' : ''}> Ко всем серверам</label>
    <label class="check" style="margin-top:6px"><input type="radio" name="scope" value="sel" ${u && u.servers !== '*' ? 'checked' : ''}> Только к выбранным</label>
    <div style="margin:8px 0 0 26px;display:grid;gap:6px">${S.servers.map(s => html`<label class="check"><input type="checkbox" name="srv" value="${s.id}" ${u && u.servers !== '*' && u.servers.split(',').includes(String(s.id)) ? 'checked' : ''}> ${s.name}</label>`)}${S.servers.length ? '' : html`<span class="mut">Серверов пока нет</span>`}</div></div>`;
  const readServers = f => f.scope.value === 'all' ? '*' : $$('input[name=srv]:checked', f).map(i => Number(i.value));
  const roleSel = cur => html`<div class="field"><label>Роль</label><select class="select" name="role">${S.roleList.filter(r => r.key !== 'owner').map(r => html`<option value="${r.key}" ${cur === r.key ? 'selected' : ''}>${r.label}</option>`)}</select>
    <div class="hint">Права ролей настраиваются на странице <a href="#/roles" data-close>«Роли и доступ»</a>.</div></div>`;
  V().onclick = async e => {
    const b = e.target.closest('[data-u]'); if (!b) return;
    const u = users.find(x => x.id == b.dataset.id);
    const act = b.dataset.u;
    if (act === 'new') {
      formModal({
        title: 'Новый аккаунт', submit: 'Создать',
        body: html`<div class="fgrid"><div class="field"><label>Логин</label><input class="input" name="login" required autocapitalize="off"></div>
          <div class="field"><label>Имя (для отображения)</label><input class="input" name="display_name"></div></div>
          <div class="field"><label>Пароль</label><div class="row"><input class="input mono" name="password" id="np" required value="${genPass()}"><button class="btn" type="button" id="gp">${ic('refresh', 16)}</button></div><div class="hint">Пароль потом не показывается — передайте его сотруднику сразу после создания.</div></div>
          <div class="fgrid"><div class="field"><label>Ник в Minecraft</label><input class="input" name="mc_nick" placeholder="для учёта минималок"></div><div></div></div>
          ${roleSel('moderator')}${srvBoxes(null)}`,
        onMount: f => $('#gp', f).onclick = () => { $('#np', f).value = genPass(); },
        onSubmit: async (dd, f, m) => {
          await api('/users', { method: 'POST', body: { login: dd.login.trim(), display_name: dd.display_name, password: dd.password, mc_nick: dd.mc_nick, role: dd.role, servers: readServers(f) } });
          m.close(); reload();
          modal({ title: 'Аккаунт создан', body: html`<p>Передайте данные для входа сотруднику:</p><pre class="code">Адрес:  ${location.origin}\nЛогин:  ${dd.login}\nПароль: ${dd.password}</pre>`, footer: html`<button class="btn" data-copy="${`Адрес: ${location.origin}\nЛогин: ${dd.login}\nПароль: ${dd.password}`}">${ic('copy', 16)} Копировать</button><button class="btn primary" data-close>Готово</button>` });
        },
      });
    } else if (act === 'edit') {
      formModal({
        title: 'Изменить: ' + u.login,
        body: html`<div class="fgrid"><div class="field"><label>Имя</label><input class="input" name="display_name" value="${u.display_name || ''}"></div>
          <div class="field"><label>Ник в Minecraft</label><input class="input" name="mc_nick" value="${u.mc_nick || ''}"></div></div>
          ${u.role === 'owner' ? '' : html`${roleSel(u.role)}${srvBoxes(u)}<label class="check"><input type="checkbox" name="disabled" ${u.disabled ? 'checked' : ''}> Аккаунт отключён (вход запрещён)</label>`}`,
        onSubmit: async (dd, f, m) => {
          const body = { display_name: dd.display_name, mc_nick: dd.mc_nick };
          if (u.role !== 'owner') { body.role = dd.role; body.servers = readServers(f); body.disabled = !!f.disabled.checked; }
          await api('/users/' + u.id, { method: 'PATCH', body }); m.close(); toast('Сохранено'); reload();
        },
      });
    } else if (act === 'pass') {
      formModal({
        title: 'Новый пароль: ' + u.login, submit: 'Установить',
        body: html`<div class="field"><label>Пароль</label><div class="row"><input class="input mono" name="password" id="np" value="${genPass()}"><button class="btn" type="button" id="gp">${ic('refresh', 16)}</button></div><div class="hint">Все активные сессии пользователя будут завершены.</div></div>`,
        onMount: f => $('#gp', f).onclick = () => { $('#np', f).value = genPass(); },
        onSubmit: async (dd, f, m) => {
          await api(`/users/${u.id}/password`, { method: 'POST', body: { password: dd.password } }); m.close(); reload();
          modal({ title: 'Пароль изменён', body: html`<p>Новый пароль для <b>${u.login}</b>:</p><pre class="code">${dd.password}</pre>`, footer: html`<button class="btn" data-copy="${dd.password}">${ic('copy', 16)} Копировать</button><button class="btn primary" data-close>Готово</button>` });
        },
      });
    } else if (act === 'kill') {
      if (await confirmBox('Завершить сессии', `Пользователь ${u.login} будет выброшен из панели на всех устройствах.`, { ok: 'Завершить' })) {
        api(`/users/${u.id}/logout`, { method: 'POST', body: {} }).then(() => { toast('Сессии завершены'); reload(); }).catch(errToast);
      }
    } else if (act === 'del') {
      if (await confirmBox('Удалить аккаунт', `Аккаунт ${u.login} будет удалён без возможности восстановления.`, { ok: 'Удалить', danger: true })) {
        api('/users/' + u.id, { method: 'DELETE', body: {} }).then(() => { toast('Удалён'); reload(); }).catch(errToast);
      }
    }
  };
}

/* ───────── Журнал действий панели ───────── */
const AUDIT_L = {
  login: 'Вход в панель', 'login.fail': 'Неудачная попытка входа', logout: 'Выход', 'password.change': 'Смена пароля',
  'user.create': 'Создан аккаунт', 'user.update': 'Изменён аккаунт', 'user.delete': 'Удалён аккаунт', 'user.password': 'Сброс пароля', 'user.logout': 'Сессии завершены',
  'server.create': 'Добавлен сервер', 'server.update': 'Изменён сервер', 'server.delete': 'Удалён сервер', 'server.key': 'Новый ключ сервера',
  'console.exec': 'Команда в консоли', 'punish.ban': 'Бан', 'punish.unban': 'Разбан', 'punish.kick': 'Кик', 'punish.mute': 'Мут', 'punish.unmute': 'Размут', 'punish.warn': 'Предупреждение', 'punish.retry': 'Повтор наказания',
  'report.create': 'Создан репорт', 'report.update': 'Изменён репорт', 'note.add': 'Заметка добавлена', 'note.delete': 'Заметка удалена',
  'whitelist.add': 'Вайтлист: добавление', 'whitelist.remove': 'Вайтлист: удаление', 'whitelist.pull': 'Вайтлист: импорт с сервера', 'whitelist.push': 'Вайтлист: отправка на сервер', 'whitelist.on': 'Вайтлист включён', 'whitelist.off': 'Вайтлист выключен',
  'quotas.update': 'Изменены минималки',
  'discord.link': 'Привязан Discord', 'discord.unlink': 'Отвязан Discord', 'discord.removed': 'Доступ закрыт (удалён из Discord)', 'discord.settings': 'Изменены настройки Discord', 'discord.sync': 'Проверка участников Discord',
  'role.reorder': 'Изменён порядок ролей', 'chat.send': 'Сообщение в чат сервера', 'items.norms': 'Изменены нормы по предметам', 'items.add': 'Записана сдача предмета', 'items.delete': 'Удалена запись о предмете',
  'control.save': 'Сохранение мира', 'control.say': 'Объявление', 'control.title': 'Титр на экране', 'control.time': 'Смена времени', 'control.weather': 'Смена погоды', 'control.gamemode': 'Смена режима игры', 'control.tp': 'Телепорт', 'control.heal': 'Лечение игрока', 'control.whitelist_reload': 'Перечитан вайтлист', 'control.list': 'Список игроков', 'control.difficulty': 'Смена сложности', 'control.op': 'Выдан OP', 'control.deop': 'Снят OP', 'control.give': 'Выдан предмет', 'control.stop': 'Остановка сервера', 'control.start': 'Запуск сервера', 'control.restart': 'Перезапуск сервера',
  'role.create': 'Создана роль', 'role.update': 'Изменена роль', 'role.delete': 'Удалена роль',
  'automod.create': 'Автомодерация: правило создано', 'automod.update': 'Автомодерация: правило изменено', 'automod.delete': 'Автомодерация: правило удалено',
  'schedule.create': 'Планировщик: задача создана', 'schedule.update': 'Планировщик: задача изменена', 'schedule.delete': 'Планировщик: задача удалена', 'schedule.run': 'Планировщик: ручной запуск',
  'webhook.create': 'Интеграция добавлена', 'webhook.update': 'Интеграция изменена', 'webhook.delete': 'Интеграция удалена',
  'system.update': 'Изменены настройки системы', 'backup.create': 'Создана резервная копия', 'backup.download': 'Скачана резервная копия', 'backup.delete': 'Удалена резервная копия',
};
async function auditView() {
  const a = vapi();
  const st = { user: '', q: '', items: [], more: false };
  const first = await a('/audit?limit=100');
  st.items = first.items; st.more = first.has_more;
  setHTML(V(), html`${pageHead('Журнал действий', 'Что делали сотрудники в самой панели: входы, наказания, команды, изменения настроек.')}
    <div class="toolbar"><select class="select" id="au-user"><option value="">Все сотрудники</option>${first.users.map(u => html`<option>${u}</option>`)}</select>
      <div class="search grow">${ic('search', 16)}<input class="input" id="au-q" placeholder="Поиск по действию, цели, деталям"></div></div>
    <div class="card flush"><div class="table-wrap"><table class="t"><thead><tr><th>Время</th><th>Сотрудник</th><th>Действие</th><th>Цель</th><th>Детали</th><th>IP</th></tr></thead><tbody id="au-body"></tbody></table></div><div class="more" id="au-more"></div></div>`);
  const draw = () => {
    setHTML($('#au-body'), st.items.length ? st.items.map(r => html`<tr><td class="nowrap">${fmtTime(r.ts)}</td><td>${r.user_login || html`<span class="mut">—</span>`}</td>
      <td><span class="badge ${/fail|delete|ban|kick/.test(r.action) ? 'bad' : ''}">${AUDIT_L[r.action] || r.action}</span></td><td>${r.target || ''}</td>
      <td class="mut" style="max-width:360px;word-break:break-word;font-size:13px">${r.details || ''}</td><td class="mut nowrap">${r.ip || ''}</td></tr>`) : html`<tr><td colspan="6" class="empty">Записей нет</td></tr>`);
    setHTML($('#au-more'), st.more ? html`<button class="btn" id="au-load">Показать ещё</button>` : '');
  };
  const load = async reset => {
    const last = reset ? null : st.items[st.items.length - 1];
    const d = await a('/audit' + qs({ limit: 100, user: st.user, q: st.q, before: last && last.id }));
    st.items = reset ? d.items : st.items.concat(d.items); st.more = d.has_more; draw();
  };
  draw();
  const search = debounce(() => load(true).catch(errToast), 300);
  V().onchange = e => { if (e.target.id === 'au-user') { st.user = e.target.value; load(true).catch(errToast); } };
  V().oninput = e => { if (e.target.id === 'au-q') { st.q = e.target.value.trim(); search(); } };
  V().onclick = e => { if (e.target.closest('#au-load')) load(false).catch(errToast); };
}

/* ───────── О панели ───────── */
async function infoView() {
  const a = vapi();
  const i = await a('/info');
  const has = (role, p) => (S.rolePerms[role] || []).includes('*') || (S.rolePerms[role] || []).includes(p);
  const roles = S.roleList.filter(r => r.key !== 'owner');
  setHTML(V(), html`${pageHead('О панели', 'Версия, состояние и руководство по подключению серверов')}
    <div class="grid g2">
      <div class="card"><h3>Состояние</h3><dl class="kv">
        <dt>Версия панели</dt><dd>${i.version}</dd><dt>Node.js</dt><dd>${i.node}</dd><dt>Работает</dt><dd>${fmtDur(i.uptime)}</dd>
        <dt>База данных</dt><dd>${fmtBytes(i.db_size)}</dd><dt>Хранение событий</dt><dd>${i.retention_days} дн.</dd>
        <dt>В базе</dt><dd>${i.counts.servers} серв. · ${i.counts.users} польз. · ${i.counts.players} игроков · ${i.counts.events} событий · ${i.counts.punishments} наказаний · ${i.counts.reports} репортов</dd></dl></div>
      <div class="card"><h3>Что отслеживается</h3><ul style="margin:0;padding-left:20px;line-height:1.8">
        <li>Входы и выходы игроков, время в игре, IP и связанные аккаунты</li><li>Чат, команды, смерти, достижения</li><li>Баны и кики, выданные на сервере или из панели</li>
        <li>Репорты игроков (<span class="mono">/report ник причина</span>)</li><li>Статус сервера, пинг и онлайн каждую минуту</li><li>Любые события от вашего плагина (сломанные блоки, сундуки и т. д.)</li></ul></div>
    </div>
    <div class="card mt"><h3>Подключение сервера Minecraft</h3>
      <ol style="line-height:1.8;margin:0 0 12px;padding-left:20px">
        <li>${can('servers.manage') ? html`<a href="#/new-server">Добавьте сервер</a>` : 'Попросите администратора добавить сервер'} — панель выдаст ключ и готовую команду (показывается один раз).</li>
        <li>Выполните команду на машине с сервером, из его папки: <span class="mono">curl -fsSL ${location.origin}/install/КЛЮЧ | bash</span>. Нужен Linux и Node.js 18+. Агент сам найдёт логи, запустится как служба и будет обновляться вместе с панелью.</li>
        <li>Для команд из панели (бан, кик, вайтлист, консоль) включите RCON в <span class="mono">server.properties</span>: <span class="mono">enable-rcon=true</span>, <span class="mono">rcon.password=…</span>. Порт RCON наружу открывать не нужно — команды идут через агента.</li>
        <li>Вручную: <a href="/api/agent-files/agent.js" download>agent.js</a> · <a href="/api/agent-files/mc.js" download>mc.js</a> и <span class="mono">node agent.js --panel … --key …</span>.</li>
      </ol><div class="note">Агент читает <span class="mono">logs/latest.log</span> и не требует плагинов. Чтобы получать расширенные данные (клиент, блоки, сундуки), плагин может отправлять события на <span class="mono">POST ${location.origin}/api/agent/events</span> с заголовком <span class="mono">Authorization: Bearer &lt;ключ&gt;</span> и телом <span class="mono">{"events":[{"type":"block_break","player":"Steve","message":"stone","data":{"world":"world"}}]}</span>. Для события <span class="mono">join</span> можно передать <span class="mono">data.client_brand</span> и <span class="mono">data.client_version</span> — они появятся на странице «Клиент дата».</div></div>
    <div class="card mt"><h3>Приложение для Android</h3><p style="margin:0 0 8px">Панель работает и в браузере, и как приложение — данные и права те же.</p>
      <ul style="margin:0;padding-left:20px;line-height:1.7"><li><b>Без установки APK:</b> откройте панель в Chrome на телефоне → меню ⋮ → «Установить приложение» (или «Добавить на главный экран»). Нужен HTTPS-адрес панели.</li>
      <li><b>Приложение (APK):</b> ${S.hasApk ? html`<a href="/app.apk" download>скачать APK</a> и установить (разрешите установку из этого источника).` : 'владелец собирает его из папки android (инструкция в README) и кладёт файл app.apk в папку данных панели — тогда здесь появится ссылка для скачивания.'}</li></ul></div>
    <div class="card mt"><h3>Вход через Discord</h3><p style="margin:0 0 8px">Сотрудники могут входить кнопкой «Войти через Discord». Доступ определяют роли на Discord-сервере: владелец привязывает роли панели к ролям Discord (страница «Роли и доступ»), и затем:</p>
      <ul style="margin:0;padding-left:20px;line-height:1.7"><li><b>Добавить сотрудника</b> — выдайте ему привязанную роль в Discord. При первом входе аккаунт создастся сам.</li><li><b>Убрать доступ</b> — снимите роль или удалите человека с Discord-сервера. С токеном бота доступ закрывается в течение 5 минут и сессии завершаются; без токена — при следующем входе.</li><li><b>Сменить роль</b> — измените роль в Discord, права в панели обновятся сами.</li><li>Уже существующие аккаунты привязываются вручную: меню профиля → «Привязать Discord».</li></ul>
      ${can('system') ? html`<div style="margin-top:10px"><a class="btn sm" href="#/system">Настроить вход через Discord</a></div>` : ''}</div>
    <div class="card flush mt"><div class="card-h"><h3>Разделы панели</h3><span class="mut" style="font-size:13px">показаны те, к которым у вас есть доступ</span></div>
      ${Object.entries(HELP).filter(([k, h]) => h.ref && (!h.feature || S.features[h.feature]) && (!h.perm || can(h.perm))).map(([k, h]) => html`<div class="pop-item" style="border-radius:0;align-items:flex-start;cursor:default"><span>${ic(h.icon)}</span><span class="grow"><div class="t">${h.title}</div><div class="s">${h.what}</div></span></div>`)}
    </div>
    <div class="card flush mt"><div class="card-h"><h3>Права ролей</h3></div><div class="table-wrap"><table class="t"><thead><tr><th>Возможность</th><th>${roleBadge('owner')}</th>${roles.map(r => html`<th>${roleBadge(r.key)}</th>`)}</tr></thead><tbody>
      ${S.catalog.map(g => html`<tr><td colspan="${roles.length + 2}" class="mut" style="font-size:12px;text-transform:uppercase;letter-spacing:.05em">${g.group}</td></tr>${g.items.map(([p, l, desc]) => html`<tr><td><b>${l}</b><div class="mut" style="font-size:12.5px">${desc}</div></td><td><span class="ok">${ic('check', 18)}</span></td>${roles.map(r => html`<td>${has(r.key, p) ? html`<span class="ok">${ic('check', 18)}</span>` : html`<span class="mut">—</span>`}</td>`)}</tr>`)}`)}
    </tbody></table></div></div>`);
}

/* ───────── Запуск ───────── */
async function boot() {
  const dcErr = new URLSearchParams(location.search).get('dc_error');
  if (dcErr) { history.replaceState(null, '', location.pathname + location.hash); return showLogin(dcErr); }
  try { await loadMe(); } catch { return showLogin(); }
  renderShell(); connectSSE();
  if (!location.hash) location.hash = '#/';
  route();
}
