'use strict';
/* ───────── Страницы сервера ───────── */
const sPage = (s, title, sub, actions) => pageHead(title, html`${s.name}${sub ? ' · ' + sub : ''}`, actions);
const playerLink = (s, name, size = 22) => html`<a class="pl" href="#/s/${s.id}/players/${encodeURIComponent(name)}">${head(name, size)}${name}</a>`;
const statusBadge = s => html`<span class="badge ${s.online ? 'ok' : 'bad'}"><span class="dot ${s.online ? 'on' : 'off'}" style="margin:0"></span>${s.online ? 'В сети' : 'Недоступен'}</span>`;

/* ───── Общая лента событий ───── */
function evRow(e, s, isNew) {
  const det = evDetails(e);
  return html`<div class="ev ${isNew ? 'new' : ''}"><div class="ev-t" title="${fmtFull(e.ts)}">${fmtTime(e.ts)}</div><div class="ev-b">${evBadge(e.type)}${e.player ? playerLink(s, e.player, 20) : ''}${e.message ? html`<span class="ev-m">${e.message}</span>` : ''}${det ? html`<span class="ev-d">${det}</span>` : ''}</div></div>`;
}
function createFeed(s, a, listEl, moreEl, getFilters) {
  const st = { items: [], more: false };
  const draw = fresh => {
    setHTML(listEl, st.items.length ? st.items.map(e => evRow(e, s, fresh && fresh.has(e.id))) : html`<div class="empty">Событий по этим условиям нет</div>`);
    setHTML(moreEl, st.more ? html`<button class="btn" data-feed="more">Показать ещё</button>` : '');
  };
  const load = async (reset = true) => {
    const last = reset ? null : st.items[st.items.length - 1];
    const d = await a(`/servers/${s.id}/events` + qs({ ...getFilters(), limit: 100, before: last && last.id }));
    st.items = reset ? d.items : st.items.concat(d.items).slice(0, 2000);
    st.more = d.has_more; draw();
  };
  const pull = async () => {
    if (!st.items.length) return load(true);
    const d = await a(`/servers/${s.id}/events` + qs({ ...getFilters(), limit: 100, after: st.items[0].id }));
    if (!d.items.length) return;
    if (d.has_more) return load(true);
    st.items = d.items.concat(st.items).slice(0, 2000);
    draw(new Set(d.items.map(x => x.id)));
  };
  return { st, load, pull, draw };
}

/* ───── Модальные окна наказаний ───── */
function punishModal(s, name, type, done) {
  const dur = type === 'ban' || type === 'mute';
  formModal({
    title: `${PUN[type][0]}: ${name}`, submit: PUN[type][0], danger: type === 'ban',
    body: html`<div class="field"><label>Причина</label><input class="input" name="reason" maxlength="200" placeholder="Например: использование читов (п. 2.1)" ${type === 'warn' ? 'required' : ''}></div>
      ${dur ? html`<div class="field"><label>Срок</label><input class="input" name="duration" list="durs" placeholder="пусто — навсегда"><datalist id="durs"><option value="30m"><option value="2h"><option value="1d"><option value="7d"><option value="30d"></datalist>
      <div class="hint">Форматы: 30m, 2h, 7d, 1w, 1d12h. Если шаблон команды не содержит {duration}, панель сама снимет наказание по истечении срока.</div></div>` : ''}`,
    onSubmit: async (d, f, m) => {
      const r = await api(`/servers/${s.id}/players/${encodeURIComponent(name)}/punish`, { method: 'POST', body: { type, reason: d.reason, duration: d.duration } });
      m.close();
      if (r.applied) toast(`${PUN[type][0]}: выполнено на сервере`);
      else toast(`Записано в панели, но команда не выполнена: ${r.error}`, 'warn', 10000);
      if (done) done();
    },
  });
}
async function undoPunish(s, name, type, done) {
  const word = type === 'unban' ? 'разбанить' : 'снять мут с';
  if (!await confirmBox(PUN[type][0], `Точно ${word} ${name}?`, { ok: PUN[type][0] })) return;
  try {
    const r = await api(`/servers/${s.id}/players/${encodeURIComponent(name)}/punish`, { method: 'POST', body: { type } });
    if (r.applied) toast('Выполнено'); else toast('Записано в панели, но команда не выполнена: ' + r.error, 'warn', 10000);
    if (done) done();
  } catch (e) { errToast(e); }
}

/* ═════════ Логи ═════════ */
async function logsView(s) {
  const a = vapi();
  const types = (await a(`/servers/${s.id}/event-types`)).types;
  const f = { types: new Set(), q: '', player: '', from: '', to: '' };
  let liveOn = true;
  setHTML(V(), html`${sPage(s, 'Логи', 'все действия игроков и сервера', html`<span class="live" id="live-t"><i class="dot on"></i>Прямой эфир</span><button class="btn" id="csv">${ic('download', 16)} CSV</button>`)}
    <div class="card" style="margin-bottom:16px"><div class="toolbar" style="margin-bottom:10px">
      <div class="search grow">${ic('search', 16)}<input class="input" id="f-q" placeholder="Поиск по сообщениям"></div>
      <input class="input" id="f-p" placeholder="Ник игрока" style="max-width:180px">
      <input class="input" id="f-from" type="datetime-local" title="С" style="max-width:210px"><input class="input" id="f-to" type="datetime-local" title="По" style="max-width:210px"></div>
      <div class="chips" id="chips"></div></div>
    <div class="card flush"><div id="ev-list"></div><div class="more" id="ev-more"></div></div>`);
  const drawChips = () => setHTML($('#chips'), types.length ? types.map(t => html`<button class="chip ${f.types.has(t.type) ? 'on' : ''}" data-t="${t.type}">${evLabel(t.type)} <span class="mut">${t.c}</span></button>`) : html`<span class="mut" style="font-size:13px">Типов событий пока нет</span>`);
  drawChips();
  const feed = createFeed(s, a, $('#ev-list'), $('#ev-more'), () => ({
    types: [...f.types].join(','), q: f.q, player: f.player,
    from: f.from ? new Date(f.from).getTime() : '', to: f.to ? new Date(f.to).getTime() : '',
  }));
  await feed.load(true);
  const reload = debounce(() => feed.load(true).catch(errToast), 350);
  const v = V();
  v.oninput = e => {
    const id = e.target.id;
    if (id === 'f-q') f.q = e.target.value.trim(); else if (id === 'f-p') f.player = e.target.value.trim(); else return;
    reload();
  };
  v.onchange = e => {
    if (e.target.id === 'f-from') f.from = e.target.value; else if (e.target.id === 'f-to') f.to = e.target.value; else return;
    reload();
  };
  v.onclick = e => {
    const chip = e.target.closest('[data-t]');
    if (chip) { const t = chip.dataset.t; f.types.has(t) ? f.types.delete(t) : f.types.add(t); drawChips(); return reload(); }
    if (e.target.closest('[data-feed=more]')) return feed.load(false).catch(errToast);
    if (e.target.closest('#live-t')) { liveOn = !liveOn; $('#live-t').classList.toggle('paused', !liveOn); $('#live-t').lastChild.textContent = liveOn ? 'Прямой эфир' : 'Пауза'; return; }
    if (e.target.closest('#csv')) {
      const q = x => '"' + String(x == null ? '' : x).replace(/"/g, '""') + '"';
      downloadFile(`${s.name}-logs-${Date.now()}.csv`, 'Время,Тип,Игрок,Сообщение,Детали\n' + feed.st.items.map(r => [fmtFull(r.ts) + ':' + pad(new Date(r.ts).getSeconds()), evLabel(r.type), r.player, r.message, evDetails(r)].map(q).join(',')).join('\n'));
    }
  };
  const pull = () => { if (liveOn && !f.to && a.alive()) feed.pull().catch(() => {}); };
  live(m => { if (m.t === 'events' && m.server === s.id) pull(); });
  every(pull, 15000);
}

/* ═════════ Статус ═════════ */
async function statusView(s0) {
  const a = vapi();
  const render = async () => {
    const d = await a(`/servers/${s0.id}/status`);
    const s = d.server;
    const lat = d.samples.filter(x => x.latency != null).map(x => ({ ts: x.ts, latency: x.latency }));
    const stat = (icon, val, label) => html`<div class="card stat"><div class="si">${ic(icon, 22)}</div><div><div class="sv">${val}</div><div class="sl">${label}</div></div></div>`;
    setHTML(V(), html`${sPage(s, 'Статус серверов', null, html`<button class="btn" data-st="refresh">${ic('refresh', 16)} Проверить сейчас</button>${can('console') || can('servers.manage') ? html`<button class="btn" data-st="rcon">${ic('terminal', 16)} Проверить RCON</button>` : ''}`)}
      <div class="card"><div class="row wrap" style="gap:16px">${sicon(s, 56)}<div class="grow"><div class="row wrap"><h2 style="margin:0;font-size:20px">${s.name}</h2>${statusBadge(s)}</div>
        <div class="dim" style="margin-top:4px;white-space:pre-line">${s.motd || (s.online ? '' : 'Сервер не отвечает на запросы статуса')}</div></div></div></div>
      <div class="grid g-stats mt">
        ${stat('signal', s.online ? `${s.players_online}${s.players_max ? ' / ' + s.players_max : ''}` : '—', 'игроков онлайн')}
        ${stat('pulse', s.latency != null && s.online ? s.latency + ' мс' : '—', 'пинг')}
        ${stat('server', s.version || '—', 'версия')}
        ${stat('shield', d.uptime.h24 == null ? '—' : d.uptime.h24 + '%', 'доступность за 24 ч')}
        ${stat('shield', d.uptime.d7 == null ? '—' : d.uptime.d7 + '%', 'доступность за 7 дн')}
        ${stat('users', d.counts.players, 'игроков в базе')}
        ${stat('list', d.counts.events_24h, 'событий за 24 ч')}
        ${stat('clock', d.counts.last_event ? ago(d.counts.last_event) : '—', 'последнее событие')}
      </div>
      <div class="grid g2 mt"><div class="card"><h3>Онлайн за 24 часа</h3>${lineChart(d.samples, { key: 'online' })}</div>
        <div class="card"><h3>Пинг за 24 часа, мс</h3>${lineChart(lat, { key: 'latency', color: 'var(--cyan)', unit: ' мс' })}</div></div>
      <div class="card mt"><h3>Агент и управление</h3><dl class="kv">
        <dt>Агент</dt><dd>${s.agent_alive ? html`<span class="ok">● подключён</span> · v${s.agent_version || '?'} · ${s.agent_rcon ? 'RCON включён' : 'без RCON'}` : html`<span class="bad">● не подключён</span> ${s.last_agent ? '(был ' + ago(s.last_agent) + ')' : ''}`}</dd>
        <dt>Команды из панели</dt><dd>${s.can_command ? html`<span class="ok">доступны</span>` : html`<span class="warn">недоступны</span> — ${s.rcon_mode === 'direct' ? 'не настроен прямой RCON' : 'нужен подключённый агент с RCON'}`}</dd>
        <dt>Режим RCON</dt><dd>${s.rcon_mode === 'direct' ? 'прямое подключение панели' : 'через агента'}</dd></dl>
        ${!s.agent_alive ? html`<div class="note warn mt-s">Агент не подключён: логи, входы/выходы и репорты не поступают. Инструкция — на странице <a href="#/info">«Информация»</a>.</div>` : ''}</div>
      ${d.all.length > 1 ? html`<div class="card flush mt"><div class="card-h"><h3>Все серверы</h3></div><div class="table-wrap"><table class="t"><thead><tr><th>Сервер</th><th>Статус</th><th>Онлайн</th><th>Версия</th><th>Пинг</th></tr></thead><tbody>
        ${d.all.map(x => html`<tr class="click" data-href="#/s/${x.id}/status"><td><div class="row">${sicon(x, 28)}<b>${x.name}</b></div></td><td>${statusBadge(x)}</td><td>${x.online ? `${x.players_online}${x.players_max ? '/' + x.players_max : ''}` : '—'}</td><td>${x.version || '—'}</td><td>${x.latency != null && x.online ? x.latency + ' мс' : '—'}</td></tr>`)}</tbody></table></div></div>` : ''}`);
    V().onclick = async e => {
      const b = e.target.closest('[data-st]'); if (!b) return;
      b.disabled = true;
      try {
        if (b.dataset.st === 'refresh') { await a(`/servers/${s.id}/refresh`, { method: 'POST', body: {} }); toast('Статус обновлён'); await render(); }
        else {
          const r = await a(`/servers/${s.id}/rcon-test`, { method: 'POST', body: {} });
          if (r.ok) toast(`RCON работает (${r.ms} мс): ${String(r.response).slice(0, 120)}`); else toast('RCON: ' + r.error, 'err', 9000);
        }
      } catch (ex) { errToast(ex); } finally { b.disabled = false; }
    };
  };
  await render();
  const again = debounce(() => { if (a.alive()) render().catch(() => {}); }, 2000);
  live(m => { if ((m.t === 'status' || m.t === 'online') && m.server === s0.id) again(); });
  every(() => { if (a.alive()) render().catch(() => {}); }, 30000);
}

/* ═════════ Консоль ═════════ */
async function consoleView(s) {
  const a = vapi();
  const d = await a(`/servers/${s.id}/console`);
  let last = d.lines.length ? d.lines[d.lines.length - 1].id : 0;
  const hist = store.get('cmdhist', []); let hi = -1;
  setHTML(V(), html`${sPage(s, 'Консоль', 'вывод сервера и команды через RCON', html`<button class="btn" id="cl-clear">Очистить экран</button>`)}
    ${d.can_command ? '' : html`<div class="note warn" style="margin-bottom:14px">Отправка команд недоступна: ${s.rcon_mode === 'direct' ? 'не настроен прямой RCON' : 'агент не подключён или запущен без RCON'}. ${can('servers.manage') ? html`<a href="#/s/${s.id}/settings">Настройки сервера</a>` : ''} Вывод консоли показывается, пока агент подключён.</div>`}
    <div class="console" id="con" aria-live="polite"></div>
    <form class="row mt-s" id="con-form" autocomplete="off"><span class="mono dim">&gt;</span><input class="input mono grow" id="con-in" placeholder="Команда без /, например: list" ${d.can_command ? '' : 'disabled'} maxlength="500"><button class="btn primary" type="submit" ${d.can_command ? '' : 'disabled'}>${ic('send', 16)} Отправить</button></form>
    <div class="chips mt-s">${['list', 'save-all', 'whitelist list', 'tps'].map(c => html`<button class="chip" data-q="${c}">${c}</button>`)}</div>`);
  const box = $('#con');
  const lineHTML = l => `<div class="cl ${esc(l.level)}"><span class="ts">${pad(new Date(l.ts).getHours())}:${pad(new Date(l.ts).getMinutes())}:${pad(new Date(l.ts).getSeconds())}</span>${esc(l.line)}</div>`;
  const append = lines => {
    if (!lines.length) return;
    const bottom = box.scrollHeight - box.scrollTop - box.clientHeight < 60;
    box.insertAdjacentHTML('beforeend', lines.map(lineHTML).join(''));
    while (box.childElementCount > 1500) box.firstChild.remove();
    if (bottom) box.scrollTop = box.scrollHeight;
    last = lines[lines.length - 1].id;
  };
  box.innerHTML = d.lines.length ? '' : '<div class="cl DEBUG">Консоль пуста. Строки появятся, когда агент начнёт отправлять лог сервера.</div>';
  append(d.lines); box.scrollTop = box.scrollHeight;
  let pulling = false;
  const pull = async () => {
    if (pulling || !a.alive()) return; pulling = true;
    try { const r = await a(`/servers/${s.id}/console` + qs({ after: last })); const ph = box.querySelector('.cl.DEBUG:only-child'); if (ph && r.lines.length) ph.remove(); append(r.lines); } catch {} finally { pulling = false; }
  };
  live(m => { if (m.t === 'console' && m.server === s.id) pull(); });
  every(pull, 4000);
  const inp = $('#con-in');
  const send = async cmd => {
    cmd = cmd.trim(); if (!cmd) return;
    if (hist[hist.length - 1] !== cmd) { hist.push(cmd); store.set('cmdhist', hist.slice(-50)); }
    hi = -1; inp.value = ''; inp.disabled = true;
    try { await a(`/servers/${s.id}/console`, { method: 'POST', body: { command: cmd } }); } catch (e) { errToast(e); }
    inp.disabled = false; inp.focus(); await pull(); box.scrollTop = box.scrollHeight;
  };
  V().onsubmit = e => { e.preventDefault(); send(inp.value); };
  V().onkeydown = e => {
    if (e.target !== inp) return;
    if (e.key === 'ArrowUp' && hist.length) { hi = Math.min(hist.length - 1, hi + 1); inp.value = hist[hist.length - 1 - hi]; e.preventDefault(); }
    if (e.key === 'ArrowDown') { hi = Math.max(-1, hi - 1); inp.value = hi < 0 ? '' : hist[hist.length - 1 - hi]; e.preventDefault(); }
  };
  V().onclick = e => {
    if (e.target.closest('#cl-clear')) box.innerHTML = '';
    const q = e.target.closest('[data-q]'); if (q && d.can_command) send(q.dataset.q);
  };
  // форма — внутри #view, поэтому onsubmit срабатывает через всплытие
}

/* ═════════ Онлайн ═════════ */
async function onlineView(s0) {
  const a = vapi();
  let range = '24h';
  const render = async () => {
    const d = await a(`/servers/${s0.id}/online` + qs({ range }));
    const s = d.server;
    const stat = (icon, val, label) => html`<div class="card stat"><div class="si">${ic(icon, 22)}</div><div><div class="sv">${val}</div><div class="sl">${label}</div></div></div>`;
    setHTML(V(), html`${sPage(s, 'Онлайн', null, html`<span class="live"><i class="dot on"></i>Обновляется автоматически</span>`)}
      <div class="grid g-stats">${stat('signal', s.online ? `${s.players_online}${s.players_max ? ' / ' + s.players_max : ''}` : 'офлайн', 'сейчас на сервере')}${stat('users', d.peak, 'пик за период')}${stat('pulse', d.avg, 'среднее за период')}${stat('user', d.unique_24h, 'уникальных за 24 ч')}${stat('user', d.unique_7d, 'уникальных за 7 дн')}${stat('kick', d.joins_24h, 'входов за 24 ч')}</div>
      <div class="card mt"><div class="row wrap" style="margin-bottom:8px"><h3 style="margin:0" class="grow">График онлайна</h3><div class="chips">${[['24h', '24 часа'], ['7d', '7 дней'], ['30d', '30 дней']].map(([k, l]) => html`<button class="chip ${range === k ? 'on' : ''}" data-r="${k}">${l}</button>`)}</div></div>
        ${lineChart(d.chart, { key: 'online', xfmt: t => range === '24h' ? `${pad(new Date(t).getHours())}:${pad(new Date(t).getMinutes())}` : fmtDate(t).slice(0, 5) })}</div>
      <div class="card flush mt"><div class="card-h"><h3>Сейчас в игре (${d.players.length})</h3></div>
        ${d.players.length ? html`<div class="table-wrap"><table class="t"><thead><tr><th>Игрок</th><th>В игре</th><th>Мир</th><th>Клиент</th><th></th></tr></thead><tbody>${d.players.map(p => html`<tr><td>${playerLink(s, p.name, 28)} ${p.muted ? html`<span class="badge warn">мут</span>` : ''}</td><td>${p.since ? fmtDur((Date.now() - p.since) / 1000) : '—'}</td><td>${p.last_world || '—'}</td><td>${p.client_brand || '—'}</td>
          <td class="nowrap" style="text-align:right">${can('punish') ? html`<button class="btn sm" data-p="warn" data-n="${p.name}">Предупр.</button> <button class="btn sm warn" data-p="kick" data-n="${p.name}">Кик</button>` : ''}</td></tr>`)}</tbody></table></div>` : html`<div class="empty">${s.online ? 'Сейчас на сервере никого нет, либо агент ещё не передал список игроков' : 'Сервер недоступен'}</div>`}</div>`);
    V().onclick = e => {
      const r = e.target.closest('[data-r]'); if (r) { range = r.dataset.r; return render().catch(errToast); }
      const p = e.target.closest('[data-p]'); if (p) punishModal(s, p.dataset.n, p.dataset.p, () => render().catch(() => {}));
    };
  };
  await render();
  const again = debounce(() => { if (a.alive()) render().catch(() => {}); }, 1500);
  live(m => { if ((m.t === 'online' || m.t === 'status') && m.server === s0.id) again(); });
  every(() => { if (a.alive()) render().catch(() => {}); }, 30000);
}

/* ═════════ Репорты ═════════ */
const REP_ST = { open: ['Открыт', 'warn'], progress: ['В работе', 'cyan'], closed: ['Закрыт', 'ok'] };
async function reportsView(s) {
  const a = vapi();
  let status = 'active', qtext = '';
  const render = async () => {
    const d = await a(`/servers/${s.id}/reports` + qs({ status, q: qtext }));
    const c = d.counts, act = (c.open || 0) + (c.progress || 0);
    const tab = (k, l, n) => html`<button class="tab ${status === k ? 'active' : ''}" data-rs="${k}">${l}${n != null ? html`<span class="n">${n}</span>` : ''}</button>`;
    setHTML(V(), html`${sPage(s, 'Репорты', 'жалобы игроков', html`<button class="btn primary" data-r="new">${ic('plus', 16)} Создать репорт</button>`)}
      <div class="tabs">${tab('active', 'Активные', act)}${tab('open', 'Открытые', c.open || 0)}${tab('progress', 'В работе', c.progress || 0)}${tab('closed', 'Закрытые', c.closed || 0)}${tab('all', 'Все', null)}</div>
      <div class="toolbar"><div class="search grow">${ic('search', 16)}<input class="input" id="rq" value="${qtext}" placeholder="Поиск по нику или причине"></div></div>
      <div class="card flush">${d.items.length ? html`<div class="table-wrap"><table class="t"><thead><tr><th>#</th><th>Время</th><th>Жалоба</th><th>Причина</th><th>Статус</th><th>Ответственный</th></tr></thead><tbody>
        ${d.items.map(r => html`<tr class="click" data-r="${r.id}"><td><b>${r.id}</b></td><td class="nowrap">${fmtTime(r.created_at, false)}</td><td class="nowrap">${r.reporter || '—'} → <b>${r.target || '—'}</b></td><td style="max-width:360px;word-break:break-word">${r.reason}${r.comments ? html` <span class="badge mut">${ic('msg', 12)} ${r.comments}</span>` : ''}</td>
          <td><span class="badge ${REP_ST[r.status][1]}">${REP_ST[r.status][0]}</span></td><td>${r.assignee_name || html`<span class="mut">—</span>`}</td></tr>`)}</tbody></table></div>` : html`<div class="empty">Репортов нет</div>`}
        ${d.has_more ? html`<div class="empty small mut">Показаны последние 50 — уточните поиск</div>` : ''}</div>`);
    const v = V();
    v.onclick = e => {
      const t = e.target.closest('[data-rs]'); if (t) { status = t.dataset.rs; return render().catch(errToast); }
      const r = e.target.closest('[data-r]'); if (!r) return;
      if (r.dataset.r === 'new') newReport(); else openReport(Number(r.dataset.r));
    };
    const search = debounce(() => render().then(() => { const i = $('#rq'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }).catch(errToast), 350);
    v.oninput = e => { if (e.target.id === 'rq') { qtext = e.target.value.trim(); search(); } };
  };
  const newReport = () => formModal({
    title: 'Новый репорт', submit: 'Создать',
    body: html`<div class="fgrid"><div class="field"><label>Кто пожаловался</label><input class="input" name="reporter" placeholder="ник (необязательно)"></div><div class="field"><label>На кого</label><input class="input" name="target" placeholder="ник"></div></div>
      <div class="field"><label>Описание</label><textarea class="input" name="reason" required maxlength="1000"></textarea></div>`,
    onSubmit: async (d, f, m) => { const r = await api(`/servers/${s.id}/reports`, { method: 'POST', body: d }); m.close(); toast('Репорт создан'); await render(); openReport(r.id); },
  });
  const openReport = async id => {
    const [d, st] = await Promise.all([api('/reports/' + id), api(`/reports-staff/${s.id}`)]).catch(e => { errToast(e); return []; });
    if (!d) return;
    const m = modal({ title: `Репорт #${id}`, wide: true, body: '', footer: false });
    const draw = (d) => {
      const r = d.report;
      setHTML(m.body, html`<div class="row wrap" style="margin-bottom:12px"><span class="badge ${REP_ST[r.status][1]}">${REP_ST[r.status][0]}</span><span class="mut">${fmtFull(r.created_at)} · ${r.source === 'game' ? 'из игры' : 'создан в панели'}</span></div>
        <dl class="kv"><dt>Жалоба от</dt><dd>${r.reporter ? playerLink(s, r.reporter, 22) : '—'}</dd><dt>На игрока</dt><dd>${r.target ? html`${playerLink(s, r.target, 22)}` : '—'}</dd><dt>Причина</dt><dd style="white-space:pre-wrap">${r.reason}</dd>
        <dt>Ответственный</dt><dd><select class="select" id="rp-as" style="max-width:260px"><option value="">— не назначен —</option>${st.staff.map(u => html`<option value="${u.id}" ${r.assignee_id === u.id ? 'selected' : ''}>${u.name}</option>`)}</select></dd>
        ${r.status === 'closed' ? html`<dt>Решение</dt><dd>${r.resolution || '—'} <span class="mut">(${r.closed_by_name || ''}, ${fmtFull(r.closed_at)})</span></dd>` : ''}</dl>
        <div class="row wrap mt">${r.status === 'open' ? html`<button class="btn primary" data-a="progress">Взять в работу</button>` : ''}${r.status !== 'closed' ? html`<button class="btn" data-a="close">Закрыть с решением</button>` : html`<button class="btn" data-a="open">Переоткрыть</button>`}
          ${r.target && can('punish') ? html`<a class="btn warn" href="#/s/${s.id}/players/${encodeURIComponent(r.target)}" data-close>${ic('ban', 16)} К игроку / наказать</a>` : ''}</div>
        <h3 style="margin:22px 0 10px">Комментарии</h3>${d.comments.length ? d.comments.map(c => html`<div class="comment"><div class="h">${c.user_name} · ${fmtFull(c.ts)}</div>${c.text}</div>`) : html`<div class="mut" style="margin-bottom:10px">Комментариев нет</div>`}
        <form class="row" id="rp-cm" style="align-items:flex-start"><textarea class="input grow" name="text" rows="2" placeholder="Добавить комментарий…" maxlength="1000"></textarea><button class="btn primary" type="submit">Отправить</button></form>`);
    };
    const reload = async () => { const nd = await api('/reports/' + id); draw(nd); render().catch(() => {}); };
    draw(d);
    m.el.addEventListener('change', async e => {
      if (e.target.id === 'rp-as') api('/reports/' + id, { method: 'PATCH', body: { assignee_id: e.target.value ? Number(e.target.value) : null } }).then(reload).catch(errToast);
    });
    m.el.addEventListener('submit', async e => {
      e.preventDefault();
      const text = e.target.text.value.trim(); if (!text) return;
      api(`/reports/${id}/comments`, { method: 'POST', body: { text } }).then(reload).catch(errToast);
    });
    m.el.addEventListener('click', e => {
      const b = e.target.closest('[data-a]'); if (!b) return;
      const act = b.dataset.a;
      if (act === 'close') {
        formModal({ title: 'Закрыть репорт', submit: 'Закрыть', body: html`<div class="field"><label>Решение</label><textarea class="input" name="resolution" placeholder="Что сделано по жалобе" maxlength="1000"></textarea></div>`,
          onSubmit: async (dd, f, mm) => { await api('/reports/' + id, { method: 'PATCH', body: { status: 'closed', resolution: dd.resolution } }); mm.close(); toast('Репорт закрыт'); await reload(); } });
      } else api('/reports/' + id, { method: 'PATCH', body: { status: act } }).then(reload).catch(errToast);
    });
  };
  await render();
  live(m => { if (m.t === 'reports' && m.server === s.id && a.alive() && !$('.modal-back')) render().catch(() => {}); });
}

/* ═════════ Минималки ═════════ */
async function quotasView(s) {
  const a = vapi();
  let week = Date.now();
  const render = async () => {
    const d = await a(`/servers/${s.id}/quotas` + qs({ week }));
    const isCur = d.week_start <= Date.now() && Date.now() < d.week_end;
    const label = `${fmtDate(d.week_start).slice(0, 5)} – ${fmtDate(d.week_end - 1).slice(0, 5)}`;
    const roles = S.roleList.filter(r => r.key !== 'owner').map(r => r.key);
    setHTML(V(), html`${sPage(s, 'Минималки', 'нормы активности персонала за неделю (пн–вс)')}
      <div class="row wrap mb"><button class="btn" data-w="-1">${ic('back', 16)}</button><b style="min-width:120px;text-align:center">${label}${isCur ? html` <span class="badge">текущая</span>` : ''}</b><button class="btn" data-w="1" style="transform:scaleX(-1)">${ic('back', 16)}</button>${isCur ? '' : html`<button class="btn ghost" data-w="0">К текущей неделе</button>`}</div>
      <div class="card flush"><div class="table-wrap"><table class="t"><thead><tr><th>Сотрудник</th><th>Роль</th><th>Часов в игре</th><th>Наказаний</th><th>Репортов закрыто</th><th>Итог</th></tr></thead><tbody>
        ${d.staff.length ? d.staff.map(u => html`<tr><td><div class="row">${head(u.mc_nick, 28)}<div><b>${u.name}</b><div class="mut" style="font-size:12.5px">${u.mc_nick}</div></div></div></td><td>${roleBadge(u.role)}</td>
          <td>${progress(u.hours, u.norm && u.norm.hours, hours)}</td><td>${progress(u.punishments, u.norm && u.norm.punishments)}</td><td>${progress(u.reports, u.norm && u.norm.reports)}</td>
          <td>${u.done === null ? html`<span class="badge mut">нет нормы</span>` : u.done ? html`<span class="badge ok">Выполнено</span>` : html`<span class="badge bad">Не выполнено</span>`}</td></tr>`) : html`<tr><td colspan="6" class="empty">Нет сотрудников с указанным ником в Minecraft. Владелец может задать ник в разделе «Пользователи».</td></tr>`}</tbody></table></div></div>
      <div class="note mt-s" style="font-size:13px">Часы считаются по сессиям игрока на этом сервере. В «наказания» входят баны, муты, кики и предупреждения, выданные из панели, и зафиксированные в логах команды (<span class="mono">/mute /warn /tempban /jail</span> и т. п.). «Репорты» — закрытые сотрудником за неделю.</div>
      ${can('quotas') ? html`<div class="card mt"><h3>Нормы на неделю</h3><form id="nq"><div class="table-wrap"><table class="t"><thead><tr><th>Роль</th><th>Часов в игре</th><th>Наказаний</th><th>Репортов</th></tr></thead><tbody>
        ${roles.map(r => { const n = d.norms[r] || { hours: 0, punishments: 0, reports: 0 }; return html`<tr><td>${roleBadge(r)}</td><td><input class="input" style="max-width:120px" type="number" min="0" max="168" step="0.5" name="${r}_hours" value="${n.hours}"></td><td><input class="input" style="max-width:120px" type="number" min="0" name="${r}_punishments" value="${n.punishments}"></td><td><input class="input" style="max-width:120px" type="number" min="0" name="${r}_reports" value="${n.reports}"></td></tr>`; })}</tbody></table></div>
        <div class="row mt-s"><button class="btn primary" type="submit">Сохранить нормы</button><span class="mut" style="font-size:13px">0 — нормы нет. Новые нормы применяются и к прошлым неделям.</span></div></form></div>` : ''}`);
    const ib = document.createElement('div'); V().appendChild(ib);
    itemsSection(s, d.week_start, ib, a).catch(e => { if (!e.stale) errToast(e); });
    V().onclick = e => {
      const w = e.target.closest('[data-w]'); if (!w) return;
      const k = Number(w.dataset.w); week = k === 0 ? Date.now() : d.week_start + k * 7 * 864e5 + 3600e3 * 12;
      render().catch(errToast);
    };
    V().onsubmit = async e => {
      e.preventDefault();
      const f = e.target, norms = {};
      for (const r of roles) norms[r] = { hours: f[r + '_hours'].value, punishments: f[r + '_punishments'].value, reports: f[r + '_reports'].value };
      try { await a(`/servers/${s.id}/quotas`, { method: 'PUT', body: { norms } }); toast('Нормы сохранены'); await render(); } catch (ex) { errToast(ex); }
    };
  };
  await render();
}

/* ═════════ Клиент дата ═════════ */
async function clientsView(s) {
  const a = vapi();
  let page = 1, qtext = '';
  const render = async () => {
    const d = await a(`/servers/${s.id}/clients` + qs({ page, q: qtext }));
    const plat = d.platform || { java: 0, bedrock: 0 };
    setHTML(V(), html`${sPage(s, 'Клиент дата', 'данные о клиентах, платформах и связанных аккаунтах')}
      <div class="grid g3"><div class="card"><h3>Клиенты</h3>${barList(d.brands)}</div><div class="card"><h3>Версии клиента</h3>${barList(d.versions)}</div>
        <div class="card"><h3>Платформа</h3>${barList([{ name: 'Java', c: plat.java || 0 }, { name: 'Bedrock (Floodgate)', c: plat.bedrock || 0 }])}</div></div>
      ${d.brands.length === 1 && d.brands[0].name === 'не передан' ? html`<div class="note mt-s" style="font-size:13px">Название и версия клиента не пишутся в лог сервера. Чтобы они появились, отправляйте их плагином в событии <span class="mono">join</span> (<span class="mono">data.client_brand</span>, <span class="mono">data.client_version</span>) — см. «Информация».</div>` : ''}
      ${d.shared ? html`<div class="card flush mt"><div class="card-h"><h3>Аккаунты с общим IP</h3><span class="mut" style="font-size:13px">возможные твинки — проверяйте вручную</span></div>
        ${d.shared.length ? html`<div class="table-wrap"><table class="t"><thead><tr><th>IP</th><th>Аккаунтов</th><th>Ники</th></tr></thead><tbody>${d.shared.map(g => html`<tr><td class="mono">${g.ip}</td><td>${g.n}</td><td>${g.names.split(',').map(n => html`<a class="badge" style="margin:2px" href="#/s/${s.id}/players/${encodeURIComponent(n)}">${n}</a>`)}</td></tr>`)}</tbody></table></div>` : html`<div class="empty small">Общих IP не найдено</div>`}</div>` : ''}
      <div class="toolbar mt"><div class="search grow">${ic('search', 16)}<input class="input" id="cq" value="${qtext}" placeholder="Поиск игрока"></div></div>
      <div class="card flush"><div class="table-wrap"><table class="t"><thead><tr><th>Игрок</th><th>Клиент</th><th>Версия</th><th>Мир</th>${d.items.some(i => 'last_ip' in i) ? html`<th>Последний IP</th><th>IP / твинки</th>` : ''}<th>Был в сети</th></tr></thead><tbody>
        ${d.items.length ? d.items.map(p => html`<tr><td>${playerLink(s, p.name, 26)} ${p.online ? html`<span class="dot on"></span>` : ''}</td><td>${p.client_brand || html`<span class="mut">—</span>`}</td><td>${p.client_version || html`<span class="mut">—</span>`}</td><td>${p.last_world || html`<span class="mut">—</span>`}</td>
          ${'last_ip' in p ? html`<td class="mono">${p.last_ip || '—'}</td><td>${p.ip_count}${p.alts ? html` <span class="badge warn">твинков: ${p.alts}</span>` : ''}</td>` : ''}<td class="nowrap">${p.online ? 'сейчас' : ago(p.last_seen)}</td></tr>`) : html`<tr><td colspan="7" class="empty">Игроков пока нет</td></tr>`}</tbody></table></div>
        ${d.pages > 1 ? html`<div class="more"><button class="btn sm" data-pg="-1" ${d.page <= 1 ? 'disabled' : ''}>Назад</button><span class="dim" style="margin:0 12px;align-self:center">${d.page} / ${d.pages}</span><button class="btn sm" data-pg="1" ${d.page >= d.pages ? 'disabled' : ''}>Вперёд</button></div>` : ''}</div>`);
    const v = V();
    v.onclick = e => { const b = e.target.closest('[data-pg]'); if (b) { page += Number(b.dataset.pg); render().catch(errToast); } };
    const search = debounce(() => { page = 1; render().then(() => { const i = $('#cq'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }).catch(errToast); }, 350);
    v.oninput = e => { if (e.target.id === 'cq') { qtext = e.target.value.trim(); search(); } };
  };
  await render();
}

/* ═════════ Вайтлист ═════════ */
async function whitelistView(s) {
  const a = vapi();
  let qtext = '';
  const render = async () => {
    const d = await a(`/servers/${s.id}/whitelist`);
    const manage = can('whitelist');
    const items = d.items.filter(i => i.name.toLowerCase().includes(qtext.toLowerCase()));
    setHTML(V(), html`${sPage(s, 'Вайтлист', `${d.items.length} ${plural(d.items.length, ['игрок', 'игрока', 'игроков'])} в списке`, manage ? html`<button class="btn" data-w="pull">${ic('download', 16)} Загрузить с сервера</button><button class="btn" data-w="push">${ic('send', 16)} Отправить на сервер</button><button class="btn ghost" data-w="on">Включить</button><button class="btn ghost" data-w="off">Выключить</button>` : '')}
      ${d.can_command ? '' : html`<div class="note warn" style="margin-bottom:14px">Нет связи с сервером для команд — список хранится в панели, а изменения на сервер не отправляются, пока не подключён агент с RCON (или прямой RCON).</div>`}
      ${manage ? html`<form class="card row wrap" id="wl-add" style="margin-bottom:16px;align-items:flex-start"><textarea class="input grow" name="names" rows="2" placeholder="Ники через пробел, запятую или с новой строки" style="min-width:240px"></textarea><button class="btn primary" type="submit">${ic('plus', 16)} Добавить</button></form>` : ''}
      <div class="toolbar"><div class="search grow">${ic('search', 16)}<input class="input" id="wq" value="${qtext}" placeholder="Поиск по списку"></div></div>
      <div class="card flush">${items.length ? html`<div class="table-wrap"><table class="t"><thead><tr><th>Игрок</th><th>Добавил</th><th>Когда</th><th></th></tr></thead><tbody>${items.map(i => html`<tr><td>${playerLink(s, i.name, 26)}</td><td>${i.added_by || '—'}</td><td class="nowrap">${fmtFull(i.added_at)}</td><td style="text-align:right">${manage ? html`<button class="btn sm danger" data-del="${i.name}">${ic('trash', 15)}</button>` : ''}</td></tr>`)}</tbody></table></div>` : html`<div class="empty">Список пуст</div>`}</div>`);
    const v = V();
    v.onsubmit = async e => {
      e.preventDefault();
      const btn = $('button', e.target); btn.disabled = true;
      try {
        const r = await a(`/servers/${s.id}/whitelist`, { method: 'POST', body: { names: e.target.names.value } });
        toast(`Добавлено: ${r.added}` + (r.synced ? `, на сервере: ${r.applied}` : ' (на сервер не отправлено)'), r.errors.length ? 'warn' : 'ok');
        if (r.errors.length) toast(r.errors.join('\n'), 'err', 9000);
        await render();
      } catch (ex) { errToast(ex); btn.disabled = false; }
    };
    v.oninput = e => { if (e.target.id === 'wq') { qtext = e.target.value.trim(); const pos = e.target.selectionStart; render().then(() => { const i = $('#wq'); i.focus(); i.setSelectionRange(pos, pos); }).catch(() => {}); } };
    v.onclick = async e => {
      const del = e.target.closest('[data-del]');
      if (del) {
        if (!await confirmBox('Убрать из вайтлиста', `Убрать ${del.dataset.del} из вайтлиста?`, { ok: 'Убрать', danger: true })) return;
        try { const r = await a(`/servers/${s.id}/whitelist/${encodeURIComponent(del.dataset.del)}`, { method: 'DELETE', body: {} }); toast(r.applied ? 'Удалено' : 'Удалено в панели; на сервере: ' + r.error, r.applied ? 'ok' : 'warn'); await render(); } catch (ex) { errToast(ex); }
        return;
      }
      const w = e.target.closest('[data-w]'); if (!w) return;
      const k = w.dataset.w;
      try {
        if (k === 'pull' || k === 'push') {
          if (!await confirmBox(k === 'pull' ? 'Загрузить с сервера' : 'Отправить на сервер', k === 'pull' ? 'Список в панели будет заменён списком с сервера.' : 'Все ники из панели будут добавлены в вайтлист сервера.', { ok: 'Продолжить' })) return;
          const r = await a(`/servers/${s.id}/whitelist/sync`, { method: 'POST', body: { direction: k } });
          toast(k === 'pull' ? `Загружено игроков: ${r.count}` : `Отправлено: ${r.count} из ${r.total}`, r.errors && r.errors.length ? 'warn' : 'ok');
        } else { const r = await a(`/servers/${s.id}/whitelist/toggle`, { method: 'POST', body: { on: k === 'on' } }); toast(r.response || 'Готово'); }
        await render();
      } catch (ex) { errToast(ex); }
    };
  };
  await render();
}

/* ═════════ Список игроков ═════════ */
async function playersView(s) {
  const a = vapi();
  const st = { tab: 'players', q: '', filter: '', sort: 'last', page: 1, ptype: '', pactive: false };
  const shell = () => {
    setHTML(V(), html`${sPage(s, 'Список игроков')}
      <div class="tabs"><button class="tab ${st.tab === 'players' ? 'active' : ''}" data-tab="players">Игроки</button><button class="tab ${st.tab === 'pun' ? 'active' : ''}" data-tab="pun">Наказания</button></div><div id="pbody"></div>`);
  };
  const drawPlayers = async () => {
    const d = await a(`/servers/${s.id}/players` + qs({ q: st.q, filter: st.filter, sort: st.sort, page: st.page }));
    const ip = d.items.some(i => 'last_ip' in i);
    setHTML($('#pbody'), html`<div class="toolbar"><div class="search grow">${ic('search', 16)}<input class="input" id="pq" value="${st.q}" placeholder="Поиск по нику"></div>
      <select class="select" id="pf">${[['', 'Все игроки'], ['online', 'Онлайн'], ['banned', 'Забанены'], ['muted', 'В муте']].map(([k, l]) => html`<option value="${k}" ${st.filter === k ? 'selected' : ''}>${l}</option>`)}</select>
      <select class="select" id="ps">${[['last', 'По последнему входу'], ['playtime', 'По времени в игре'], ['joins', 'По числу входов'], ['first', 'Новые сначала'], ['name', 'По алфавиту']].map(([k, l]) => html`<option value="${k}" ${st.sort === k ? 'selected' : ''}>${l}</option>`)}</select></div>
      <div class="card flush"><div class="table-wrap"><table class="t"><thead><tr><th>Игрок</th><th>Статус</th><th>Время в игре</th><th>Входов</th><th>Первый вход</th><th>Последний вход</th>${ip ? html`<th>IP</th>` : ''}</tr></thead><tbody>
      ${d.items.length ? d.items.map(p => html`<tr class="click" data-go="${p.name}"><td>${playerLink(s, p.name, 28)}${p.banned ? html` <span class="badge bad">бан</span>` : ''}${p.muted ? html` <span class="badge warn">мут</span>` : ''}</td><td>${p.online ? html`<span class="ok"><i class="dot on"></i>онлайн</span>` : html`<span class="mut">офлайн</span>`}</td><td>${fmtDur(p.playtime)}</td><td>${p.joins}</td><td class="nowrap">${fmtDate(p.first_seen)}</td><td class="nowrap">${p.online ? 'сейчас' : ago(p.last_seen)}</td>${ip ? html`<td class="mono">${p.last_ip || '—'}</td>` : ''}</tr>`) : html`<tr><td colspan="7" class="empty">Игроки не найдены</td></tr>`}</tbody></table></div>
      <div class="more"><span class="dim" style="align-self:center;margin-right:12px">Всего: ${d.total}</span>${d.pages > 1 ? html`<button class="btn sm" data-pg="-1" ${d.page <= 1 ? 'disabled' : ''}>Назад</button><span class="dim" style="margin:0 12px;align-self:center">${d.page} / ${d.pages}</span><button class="btn sm" data-pg="1" ${d.page >= d.pages ? 'disabled' : ''}>Вперёд</button>` : ''}</div></div>`);
  };
  const pun = { items: [], more: false };
  const drawPun = async (reset = true) => {
    const last = reset ? null : pun.items[pun.items.length - 1];
    const d = await a(`/servers/${s.id}/punishments` + qs({ type: st.ptype, active: st.pactive ? 1 : '', q: st.q, before: last && last.id }));
    pun.items = reset ? d.items : pun.items.concat(d.items); pun.more = d.has_more;
    const state = p => p.active ? html`<span class="badge bad">активно</span>` : p.ended_at ? html`<span class="badge mut">${p.ended_by || 'снято'}</span>` : html`<span class="badge mut">—</span>`;
    setHTML($('#pbody'), html`<div class="toolbar"><div class="search grow">${ic('search', 16)}<input class="input" id="pq" value="${st.q}" placeholder="Ник игрока или сотрудника"></div>
      <select class="select" id="pt"><option value="">Все типы</option>${Object.entries(PUN).map(([k, v]) => html`<option value="${k}" ${st.ptype === k ? 'selected' : ''}>${v[0]}</option>`)}</select>
      <label class="check"><input type="checkbox" id="pa" ${st.pactive ? 'checked' : ''}> Только активные</label></div>
      <div class="card flush"><div class="table-wrap"><table class="t"><thead><tr><th>Время</th><th>Тип</th><th>Игрок</th><th>Причина</th><th>Срок</th><th>Выдал</th><th>Состояние</th><th></th></tr></thead><tbody>
      ${pun.items.length ? pun.items.map(p => html`<tr><td class="nowrap">${fmtTime(p.created_at, false)}</td><td>${punBadge(p.type)}</td><td>${playerLink(s, p.player, 22)}</td><td style="max-width:280px;word-break:break-word">${p.reason || '—'}</td>
        <td class="nowrap">${p.duration ? fmtDur(p.duration) : (p.type === 'ban' || p.type === 'mute' ? 'навсегда' : '—')}${p.active && p.expires_at ? html`<div class="mut" style="font-size:12px">до ${fmtTime(p.expires_at, false)}</div>` : ''}</td>
        <td>${p.issued_name || '—'} ${p.source === 'game' ? html`<span class="badge mut">игра</span>` : ''}</td><td>${state(p)}${!p.applied && p.source === 'panel' ? html` <span class="badge warn" title="Команда на сервере не выполнялась">не применено</span>` : ''}</td>
        <td style="text-align:right">${!p.applied && p.source === 'panel' && can('punish') ? html`<button class="btn sm" data-retry="${p.id}">Повторить</button>` : ''}</td></tr>`) : html`<tr><td colspan="8" class="empty">Наказаний нет</td></tr>`}</tbody></table></div>
      ${pun.more ? html`<div class="more"><button class="btn" data-pm="1">Показать ещё</button></div>` : ''}</div>`);
  };
  const draw = () => (st.tab === 'players' ? drawPlayers() : drawPun());
  shell(); await draw();
  const refocus = id => () => { const i = $('#' + id); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } };
  const search = debounce(() => { st.page = 1; draw().then(refocus('pq')).catch(errToast); }, 350);
  const v = V();
  v.oninput = e => { if (e.target.id === 'pq') { st.q = e.target.value.trim(); search(); } };
  v.onchange = e => {
    const id = e.target.id;
    if (id === 'pf') st.filter = e.target.value; else if (id === 'ps') st.sort = e.target.value; else if (id === 'pt') st.ptype = e.target.value; else if (id === 'pa') st.pactive = e.target.checked; else return;
    st.page = 1; draw().catch(errToast);
  };
  v.onclick = async e => {
    const tab = e.target.closest('[data-tab]'); if (tab) { st.tab = tab.dataset.tab; st.q = ''; shell(); return draw().catch(errToast); }
    const pg = e.target.closest('[data-pg]'); if (pg) { st.page += Number(pg.dataset.pg); return draw().catch(errToast); }
    if (e.target.closest('[data-pm]')) return drawPun(false).catch(errToast);
    const rt = e.target.closest('[data-retry]');
    if (rt) { try { const r = await a('/punishments/' + rt.dataset.retry + '/retry', { method: 'POST', body: {} }); toast(r.applied ? 'Выполнено на сервере' : 'Не удалось: ' + r.error, r.applied ? 'ok' : 'err'); drawPun().catch(() => {}); } catch (ex) { errToast(ex); } return; }
    const row = e.target.closest('tr[data-go]'); if (row && !e.target.closest('a')) location.hash = `#/s/${s.id}/players/${encodeURIComponent(row.dataset.go)}`;
  };
  live(m => { if ((m.t === 'online' || m.t === 'punish') && m.server === s.id && st.tab === (m.t === 'punish' ? 'pun' : 'players') && a.alive() && document.activeElement.tagName !== 'INPUT') draw().catch(() => {}); });
}

/* ═════════ Профиль игрока ═════════ */
async function profileView(s, name) {
  const a = vapi();
  let tab = S.profTab || 'events'; S.profTab = null;
  let d;
  try { d = await a(`/servers/${s.id}/players/${encodeURIComponent(name)}`); }
  catch (e) { if (e.stale) throw e; return setHTML(V(), html`${sPage(s, name)}<div class="card empty">${e.message}. Игрок ещё не появлялся на этом сервере.<p><a class="btn" href="#/s/${s.id}/players">К списку</a></p></div>`); }
  const reloadAll = () => profileView(s, name).catch(errToast);
  const p = d.player;
  const ban = d.punishments.find(x => x.type === 'ban' && x.active), mute = d.punishments.find(x => x.type === 'mute' && x.active);
  const st = d.stats;
  setHTML(V(), html`${sPage(s, 'Профиль игрока', null, html`<a class="btn" href="#/s/${s.id}/players">${ic('back', 16)} К списку</a>`)}
    <div class="card"><div class="profile-head">${head(p.name, 72)}<div class="grow"><div class="row wrap"><h2 style="margin:0">${p.name}</h2>${p.online ? html`<span class="badge ok">онлайн</span>` : html`<span class="badge mut">офлайн</span>`}${ban ? html`<span class="badge bad">забанен</span>` : ''}${mute ? html`<span class="badge warn">в муте</span>` : ''}${d.whitelisted ? html`<span class="badge cyan">в вайтлисте</span>` : ''}</div>
      <div class="dim" style="margin-top:4px">${p.online ? 'Сейчас на сервере' : 'Последний вход: ' + ago(p.last_seen)}</div></div></div>
      ${can('punish') ? html`<div class="row wrap mt">
        ${can('ban') ? (ban ? html`<button class="btn" data-pa="unban">Разбанить</button>` : html`<button class="btn danger" data-pa="ban">${ic('ban', 16)} Бан</button>`) : ''}
        ${mute ? html`<button class="btn" data-pa="unmute">Снять мут</button>` : html`<button class="btn warn" data-pa="mute">${ic('mute', 16)} Мут</button>`}
        <button class="btn warn" data-pa="kick">${ic('kick', 16)} Кик</button><button class="btn" data-pa="warn">${ic('warnc', 16)} Предупреждение</button></div>` : ''}
      ${ban || mute ? html`<div class="note bad mt-s">${[ban, mute].filter(Boolean).map(x => html`<div>${PUN[x.type][0]}: ${x.reason || 'без причины'} — ${x.issued_name || '—'}, ${fmtFull(x.created_at)}${x.expires_at ? ', до ' + fmtFull(x.expires_at) : ', навсегда'}</div>`)}</div>` : ''}</div>
    <div class="grid g2 mt"><div class="card"><dl class="kv"><dt>UUID</dt><dd class="mono" style="font-size:13px">${p.uuid || '—'}</dd><dt>Первый вход</dt><dd>${fmtFull(p.first_seen)}</dd><dt>Последний вход</dt><dd>${fmtFull(p.last_seen)}</dd><dt>Время в игре</dt><dd>${fmtDur(p.playtime)}</dd><dt>Входов</dt><dd>${p.joins}</dd></dl></div>
      <div class="card"><dl class="kv"><dt>Клиент</dt><dd>${p.client_brand ? `${p.client_brand} ${p.client_version || ''}` : '—'}</dd><dt>Мир</dt><dd>${p.last_world || '—'}</dd>${'last_ip' in p ? html`<dt>Последний IP</dt><dd class="mono">${p.last_ip || '—'}</dd>` : ''}<dt>Сообщений</dt><dd>${st.chat || 0}</dd><dt>Команд</dt><dd>${st.command || 0}</dd><dt>Смертей</dt><dd>${st.death || 0}</dd></dl></div></div>
    <div class="tabs mt" id="ptabs"></div><div id="pbody2"></div>`);
  const tabs = [['events', 'События'], ['pun', `Наказания (${d.punishments.length})`], ['notes', `Заметки (${d.notes.length})`], ['reports', `Репорты (${d.reports_against.length + d.reports_by.length})`]];
  if (d.ips) tabs.push(['ips', `IP и твинки (${d.alts.length})`]);
  tabs.push(['sess', 'Сессии']);
  let feed = null;
  const drawTabs = () => setHTML($('#ptabs'), tabs.map(([k, l]) => html`<button class="tab ${tab === k ? 'active' : ''}" data-t="${k}">${l}</button>`));
  const drawTab = async () => {
    drawTabs(); feed = null;
    const body = $('#pbody2');
    if (tab === 'events') {
      setHTML(body, html`<div class="card flush"><div id="pe-list"></div><div class="more" id="pe-more"></div></div>`);
      feed = createFeed(s, a, $('#pe-list'), $('#pe-more'), () => ({ player: name }));
      await feed.load(true);
    } else if (tab === 'pun') {
      setHTML(body, html`<div class="card flush">${d.punishments.length ? html`<div class="table-wrap"><table class="t"><thead><tr><th>Время</th><th>Тип</th><th>Причина</th><th>Срок</th><th>Выдал</th><th>Состояние</th></tr></thead><tbody>${d.punishments.map(x => html`<tr><td class="nowrap">${fmtFull(x.created_at)}</td><td>${punBadge(x.type)}</td><td>${x.reason || '—'}</td><td>${x.duration ? fmtDur(x.duration) : (x.type === 'ban' || x.type === 'mute' ? 'навсегда' : '—')}</td><td>${x.issued_name || '—'}</td><td>${x.active ? html`<span class="badge bad">активно</span>` : x.ended_at ? html`<span class="badge mut">${x.ended_by || 'снято'}</span>` : '—'}</td></tr>`)}</tbody></table></div>` : html`<div class="empty">Наказаний нет</div>`}</div>`);
    } else if (tab === 'notes') {
      setHTML(body, html`<div class="card"><form class="row" id="nf" style="align-items:flex-start;margin-bottom:14px"><textarea class="input grow" name="text" rows="2" placeholder="Заметка о игроке (видна всему персоналу)" maxlength="1000"></textarea><button class="btn primary" type="submit">Добавить</button></form>
        ${d.notes.length ? d.notes.map(n => html`<div class="comment"><div class="h row">${n.user_name} · ${fmtFull(n.ts)}${n.user_id === S.me.id || can('servers.manage') ? html`<button class="btn sm danger right" data-dn="${n.id}">${ic('trash', 14)}</button>` : ''}</div><div style="white-space:pre-wrap">${n.text}</div></div>`) : html`<div class="mut">Заметок нет</div>`}</div>`);
    } else if (tab === 'reports') {
      const row = (r, who) => html`<tr class="click" data-href="#/s/${s.id}/reports"><td>#${r.id}</td><td>${fmtTime(r.created_at, false)}</td><td>${who}</td><td>${r.reason}</td><td><span class="badge ${REP_ST[r.status][1]}">${REP_ST[r.status][0]}</span></td></tr>`;
      setHTML(body, html`<div class="card flush"><div class="table-wrap"><table class="t"><thead><tr><th>#</th><th>Время</th><th>Кто / на кого</th><th>Причина</th><th>Статус</th></tr></thead><tbody>
        ${d.reports_against.map(r => row(r, html`на него от ${r.reporter || '—'}`))}${d.reports_by.map(r => row(r, html`он → ${r.target || '—'}`))}
        ${d.reports_against.length + d.reports_by.length ? '' : html`<tr><td colspan="5" class="empty">Репортов нет</td></tr>`}</tbody></table></div></div>`);
    } else if (tab === 'ips') {
      setHTML(body, html`<div class="grid g2"><div class="card flush"><div class="card-h"><h3>IP-адреса</h3></div><div class="table-wrap"><table class="t"><thead><tr><th>IP</th><th>Входов</th><th>Первый</th><th>Последний</th></tr></thead><tbody>${d.ips.map(i => html`<tr><td class="mono">${i.ip}</td><td>${i.cnt}</td><td class="nowrap">${fmtDate(i.first_seen)}</td><td class="nowrap">${ago(i.last_seen)}</td></tr>`)}${d.ips.length ? '' : html`<tr><td colspan="4" class="empty">Нет данных</td></tr>`}</tbody></table></div></div>
        <div class="card flush"><div class="card-h"><h3>Аккаунты с общим IP</h3></div><div class="table-wrap"><table class="t"><thead><tr><th>Игрок</th><th>Общие IP</th><th>Статус</th></tr></thead><tbody>${d.alts.map(x => html`<tr><td>${playerLink(s, x.name, 24)}</td><td class="mono" style="font-size:12.5px">${x.shared_ips}</td><td>${x.banned ? html`<span class="badge bad">бан</span>` : x.online ? html`<span class="badge ok">онлайн</span>` : ago(x.last_seen)}</td></tr>`)}${d.alts.length ? '' : html`<tr><td colspan="3" class="empty">Не найдено</td></tr>`}</tbody></table></div></div></div>`);
    } else {
      setHTML(body, html`<div class="card flush">${d.sessions.length ? html`<div class="table-wrap"><table class="t"><thead><tr><th>Вход</th><th>Выход</th><th>Длительность</th></tr></thead><tbody>${d.sessions.map(x => html`<tr><td>${fmtFull(x.joined)}</td><td>${x.left ? fmtFull(x.left) : html`<span class="ok">в игре</span>`}</td><td>${fmtDur(((x.left || Date.now()) - x.joined) / 1000)}</td></tr>`)}</tbody></table></div>` : html`<div class="empty">Сессий нет</div>`}</div>`);
    }
  };
  await drawTab();
  live(m => { if (m.t === 'events' && m.server === s.id && tab === 'events' && feed) feed.pull().catch(() => {}); });
  V().onclick = async e => {
    const t = e.target.closest('[data-t]'); if (t) { tab = t.dataset.t; return drawTab().catch(errToast); }
    if (e.target.closest('[data-feed=more]') && feed) return feed.load(false).catch(errToast);
    const pa = e.target.closest('[data-pa]');
    if (pa) { const k = pa.dataset.pa; return k === 'unban' || k === 'unmute' ? undoPunish(s, name, k, reloadAll) : punishModal(s, name, k, reloadAll); }
    const dn = e.target.closest('[data-dn]');
    if (dn) { if (await confirmBox('Удалить заметку', 'Удалить эту заметку?', { ok: 'Удалить', danger: true })) api(`/servers/${s.id}/notes/${dn.dataset.dn}`, { method: 'DELETE', body: {} }).then(() => { S.profTab = 'notes'; return reloadAll(); }).catch(errToast); }
  };
  V().onsubmit = e => {
    if (e.target.id !== 'nf') return;
    e.preventDefault();
    const text = e.target.text.value.trim(); if (!text) return;
    api(`/servers/${s.id}/players/${encodeURIComponent(name)}/notes`, { method: 'POST', body: { text } }).then(() => { toast('Заметка добавлена'); S.profTab = 'notes'; return profileView(s, name); }).catch(errToast);
  };
}

/* ═════════ Настройки сервера / добавление ═════════ */
const TPL_L = {
  ban: 'Бан', unban: 'Разбан', kick: 'Кик', mute: 'Мут', unmute: 'Размут', warn: 'Предупреждение',
  whitelist_add: 'Вайтлист: добавить', whitelist_remove: 'Вайтлист: убрать',
};
function agentSnippet(key, s) {
  const cfg = { panel: location.origin, key, log: '/путь/к/серверу/logs/latest.log', mcHost: '127.0.0.1', mcPort: s.port || 25565, rcon: { host: '127.0.0.1', port: 25575, password: 'пароль из server.properties' } };
  return JSON.stringify(cfg, null, 2);
}
const installCmd = key => `curl -fsSL ${location.origin}/install/${key} | bash`;
function showKey(key, s) {
  modal({
    title: 'Ключ сервера и подключение агента', wide: true,
    body: html`<div class="note warn" style="margin-bottom:14px">Ключ показывается <b>один раз</b>. Сохраните его — позже его можно только перевыпустить.</div>
      <div class="field"><label>Установка одной командой (Linux, нужен Node.js 18+)</label><div class="row"><input class="input mono" readonly value="${installCmd(key)}"><button class="btn" data-copy="${installCmd(key)}">${ic('copy', 16)}</button></div><div class="hint">Выполните на машине с сервером Minecraft, из его папки. Агент сам найдёт server.properties и логи, запустится как служба и будет обновляться вместе с панелью.</div></div>
      <details style="margin:14px 0"><summary class="mut" style="cursor:pointer">Ручная установка</summary>
      <div class="field" style="margin-top:12px"><label>Ключ сервера «${s.name}»</label><div class="row"><input class="input mono" readonly value="${key}"><button class="btn" data-copy="${key}">${ic('copy', 16)}</button></div></div>
      <p class="dim" style="margin:14px 0 8px"><b>1.</b> Скачайте <a href="/api/agent-files/agent.js" download>agent.js</a> и <a href="/api/agent-files/mc.js" download>mc.js</a> на машину с сервером (нужен Node.js 18+).</p>
      <p class="dim" style="margin:0 0 8px"><b>2.</b> Создайте рядом <span class="mono">agent.config.json</span>:</p><pre class="code">${agentSnippet(key, s)}</pre>
      <p class="dim" style="margin:14px 0 8px"><b>3.</b> Запустите:</p><pre class="code">node agent.js --config agent.config.json</pre>
      <p class="dim" style="margin:14px 0 0;font-size:13px">Короткий вариант без конфига: <span class="mono">node agent.js --panel ${location.origin} --key ${key} --properties /путь/к/server.properties</span> — агент сам найдёт лог и параметры RCON. Для постоянной работы запустите через systemd, pm2 или screen.</p></details>`,
    footer: html`<button class="btn" data-copy="${agentSnippet(key, s)}">${ic('copy', 16)} Копировать конфиг</button><button class="btn primary" data-close>Готово</button>`,
  });
}
async function serverFormView(s0) {
  const a = vapi();
  const s = s0;
  const isNew = !s;
  const t = s ? s.templates : null;
  setHTML(V(), html`${pageHead(isNew ? 'Новый сервер' : 'Настройки сервера', isNew ? 'После создания панель выдаст ключ для агента' : s.name)}
    <form class="card" id="sf" autocomplete="off" style="max-width:820px"><h3>Основное</h3>
      <div class="fgrid"><div class="field"><label>Название</label><input class="input" name="name" required maxlength="40" value="${s ? s.name : ''}"></div>
        <div class="field"><label>Цвет иконки</label><input class="input" type="color" name="color" value="${s ? s.color : '#4f7cff'}" style="padding:4px;height:42px"></div>
        <div class="field"><label>Адрес сервера</label><input class="input" name="host" placeholder="mc.example.com или IP" value="${s && s.host ? s.host : ''}"><div class="hint">Для опроса статуса (пинг, онлайн, иконка). Можно оставить пустым — тогда статус пришлёт агент.</div></div>
        <div class="field"><label>Порт</label><input class="input" type="number" name="port" min="1" max="65535" value="${s ? s.port : 25565}"></div></div>
      <h3 style="margin-top:8px">Команды (RCON)</h3>
      <div class="field"><label class="check"><input type="radio" name="rcon_mode" value="agent" ${!s || s.rcon_mode === 'agent' ? 'checked' : ''}> Через агента (рекомендуется)</label><div class="hint" style="margin:2px 0 8px 26px">RCON-порт сервера не нужно открывать наружу — агент выполняет команды локально.</div>
        <label class="check"><input type="radio" name="rcon_mode" value="direct" ${s && s.rcon_mode === 'direct' ? 'checked' : ''}> Прямое подключение панели к RCON</label></div>
      <div id="direct-box" class="fgrid" style="${s && s.rcon_mode === 'direct' ? '' : 'display:none'}"><div class="field"><label>RCON порт</label><input class="input" type="number" name="rcon_port" value="${s && s.rcon_port ? s.rcon_port : 25575}"></div>
        <div class="field"><label>RCON пароль</label><input class="input" type="password" name="rcon_password" autocomplete="new-password" placeholder="${s && s.has_rcon_password ? '•••••••• (оставьте пустым, чтобы не менять)' : ''}"></div></div>
      ${!isNew ? html`<details style="margin:6px 0 16px"><summary style="cursor:pointer;font-weight:600">Шаблоны команд наказаний</summary><div class="hint" style="margin:8px 0">Подстановки: <span class="mono">{player} {reason} {duration} {issuer}</span>. Если плагин модерации другой (LiteBans, Essentials, AdvancedBan…), поменяйте команды под него. Если в шаблоне мута/бана нет {duration}, панель сама снимет наказание по сроку.</div>
        <div class="fgrid">${Object.keys(TPL_L).map(k => html`<div class="field"><label>${TPL_L[k]}</label><input class="input mono" name="tpl_${k}" value="${t[k]}"></div>`)}</div></details>` : ''}
      <div class="form-err" id="sf-err"></div><div class="row"><button class="btn primary" type="submit">${isNew ? 'Создать сервер' : 'Сохранить'}</button>${isNew ? '' : html`<button class="btn" type="button" data-k="test">Проверить связь</button>`}</div></form>
    ${isNew ? '' : html`<div class="card mt" style="max-width:820px"><h3>Агент и ключ</h3><dl class="kv"><dt>Ключ</dt><dd class="mono">mcp_••••••••${s.api_key_hint}</dd><dt>Агент</dt><dd>${s.agent_alive ? html`<span class="ok">● подключён</span> v${s.agent_version || '?'}` : html`<span class="bad">● не подключён</span>`}</dd></dl>
      <div class="row wrap mt-s"><button class="btn" data-k="key">${ic('key', 16)} Перевыпустить ключ</button></div><div class="hint" style="margin-top:8px">После перевыпуска старый ключ перестаёт работать — агент нужно перенастроить.</div></div>
      <div class="card mt" style="max-width:820px;border-color:rgba(240,82,79,.4)"><h3 class="bad">Опасная зона</h3><p class="dim" style="margin-top:0">Удаление сервера стирает всю его историю: игроков, логи, наказания, репорты.</p><button class="btn danger" data-k="del">${ic('trash', 16)} Удалить сервер</button></div>`}`);
  const form = $('#sf');
  form.addEventListener('change', e => { if (e.target.name === 'rcon_mode') $('#direct-box').style.display = e.target.value === 'direct' ? '' : 'none'; });
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const f = form, err = $('#sf-err'); err.textContent = '';
    const body = { name: f.name.value, color: f.color.value, host: f.host.value, port: f.port.value, rcon_mode: f.rcon_mode.value, rcon_port: f.rcon_port.value, rcon_password: f.rcon_password.value };
    if (!isNew) { body.templates = {}; for (const k of Object.keys(TPL_L)) body.templates[k] = f['tpl_' + k].value; }
    const btn = $('button[type=submit]', f); btn.disabled = true;
    try {
      if (isNew) {
        const r = await api('/servers', { method: 'POST', body });
        await loadMe(); renderSidebar(); updateTop();
        location.hash = `#/s/${r.server.id}/settings`;
        showKey(r.api_key, r.server);
      } else {
        await api('/servers/' + s.id, { method: 'PATCH', body });
        await loadMe(); renderSidebar(); toast('Настройки сохранены'); route();
      }
    } catch (ex) { err.textContent = ex.message; btn.disabled = false; }
  });
  V().onclick = async e => {
    const b = e.target.closest('[data-k]'); if (!b || isNew) return;
    const k = b.dataset.k;
    try {
      if (k === 'test') {
        await api(`/servers/${s.id}/refresh`, { method: 'POST', body: {} });
        const r = await api(`/servers/${s.id}/rcon-test`, { method: 'POST', body: {} });
        await loadMe();
        const cur = srv(s.id);
        toast(`Статус: ${cur.online ? 'в сети' : 'недоступен'}. RCON: ${r.ok ? 'работает' : r.error}`, cur.online && r.ok ? 'ok' : 'warn', 8000);
      } else if (k === 'key') {
        if (!await confirmBox('Перевыпустить ключ', 'Старый ключ сразу перестанет работать, агент придётся перенастроить.', { ok: 'Перевыпустить', danger: true })) return;
        const r = await api(`/servers/${s.id}/key`, { method: 'POST', body: {} });
        showKey(r.api_key, s);
      } else if (k === 'del') {
        formModal({
          title: 'Удалить сервер', submit: 'Удалить навсегда', danger: true,
          body: html`<p style="margin-top:0">Для подтверждения введите название сервера: <b>${s.name}</b></p><input class="input" name="confirm" required>`,
          onSubmit: async (d, f, m) => { await api('/servers/' + s.id, { method: 'DELETE', body: { confirm: d.confirm } }); m.close(); await loadMe(); toast('Сервер удалён'); location.hash = '#/'; renderSidebar(); },
        });
      }
    } catch (ex) { errToast(ex); }
  };
}

function settingsView(s) { return serverFormView(s); }
